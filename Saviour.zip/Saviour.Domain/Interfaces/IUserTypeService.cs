﻿using System.Security.Claims;
using Saviour.Domain.Dto;

namespace Saviour.Domain.Interfaces;

public interface IUserTypeService
{
    UserType Get(ClaimsPrincipal user);
}