﻿using System.Threading.Tasks;
using Saviour.Domain.Dto;

namespace Saviour.Domain.Interfaces;

public interface ISampleService
{
    Task AddSampleAsync(UploadSampleDto sample);
}