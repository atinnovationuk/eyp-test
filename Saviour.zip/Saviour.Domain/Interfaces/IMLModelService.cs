﻿using System.Threading.Tasks;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IMLModelService
{
    ValueTask Run(MLInputData inputData);
}