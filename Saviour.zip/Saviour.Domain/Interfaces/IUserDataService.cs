﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Saviour.Domain.Dto;

namespace Saviour.Domain.Interfaces;

public interface IUserDataService
{
    ValueTask<CompanyDto?> TryGetCompany(ClaimsPrincipal user);

    IAsyncEnumerable<PerSiteData<ReportSummary>> GetReports(string companyId);
}