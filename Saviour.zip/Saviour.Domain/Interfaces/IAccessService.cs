﻿using System.Security.Claims;
using System.Threading.Tasks;

namespace Saviour.Domain.Interfaces;

public interface IAccessService
{
    /// <summary>
    /// Indicates if the input user can access the data of a company
    /// </summary>
    ValueTask<bool> CanAccessCompanyData(ClaimsPrincipal user, string companyId);
}