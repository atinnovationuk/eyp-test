﻿using System.Collections.Generic;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public record SampleResults(decimal[] Results);

public interface IPrepareMLInputs
{
    IEnumerable<SampleResults> GetInputs(MLInputData inputData);
}