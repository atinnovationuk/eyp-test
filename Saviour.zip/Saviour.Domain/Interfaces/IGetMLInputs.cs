﻿using System.Linq;
using System.Threading.Tasks;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IGetMLInputs
{
    ValueTask<MLInputData> Get(MLModel model, IQueryable<Sample> samples);
}