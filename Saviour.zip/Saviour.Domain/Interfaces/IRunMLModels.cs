﻿using System.Threading.Tasks;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IRunMLModels
{
    Task Run(MLModelType modelType, Batch batch);
}
