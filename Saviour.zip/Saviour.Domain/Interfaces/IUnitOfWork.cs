﻿using System;
using System.Threading.Tasks;

namespace Saviour.Domain.Interfaces;

/// <summary>
/// Represents the unit of work pattern for transactional operations with a database
/// </summary>
public interface IUnitOfWork
{
    ValueTask<ITransaction> BeginTransaction();
    ValueTask SaveChangesAsync();
}

public interface ITransaction : IDisposable
{
    ValueTask Rollback();
    ValueTask Commit();
}