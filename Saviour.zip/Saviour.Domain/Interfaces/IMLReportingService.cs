﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IMLReportingService
{
    ValueTask OnCreated(DraftReport draftReport);
    
    ValueTask OnApproved(DraftReport draftReport, Report report);
}