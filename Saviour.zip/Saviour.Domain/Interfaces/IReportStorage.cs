﻿using System.IO;
using System.Threading.Tasks;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IReportStorage
{
    ValueTask Save(Stream reportData, Report report);
    ValueTask<Stream> Get(Report report);
}