﻿using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IMLRealtimeRequest
{
    ValueTask<Stream> Post(HttpClient client, Uri endPoint, MLInputData inputData);
}