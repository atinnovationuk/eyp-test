﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Saviour.Domain.Interfaces;

/// <summary>
/// Represents the repository pattern for abstraction of database CRUD interactions
/// </summary>
/// <typeparam name="T"></typeparam>
public interface IRepository<T>
{
    /// <summary>
    /// Returns all instances of this type
    /// </summary>
    IQueryable<T> GetAll();

    /// <summary>
    /// Looks up an item by ID
    /// </summary>
    /// <param name="id">ID of item</param>
    /// <returns>The item or null if the item could not be found</returns>
    ValueTask<T?> GetByIdAsync(object id);

    /// <summary>
    /// Looks up an item via the input callback, or creates it if it is not present.
    /// This has a side-effect of locking the whole table for the rest of the transaction, so it may not be suitable for all queries
    /// </summary>
    /// <param name="find">Callback to locate item</param>
    /// <param name="create">Callback to construct an instance of the entity if not found</param>
    /// <returns>The found item or newly created item</returns>
    ValueTask<T> FindOrCreateAsync(Func<Task<T?>> find, Func<Task<T>> create);

    /// <summary>
    /// Looks up an item by ID, or creates it if it is not present.
    /// This has a side-effect of locking the whole table for the rest of the transaction, so it may not be suitable for all queries
    /// </summary>
    /// <param name="id">ID of item</param>
    /// <param name="create">Callback to construct an instance of the entity if not found</param>
    /// <returns>The found item or newly created item</returns>
    ValueTask<T> FindByIdOrCreateAsync(object id, Func<Task<T>> create);

    /// <summary>
    /// Queries via the input predicate
    /// </summary>
    /// <returns>All items which return true for the predicate</returns>
    IQueryable<T> FindAsync(Expression<Func<T, bool>> predicate);

    /// <summary>
    /// Creates the input item
    /// </summary>
    /// <returns>Created object</returns>
    ValueTask<T> InsertAsync(T item);

    /// <summary>
    /// Updates the input item data
    /// </summary>
    void Update(T item);

    /// <summary>
    /// Deletes an item
    /// </summary>
    void Delete(T item);
}

public static class RepositoryExtensions
{
    public static ValueTask<T> FindOrCreateAsync<T>(this IRepository<T> repository, Func<Task<T?>> find, Func<T> create)
        => repository.FindOrCreateAsync(find, () => Task.FromResult(create()));
    
    public static ValueTask<T> FindByIdOrCreateAsync<T>(this IRepository<T> repository, object id, Func<T> create)
        => repository.FindByIdOrCreateAsync(id, () => Task.FromResult(create()));
}
