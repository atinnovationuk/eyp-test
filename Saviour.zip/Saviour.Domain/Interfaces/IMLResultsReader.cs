﻿using System.Collections.Generic;
using System.IO;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IMLResultsReader
{
    IEnumerable<FishHealthResultType> ReadFishHealthResults(Stream resultsStream);
}