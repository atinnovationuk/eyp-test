﻿using System.Threading.Tasks;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IBatchListener
{
    ValueTask OnBatchUpdated(Batch batch);
}
