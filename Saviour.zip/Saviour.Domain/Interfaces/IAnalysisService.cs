﻿using System.Collections.Generic;
using Saviour.Domain.Dto;

namespace Saviour.Domain.Interfaces;

public interface IAnalysisService
{
    IAsyncEnumerable<AnalysisDto> GetAll(string countryCode);
    IAsyncEnumerable<AnalysisDto> Get(string countryCode, IEnumerable<int> analysisIds);
}