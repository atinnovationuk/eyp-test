﻿using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IGetMLModel
{
    MLModel GetLatest(MLModelType modelType);
}