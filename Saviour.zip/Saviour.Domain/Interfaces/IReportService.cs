﻿using System.IO;
using System.Threading.Tasks;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;

namespace Saviour.Domain.Interfaces;

public interface IReportService
{
    /// <summary>
    /// Creates a report object from the input data
    /// </summary>
    /// <param name="data">Input data</param>
    /// <param name="user">User creating the report</param>
    /// <returns></returns>
    /// <exception cref="EntityNotFoundException">Report could not be created because of missing related entities</exception>
    /// <exception cref="EntitiesNotFoundException">Report could not be created because of missing related entities</exception>
    /// <exception cref="InvalidUserException">The user object was invalid</exception>
    ValueTask<DraftReport> Create(NewReport data, User user);

    /// <summary>
    /// Retrieve a draft report by ID
    /// </summary>
    /// <returns>Report data, or null if not found</returns>
    ValueTask<DraftReport?> GetDraft(long reportId);
    
    /// <summary>
    /// Retrieve a report by ID
    /// </summary>
    /// <returns>Report data, or null if not found</returns>
    ValueTask<Report?> Get(long reportId);

    /// <summary>
    /// Mark the input report as reviewed
    /// </summary>
    /// <param name="reportId">Report ID</param>
    /// <param name="user">Reviewing user</param>
    /// <param name="file">File content</param>
    /// <returns>The full report if changes were accepted, otherwise null</returns>
    /// <remarks>The change may be rejected if for example the report has already been reviewed, or if the input user also created this report</remarks>
    ValueTask<Report?> Approve(long reportId, User user, Stream file);

    /// <summary>
    /// Deletes a draft report
    /// </summary>
    ValueTask Delete(long draftReportId);
}