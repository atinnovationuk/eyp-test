﻿using System.Security.Claims;
using System.Threading.Tasks;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IUserService
{
    ValueTask<User> FindOrCreate(ClaimsPrincipal userIdentity);
    ValueTask<User> Find(int userId);
}