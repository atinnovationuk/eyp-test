﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Saviour.Domain.Dto;

namespace Saviour.Domain.Interfaces;

public interface ICompanyService
{
    IAsyncEnumerable<CompanyDto> GetCompaniesAsync();

    ValueTask<CompanyDto?> GetCompanyAsync(string companyId);
    
    IAsyncEnumerable<SiteDto> GetSitesForCompanyAsync(string companyId);
    
    ValueTask<SiteDto?> GetSiteAsync(string siteId);
    
    ValueTask<CompanyDto> Create(EditCompanyDto companyData);
    
    /// <summary>
    /// Delete a company
    /// </summary>
    /// <returns>True if deleted, else false</returns>
    /// <remarks>To avoid data loss, the implementation will currently only allow deletion when there are no associated sites</remarks>
    ValueTask<bool> DeleteCompany(string companyId);

    ValueTask<CompanyDto> Update(EditCompanyDto companyData);
}