﻿namespace Saviour.Domain.Interfaces;

public enum WaterType
{
    FreshWater,
    SeaWater
}