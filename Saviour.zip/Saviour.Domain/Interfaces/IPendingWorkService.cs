﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Saviour.Domain.Dto;

namespace Saviour.Domain.Interfaces;

public interface IPendingWorkService
{
    ValueTask<PendingWork> Get();
    IAsyncEnumerable<PerSiteData<ReportSummary>> GetReports(string companyId);
}