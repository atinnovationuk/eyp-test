﻿using System.Collections.Generic;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Interfaces;

public interface IGetBatchesNeedingML
{
    IAsyncEnumerable<Batch> Get();
}