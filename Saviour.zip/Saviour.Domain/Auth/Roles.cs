﻿namespace Saviour.Domain.Auth;

public static class Roles
{
    public const string Analyst = "analyst";
}
