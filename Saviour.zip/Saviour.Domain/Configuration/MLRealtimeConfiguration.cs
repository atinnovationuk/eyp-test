﻿namespace Saviour.Domain.Configuration;

public class MLRealtimeConfiguration
{
    public string Model0EndPoint { get; set; } = string.Empty;
    public string Model0ApiKey { get; set; } = string.Empty;
}
