﻿namespace Saviour.Domain.Configuration;

public class FileStorageConfig
{
    public string ConnectionString { get; set; } = string.Empty;
    public string ShareName { get; set; } = string.Empty;
}
