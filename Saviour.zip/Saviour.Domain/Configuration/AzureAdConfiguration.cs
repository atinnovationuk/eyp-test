﻿namespace Saviour.Domain.Configuration;

public class AzureAdConfiguration
{
    public const string SectionName = "AzureAd";
    
    /// <summary>
    /// The Azure AD instance URI
    /// </summary>
    public string Instance { get; set; } = string.Empty;
    
    /// <summary>
    /// Directory/tenant ID of the Azure App Registration
    /// </summary>
    public string TenantId { get; set; } = string.Empty;
    
    /// <summary>
    /// Application/Client ID of the Azure App Registration
    /// </summary>
    public string ClientId { get; set; } = string.Empty;
    
    /// <summary>
    /// URI of the tenant to authenticate and authorize with. Usually takes the form of https://{uri}/{tenantId}
    /// </summary>
    public string Authority { get; set; } = string.Empty;
    
    /// <summary>
    /// The URI to redirect to after authentication requests.
    /// Must match a 'Redirect URI' defined for a 'Single Page Application' in the App Registration's Authentication section
    /// </summary>
    public string RedirectUri { get; set; } = string.Empty;
}
