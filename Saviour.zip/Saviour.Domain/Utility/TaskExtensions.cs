﻿using System;
using System.Threading.Tasks;

namespace Saviour.Domain.Utility;

public static class TaskExtensions
{
    public static async ValueTask<TReturned> Map<TInput, TReturned>(this ValueTask<TInput> task, Func<TInput, TReturned> map)
    {
        var value = await task.ConfigureAwait(false);
        return map(value);
    }
}