﻿namespace Saviour.Domain.Utility;

public static class ClaimSchemas
{
    public const string ObjectIdentifier = "http://schemas.microsoft.com/identity/claims/objectidentifier";
}