﻿using System;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Dto;

public record ReportSummary(long Id, DateTime CreatedOn)
{
    public static ReportSummary FromReport(Report report)
        => new(report.Id, report.CreatedOn);
}