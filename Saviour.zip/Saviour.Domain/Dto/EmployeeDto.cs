﻿using Saviour.Domain.Validation;

namespace Saviour.Domain.Dto;

public record EmployeeDto(int Id, 
    [RequiredString(Limits.Employees.Name)] string Name,
    [RequiredString(Limits.Employees.LoginIdentity)] string Identity
);