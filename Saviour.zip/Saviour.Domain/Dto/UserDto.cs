﻿using Saviour.Domain.Entities;

namespace Saviour.Domain.Dto;

public record UserDto(int Id, string Name, string AzureId)
{
    public static UserDto FromUser(User user) => new(user.Id, user.Name, user.AzureId);
}