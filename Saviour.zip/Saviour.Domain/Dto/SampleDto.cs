﻿using System;
using System.Collections.Generic;
using System.Linq;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Dto;

public delegate MLResult? SelectMLResult(IEnumerable<MLResult> results);

public record SampleDto(string SampleCode, string Species, WaterType WaterType,
    string Pen, string FishNumber, decimal AverageWeightInGrams, decimal TemperatureInCelsius,
    decimal? OxygenLevelInMg, decimal MortalityRatePercentage, string? Strain,
    ICollection<string> Hatcheries, IDictionary<string, decimal> BiomarkerResults, FishHealthResultType? HealthResult
)
{
    private static StringComparer StringComparer => DtoHelpers.StringComparer;
    private static readonly IEqualityComparer<KeyValuePair<string,decimal>> BiomarkerResultComparer = new BiomarkerDictionaryComparer();

    public static SampleDto FromSample(Sample sample, SelectMLResult selectMLResult)
        => new(sample.SampleCode, sample.Species, sample.WaterType, sample.Pen,
            sample.FishNumber,
            sample.AverageWeightInGrams, sample.TemperatureInCelsius, sample.OxygenLevelInMg, sample.MortalityRatePercentage,
            sample.Strain,
            sample.Hatcheries.Select(h => h.HatcheryCode).ToList(),
            sample.BiomarkerResults
                .GroupBy(r => GetBiomarkerName(r.Biomarker), StringComparer)
                .ToDictionary(
                    group => group.Key,
                    group => group.Select(g => g.Result).First()
                ),
            GetMLResult(sample.FishHealthResults, selectMLResult)?.Result
        );

    private static T? GetMLResult<T>(IEnumerable<T> results, SelectMLResult selectMLResult)
        where T : MLResult
        => selectMLResult(results) as T;

    private static string GetBiomarkerName(Biomarker biomarker)
        => biomarker.Parent is null
            ? biomarker.Name
            : GetBiomarkerName(biomarker.Parent);

    public virtual bool Equals(SampleDto? other)
    {
        if (ReferenceEquals(null, other))
        {
            return false;
        }

        if (ReferenceEquals(this, other))
        {
            return true;
        }

        return SampleCode == other.SampleCode && Species == other.Species && WaterType == other.WaterType
               && Pen == other.Pen && FishNumber == other.FishNumber &&
               AverageWeightInGrams == other.AverageWeightInGrams
               && TemperatureInCelsius == other.TemperatureInCelsius && OxygenLevelInMg == other.OxygenLevelInMg
               && MortalityRatePercentage == other.MortalityRatePercentage && Strain == other.Strain
               && Hatcheries.SequenceEqual(other.Hatcheries, StringComparer)
               && BiomarkerResults.SequenceEqual(other.BiomarkerResults, BiomarkerResultComparer)
               && HealthResult == other.HealthResult;
    }
    
    private class BiomarkerDictionaryComparer : IEqualityComparer<KeyValuePair<string, decimal>>
    {
        public bool Equals(KeyValuePair<string, decimal> x, KeyValuePair<string, decimal> y)
        {
            return StringComparer.Equals(x.Key, y.Key)
                   && x.Value == y.Value;
        }

        public int GetHashCode(KeyValuePair<string, decimal> obj)
        {
            return HashCode.Combine(obj.Key, obj.Value);
        }
    }

    public override int GetHashCode()
    {
        var hashCode = new HashCode();
        hashCode.Add(SampleCode);
        hashCode.Add(Species);
        hashCode.Add((int)WaterType);
        hashCode.Add(Pen);
        hashCode.Add(FishNumber);
        hashCode.Add(AverageWeightInGrams);
        hashCode.Add(TemperatureInCelsius);
        hashCode.Add(OxygenLevelInMg);
        hashCode.Add(MortalityRatePercentage);
        hashCode.Add(Strain);
        hashCode.Add(Hatcheries);
        hashCode.Add(BiomarkerResults);
        hashCode.Add(HealthResult);
        return hashCode.ToHashCode();
    }
}
