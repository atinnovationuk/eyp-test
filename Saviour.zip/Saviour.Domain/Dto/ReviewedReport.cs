﻿using System;
using System.Collections.Generic;
using System.Linq;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Dto;

public record ReviewedReport(long Id, ReportCompanyDto Company, SiteDto Site, DateTime CreatedOn, UserDto CreatedBy, DateTime ReviewedOn, UserDto ReviewedBy, string Observations, 
    int SiteLocalId, ICollection<BatchDto> Batches, ICollection<AnalysisDto> Analyses, string ProcessDeviations)
{
    public static ReviewedReport FromReport(Report report, ICollection<AnalysisDto> analyses)
        => new(report.Id,
            ReportCompanyDto.FromCompany(report.Site.Company), 
            SiteDto.FromSite(report.Site), 
            report.CreatedOn, 
            UserDto.FromUser(report.CreatedBy),
            report.ApprovedOn,
            UserDto.FromUser(report.ReviewedBy ?? throw new InvalidOperationException($"Attempted to construct {nameof(ReviewedReport)} from a non-reviewed report")),
            report.Observations,
            report.SiteLocalId,
            report.Batches.Select(b => BatchDto.FromBatch(b, results => SelectMLResultForReport(report, results))).ToList(),
            analyses,
            report.ProcessDeviations
        );

    private static MLResult? SelectMLResultForReport(Report report, IEnumerable<MLResult> results)
    {
        return results.FirstOrDefault(result => result.Reports.Select(r => r.Id).Contains(report.Id));
    }
}
