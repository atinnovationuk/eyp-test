﻿using System.Collections.Generic;

namespace Saviour.Domain.Dto;

public record BatchFishHealthResultDto(long batchId, Dictionary<string, decimal> penFishHealthResults);