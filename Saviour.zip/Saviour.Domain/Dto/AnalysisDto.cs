﻿using System;
using System.Collections.Generic;
using System.Linq;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Dto;

public record AnalysisDto(int Id, string Name, ICollection<AnalysisBiomarkerDto> Biomarkers)
{
    public static AnalysisDto FromAnalysis(Analysis analysis, ICollection<AnalysisBiomarkerDto> biomarkers)
        => new(analysis.Id, analysis.MethodName, biomarkers);

    public virtual bool Equals(AnalysisDto? other)
    {
        if (ReferenceEquals(null, other)) return false;
        if (ReferenceEquals(this, other)) return true;

        return Id == other.Id && DtoHelpers.StringComparer.Equals(Name, other.Name) &&
               Biomarkers.SequenceEqual(other.Biomarkers);
    }

    public override int GetHashCode()
    {
        var hashCode = new HashCode();
        hashCode.Add(Id);
        hashCode.Add(Name, DtoHelpers.StringComparer);
        hashCode.Add(Biomarkers);
        return hashCode.ToHashCode();
    }
}

public record AnalysisBiomarkerDto(string Name, double Min, double LowRed, double LowAmber, double Reference,
    double HighAmber, double Max)
{
    public static AnalysisBiomarkerDto FromBiomarkerRange(BiomarkerRange range)
        => new(range.Biomarker.Name, range.Min, range.LowRed, range.LowAmber, range.Reference, range.HighAmber,
            range.Max);
}
