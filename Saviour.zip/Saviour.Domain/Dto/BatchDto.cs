﻿using System;
using System.Collections.Generic;
using System.Linq;
using Saviour.Domain.Entities;

namespace Saviour.Domain.Dto;

public record BatchDto(long Id, string BatchNumber, DateOnly DateCollected, DateTime DateAnalysed,DateTime DateReceived, string CompanyId,
    string SiteId,string ConfirmedCondition, string FishHealthHistory, IReadOnlyList<SampleDto> Samples)
{
    public static BatchDto FromBatch(Batch b, SelectMLResult selectMLResult)
        => new(b.Id, b.BatchNumber, b.DateCollected, b.DateAnalysed, b.DateReceived, b.Site.CompanyId, b.Site.Id,
            b.ConfirmedCondition, b.FishHealthHistory, b.Samples.Select(sample => SampleDto.FromSample(sample, selectMLResult)).ToList());

    public virtual bool Equals(BatchDto? other)
    {
        if (ReferenceEquals(null, other)) return false;
        if (ReferenceEquals(this, other)) return true;
        return Id == other.Id 
               && BatchNumber == other.BatchNumber 
               && DateCollected.Equals(other.DateCollected) 
               && DateAnalysed.Equals(other.DateAnalysed) 
               && DateReceived.Equals(other.DateReceived)
               && CompanyId == other.CompanyId
               && SiteId == other.SiteId 
               && FishHealthHistory == other.FishHealthHistory
               && ConfirmedCondition == other.ConfirmedCondition
               && Samples.SequenceEqual(other.Samples);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(Id, BatchNumber, DateCollected, DateAnalysed, CompanyId, SiteId, Samples);
    }
}
