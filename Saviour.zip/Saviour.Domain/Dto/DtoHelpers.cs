﻿using System;

namespace Saviour.Domain.Dto;

public static class DtoHelpers
{
    public static StringComparer StringComparer => StringComparer.InvariantCultureIgnoreCase;
}
