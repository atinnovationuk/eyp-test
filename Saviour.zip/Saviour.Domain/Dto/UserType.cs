﻿namespace Saviour.Domain.Dto;

public enum UserType
{
    WellfishAnalyst,
    Customer
}