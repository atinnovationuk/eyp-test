﻿using System;
using System.Collections.Generic;

namespace Saviour.Domain.Dto;

public record PendingWork(
    ICollection<CompanyAndSiteTree<BatchNeedingReport>> BatchesNeedingReport,
    ICollection<CompanyAndSiteTree<ReportSummary>> ReportsPendingReview
);

public record BatchNeedingReport(long Id, string BatchNumber, int SampleCount, DateOnly DateCollected);
