﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Saviour.Domain.Dto;

public static class CompanyAndSiteSorting
{
    public static IAsyncEnumerable<CompanyAndSiteTree<TOutputData>> SortByCompanyThenSite<TOutputData, TInputData>(
        IAsyncEnumerable<TInputData> inputData, 
        Func<TInputData, CompanyDto> getCompany,
        Func<TInputData, SiteDto> getSite,
        Func<TInputData, TOutputData> createItem
    ) {
        return inputData
            .GroupBy(getCompany, new CompanyNameComparer())
            .SelectAwait(async companyGroup =>
                new CompanyAndSiteTree<TOutputData>(companyGroup.Key,
                    await SortBySite(companyGroup, getSite, createItem)
                        .ToListAsync()
                        .ConfigureAwait(false)
                ));
    }

    public static IAsyncEnumerable<PerSiteData<TOutputData>> SortBySite<TOutputData, TInputData>(
        IAsyncEnumerable<TInputData> data,
        Func<TInputData, SiteDto> getSite,
        Func<TInputData, TOutputData> createItem
    ) {
        return data.GroupBy(getSite, new SiteNameComparer())
            .SelectAwait(async siteGroup => new PerSiteData<TOutputData>(
                siteGroup.Key,
                await siteGroup.Select(createItem).ToListAsync()
                    .ConfigureAwait(false)
            ));
    }

    private class CompanyNameComparer : IEqualityComparer<CompanyDto>
    {
        public bool Equals(CompanyDto? x, CompanyDto? y)
        {
            if (ReferenceEquals(x, y)) return true;
            if (ReferenceEquals(x, null)) return false;
            if (ReferenceEquals(y, null)) return false;

            return x.Name == y.Name;
        }

        public int GetHashCode(CompanyDto obj)
        {
            return obj.Name.GetHashCode();
        }
    }

    private class SiteNameComparer : IEqualityComparer<SiteDto>
    {
        public bool Equals(SiteDto? x, SiteDto? y)
        {
            if (ReferenceEquals(x, y)) return true;
            if (ReferenceEquals(x, null)) return false;
            if (ReferenceEquals(y, null)) return false;
            
            return x.Name == y.Name;
        }

        public int GetHashCode(SiteDto obj)
        {
            return obj.Name.GetHashCode();
        }
    }
}