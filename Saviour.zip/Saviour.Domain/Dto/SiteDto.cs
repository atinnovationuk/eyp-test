﻿using Saviour.Domain.Entities;

namespace Saviour.Domain.Dto;

public record SiteDto(string Id, string Name, string CompanyCode, string CountryCode)
{
    public static SiteDto FromSite(Site site)
        => new(site.Id, site.SiteName, site.CompanyId, site.CountryCode);
}