﻿using Saviour.Domain.Entities;

namespace Saviour.Domain.Dto;

public record CompanyDto(string Id, string Name, string Address, int? SiteCount)
{
    public static CompanyDto FromCompany(Company company)
        => new(company.Id, company.CompanyName, company.Address, company.Sites?.Count);
}