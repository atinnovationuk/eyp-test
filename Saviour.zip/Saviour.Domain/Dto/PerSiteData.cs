﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Saviour.Domain.Dto;

public record PerSiteData<T>(SiteDto Site, ICollection<T> Data)
{
    public virtual bool Equals(PerSiteData<T>? other)
    {
        if (ReferenceEquals(null, other)) return false;
        if (ReferenceEquals(this, other)) return true;
        return Site.Equals(other.Site) && Data.SequenceEqual(other.Data);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(Site, Data);
    }
}
