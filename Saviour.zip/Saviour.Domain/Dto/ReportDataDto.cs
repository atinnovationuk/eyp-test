﻿using System.Collections.Generic;

namespace Saviour.Domain.Dto;

public record ReportDataDto(CompanyDto Company, IReadOnlyList<PerSiteData<ReportSummary>> Reports);