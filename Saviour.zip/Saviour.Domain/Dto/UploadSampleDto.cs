﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Validation;

namespace Saviour.Domain.Dto;

public class UploadSampleDto
{
    [RequiredString(Limits.Samples.Id)]
    public string SampleCode { get; set; } = string.Empty;

    [RequiredString(Limits.Companies.Id)]
    public string CompanyCode { get; init; } = string.Empty;

    [RequiredString(Limits.Companies.Name)]
    public string CompanyName { get; init; } = string.Empty;

    [RequiredString(Limits.Sites.Id)]
    public string SiteCode { get; init; } = string.Empty;
    
    [RequiredString(Limits.Sites.Name)]
    public string SiteName { get; init; } = string.Empty;

    [Required]
    public DateOnly DateCollected { get; init; }

    [Required]
    public DateTime DateAnalysed { get; init; }
    
    [Required]
    public DateTime DateReceived { get; init; }

    [RequiredString(Limits.Samples.Species)]
    public string Species { get; init; } = string.Empty;

    [Required]
    public WaterType WaterType { get; init; }

    [RequiredString(Limits.Batches.BatchNumber)]
    public string BatchNumber { get; init; } = string.Empty;

    [RequiredString(Limits.Samples.Instrument)]
    public string Instrument { get; init; } = string.Empty;

    [RequiredString(Limits.Samples.Pen)]
    public string Pen { get; init; } = string.Empty;

    [RequiredString(Limits.Samples.FishNumber)]
    public string FishNumber { get; init; } = string.Empty;

    [Required]
    public decimal AverageWeightInGrams { get; init; }

    [Required]
    public decimal TemperatureInCelsius { get; init; }

    public decimal? OxygenLevelInMg { get; init; }

    [Required]
    public decimal MortalityRatePercentage { get; init; }

    [MaxLength(Limits.Samples.Strain)]
    public string? Strain { get; init; } = string.Empty;

    [CollectionStringLength(Limits.Hatcheries.Code)]
    public ICollection<string>? Hatcheries { get; set; }

    [Required]
    public ICollection<BiomarkerResultDto> BiomarkerResults { get; init; } = new List<BiomarkerResultDto>();

    [RequiredString(Limits.Countries.Code)]
    public string CountryCode { get; init; } = string.Empty;

    [RequiredString(Limits.Batches.FishHealthHistory)]
    public string FishHealthHistory { get; init; } = string.Empty;
    
    [RequiredString(Limits.Batches.ConfirmedCondition)]
    public string ConfirmedCondition { get; init; } = string.Empty;

    public Sample MapToSample(Batch batch, ICollection<Hatchery> hatcheries,
        ICollection<BiomarkerResult> biomarkerResults)
    {
        return new Sample
        {
            SampleCode = SampleCode,
            Batch = batch,
            Species = Species,
            WaterType = WaterType,
            Pen = Pen,
            FishNumber = FishNumber,
            AverageWeightInGrams = AverageWeightInGrams,
            TemperatureInCelsius = TemperatureInCelsius,
            OxygenLevelInMg = OxygenLevelInMg,
            MortalityRatePercentage = MortalityRatePercentage,
            Strain = Strain,
            Hatcheries = hatcheries,
            BiomarkerResults = biomarkerResults,
            Instrument = Instrument
        };
    }
}