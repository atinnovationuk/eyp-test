using System;
using Saviour.Domain.Validation;

namespace Saviour.Domain.Dto;

public record BiomarkerResultDto(
    [RequiredString(Limits.Biomarkers.Name)] string Biomarker,
    decimal Result)
{
    public virtual bool Equals(BiomarkerResultDto? other)
    {
        if (ReferenceEquals(null, other)) return false;
        if (ReferenceEquals(this, other)) return true;

        return DtoHelpers.StringComparer.Equals(Biomarker, other.Biomarker)
               && Result == other.Result;
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(Biomarker, Result);
    }
}
