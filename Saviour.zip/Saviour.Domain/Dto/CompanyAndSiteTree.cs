﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Saviour.Domain.Dto;

public record CompanyAndSiteTree<T>(CompanyDto Company, ICollection<PerSiteData<T>> SiteData)
{
    public virtual bool Equals(CompanyAndSiteTree<T>? other)
    {
        if (ReferenceEquals(null, other)) return false;
        if (ReferenceEquals(this, other)) return true;
        return Company.Equals(other.Company) && SiteData.SequenceEqual(other.SiteData);
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(Company, SiteData);
    }
}