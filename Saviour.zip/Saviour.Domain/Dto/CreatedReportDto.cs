﻿namespace Saviour.Domain.Dto;

public record CreatedReportDto(long Id);