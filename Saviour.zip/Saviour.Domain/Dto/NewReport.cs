﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Saviour.Domain.Validation;

namespace Saviour.Domain.Dto;

public record NewReport([Required] string Observations, [RequiredString(Limits.Sites.Id)] string SiteId, 
    [RequiredNonEmpty] ICollection<long> BatchIds, [RequiredNonEmpty] ICollection<int> AnalysisIds, string ProcessDeviations);