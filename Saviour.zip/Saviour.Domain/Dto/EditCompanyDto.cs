﻿using Saviour.Domain.Validation;

namespace Saviour.Domain.Dto;

public record EditCompanyDto(
    [RequiredString(Limits.Companies.Id)] string Id,
    [RequiredString(Limits.Companies.Name)] string Name,
    [RequiredString(Limits.Companies.Address)] string Address
);