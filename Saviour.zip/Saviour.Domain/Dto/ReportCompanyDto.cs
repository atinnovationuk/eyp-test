﻿using Saviour.Domain.Entities;

namespace Saviour.Domain.Dto;

public record ReportCompanyDto(string Id, string Name, string Address)
{
    public static ReportCompanyDto FromCompany(Company company) => new(company.Id, company.CompanyName, company.Address);
}