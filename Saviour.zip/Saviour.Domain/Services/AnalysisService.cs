﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class AnalysisService : IAnalysisService
{
    private readonly IRepository<Analysis> _analyses;

    public AnalysisService(IRepository<Analysis> analyses)
    {
        _analyses = analyses;
    }

    public IAsyncEnumerable<AnalysisDto> GetAll(string countryCode) => QueryToAnalyses(_analyses.GetAll(), countryCode);

    public IAsyncEnumerable<AnalysisDto> Get(string countryCode, IEnumerable<int> analysisIds) =>
        QueryToAnalyses(_analyses
                .FindAsync(a => analysisIds.Contains(a.Id)),
            countryCode
        );

    private static IAsyncEnumerable<AnalysisDto> QueryToAnalyses(IQueryable<Analysis> query, string countryCode)
        => query
            .AsNoTracking()
            .Include(a => a.BiomarkerRanges)
            .ThenInclude(b => b.Biomarker)
            .AsAsyncEnumerable()
            .Select(analysis => AnalysisDto.FromAnalysis(analysis, GetBiomarkers(analysis, countryCode).ToList()));

    private static IEnumerable<AnalysisBiomarkerDto> GetBiomarkers(Analysis analysis, string countryCode)
    {
        var groupedRanges = analysis.BiomarkerRanges
            .GroupBy(r => r.Biomarker.Name, DtoHelpers.StringComparer);

        foreach (var group in groupedRanges)
        {
            yield return AnalysisBiomarkerDto.FromBiomarkerRange(GetRange(group.Key, group));
        }

        BiomarkerRange GetRange(string biomarker, IEnumerable<BiomarkerRange> biomarkerRanges)
        {
            BiomarkerRange? defaultRange = null;
            foreach (var range in biomarkerRanges)
            {
                if (DtoHelpers.StringComparer.Equals(range.CountryCode, countryCode))
                {
                    return range;
                }

                if (range.CountryCode is null)
                {
                    defaultRange = range;
                }
            }

            if (defaultRange != null)
            {
                return defaultRange;
            }

            throw new ArgumentException($"Invalid database state: No default ranges defined for Biomarker '{biomarker}'");
        }
    }
}
