﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class MLResultsReader : IMLResultsReader
{
    public IEnumerable<FishHealthResultType> ReadFishHealthResults(Stream resultsStream)
    {
        using var sr = new StreamReader(resultsStream);
        using var reader = new JsonTextReader(sr);
        
        var serializer = new JsonSerializer();

        var results = serializer.Deserialize<double[]>(reader) 
                      ?? throw new InvalidOperationException("Failed to deserialize ML model results");

        return results.Select(r => r.ParseFishHealthResult());
    }
}