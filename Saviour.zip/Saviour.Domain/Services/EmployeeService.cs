using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class EmployeeService : IEmployeeService
{
    private readonly IRepository<Employee> _employees;
    private readonly IUnitOfWork _unitOfWork;

    public EmployeeService(IRepository<Employee> employees, IUnitOfWork unitOfWork)
    {
        _employees = employees;
        _unitOfWork = unitOfWork;
    }

    public IAsyncEnumerable<EmployeeDto> Get(string companyId)
        => _employees.FindAsync(employee => employee.CompanyId == companyId)
            .AsNoTracking()
            .AsAsyncEnumerable()
            .Select(ConvertToDto);

    public async ValueTask<EmployeeDto> Create(string companyId, EmployeeDto employeeData)
    {
        var employee = await _employees.InsertAsync(new Employee
        {
            CompanyId = companyId,
            LoginIdentity = employeeData.Identity,
            Name = employeeData.Name
        }).ConfigureAwait(false);

        await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

        return ConvertToDto(employee);
    }

    public async ValueTask Update(EmployeeDto employeeData)
    {
        var employee = await _employees.GetByIdAsync(employeeData.Id).ConfigureAwait(false);
        if (employee is null)
        {
            throw EntityNotFoundException.Create<Employee>(employeeData.Id);
        }

        employee.Name = employeeData.Name;
        employee.LoginIdentity = employeeData.Identity;

        _employees.Update(employee);
        
        await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);
    }

    public async ValueTask Delete(int employeeId)
    {
        _employees.Delete(new Employee
        {
            Id = employeeId
        });

        await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);
    }

    private static EmployeeDto ConvertToDto(Employee employee) => new(employee.Id, employee.Name, employee.LoginIdentity);
}