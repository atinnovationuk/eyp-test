﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class BatchService : IBatchService
{
    private readonly IRepository<Batch> _batches;

    public BatchService(IRepository<Batch> batches)
    {
        _batches = batches;
    }

    public IAsyncEnumerable<BatchDto> GetBatches(string siteId)
    {
        return _batches
            .FindAsync(batch => batch.SiteId == siteId)
            .AsNoTracking()
            .Include(batch => batch.Site)
            .Include(batch => batch.Samples)
                .ThenInclude(sample => sample.Hatcheries)
            .Include(batch => batch.Samples)
                .ThenInclude(sample => sample.BiomarkerResults)
                    .ThenInclude(biomarkerResult => biomarkerResult.Biomarker)
                        .ThenInclude(biomarker => biomarker.Parent)
            .Include(batch => batch.Samples)
                .ThenInclude(sample => sample.FishHealthResults)
                    .ThenInclude(result => result.Model)
            .AsAsyncEnumerable()
            .Select(batch => BatchDto.FromBatch(batch, results => results.MaxBy(r => r.Model.Version)));
    }
}
