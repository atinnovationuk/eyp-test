﻿using System;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Saviour.Domain.Configuration;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class UpdateMLModelsBackgroundService : BackgroundService
{
    private readonly IServiceProvider _services;
    private readonly Channel<Batch> _batchQueue;
    private readonly ILogger _logger;
    private readonly MLRealtimeConfiguration _configuration;

    public UpdateMLModelsBackgroundService(IServiceProvider services, Channel<Batch> batchQueue,
        ILogger<UpdateMLModelsBackgroundService> logger, IOptions<MLRealtimeConfiguration> configuration)
    {
        _services = services;
        _batchQueue = batchQueue;
        _logger = logger;
        _configuration = configuration.Value;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        if (ConfigurationIsEmpty())
        {
            _logger.LogInformation("ML models disabled - configuration missing");
            return;
        }
        
        await FillQueue();

        while (!stoppingToken.IsCancellationRequested)
        {
            var batch = await _batchQueue.Reader.ReadAsync(stoppingToken);
            
            _logger.LogInformation("Running ML models for batch {BatchId}", batch.Id);

            try
            {
                using var scope = _services.CreateScope();

                var updater = scope.ServiceProvider.GetRequiredService<IRunMLModels>();

                await updater.Run(MLModelType.FishHealth, batch)
                    .ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception raised running background task for batch {BatchId}", batch.Id);
            }
            
            _logger.LogInformation("ML models completed for batch {BatchId}", batch.Id);
        }
    }

    private async Task FillQueue()
    {
        using var scope = _services.CreateScope();

        var getBatches = scope.ServiceProvider.GetRequiredService<IGetBatchesNeedingML>();
        
        await foreach (var batch in getBatches.Get()
                           .ConfigureAwait(false))
        {
            await _batchQueue.Writer.WriteAsync(batch)
                .ConfigureAwait(false);
        }
    }

    private bool ConfigurationIsEmpty()
    {
        return string.IsNullOrWhiteSpace(_configuration.Model0ApiKey)
               || string.IsNullOrWhiteSpace(_configuration.Model0EndPoint);
    }
}
