﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class SampleService : ISampleService
{
    private readonly IRepository<Sample> _samples;
    private readonly IRepository<Company> _companies;
    private readonly IRepository<Batch> _batches;
    private readonly IRepository<Site> _sites;
    private readonly IRepository<Country> _countries;
    private readonly IRepository<Biomarker> _biomarkers;
    private readonly IRepository<Hatchery> _hatcheries;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IBatchListener _batchListener;

    public SampleService(IRepository<Sample> samples, IRepository<Company> companies, IRepository<Site> sites, 
        IRepository<Batch> batches, IRepository<Country> countries, IRepository<Biomarker> biomarkers, IRepository<Hatchery> hatcheries,
        IUnitOfWork unitOfWork, IBatchListener batchListener)
    {
        _samples = samples;
        _companies = companies;
        _sites = sites;
        _batches = batches;
        _countries = countries;
        _biomarkers = biomarkers;
        _hatcheries = hatcheries;
        _unitOfWork = unitOfWork;
        _batchListener = batchListener;
    }

    public async Task AddSampleAsync(UploadSampleDto sample)
    {
        using var transaction = await _unitOfWork.BeginTransaction()
            .ConfigureAwait(false);

        var hatcheries = await FindOrCreateHatcheries(sample.Hatcheries)
            .ToListAsync()
            .ConfigureAwait(false);

        var biomarkerResults = await CreateBiomarkerResults(sample.BiomarkerResults)
            .ToListAsync()
            .ConfigureAwait(false);

        var batch = await _batches.FindOrCreateAsync(
            () => _batches.FindAsync(batch => batch.BatchNumber == sample.BatchNumber)
                .Include(b => b.Site)
                .ThenInclude(s => s.Company)
                .FirstOrDefaultAsync(),
            () => CreateBatch(sample)
        ).ConfigureAwait(false);

        var sampleEntity = sample.MapToSample(batch, hatcheries, biomarkerResults);

        await _samples.InsertAsync(sampleEntity).ConfigureAwait(false);

        await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

        await transaction.Commit().ConfigureAwait(false);

        await _batchListener.OnBatchUpdated(batch);
    }

    private async Task<Batch> CreateBatch(UploadSampleDto sample)
    {
        var country = await _countries.FindByIdOrCreateAsync(sample.CountryCode, () => new Country
        {
            Code = sample.CountryCode
        }).ConfigureAwait(false);
        
        var company = await _companies.FindByIdOrCreateAsync(sample.CompanyCode, () => new Company
        {
            Id = sample.CompanyCode,
            CompanyName = sample.CompanyName
        }).ConfigureAwait(false);

        var site = await _sites.FindByIdOrCreateAsync(sample.SiteCode, () => new Site
        {
            Id = sample.SiteCode,
            Company = company,
            SiteName = sample.SiteName,
            Country = country
        }).ConfigureAwait(false);

        return new Batch
        {
            BatchNumber = sample.BatchNumber,
            Site = site,
            DateCollected = sample.DateCollected,
            DateReceived = DateTime.SpecifyKind(sample.DateReceived, DateTimeKind.Utc),
            DateAnalysed = DateTime.SpecifyKind(sample.DateAnalysed, DateTimeKind.Utc), // trust that the uploaded time is UTC
            FishHealthHistory = sample.FishHealthHistory.Replace("\r", "").Replace("\n", " "),
            ConfirmedCondition = sample.ConfirmedCondition.Replace("\r", "").Replace("\n", " ")
        };
    }

    private async IAsyncEnumerable<Hatchery> FindOrCreateHatcheries(ICollection<string>? hatcheries)
    {
        if (hatcheries == null || hatcheries.Count == 0)
        {
            yield break;
        }

        foreach (var hatcheryCode in hatcheries.Distinct())
        {
            var hatchery = await _hatcheries.FindOrCreateAsync(
                () => _hatcheries.FindAsync(h => h.HatcheryCode == hatcheryCode).FirstOrDefaultAsync(),
                () => new Hatchery
                {
                    HatcheryCode = hatcheryCode
                }).ConfigureAwait(false);

            yield return hatchery;
        }
    }

    private async IAsyncEnumerable<BiomarkerResult> CreateBiomarkerResults(ICollection<BiomarkerResultDto> results)
    {
        var biomarkers = await GetOrInsertBiomarkers(results);
        
        foreach (var (bioMarkerName, result) in results)
        {
            var biomarker = biomarkers[bioMarkerName];

            yield return new BiomarkerResult
            {
                Biomarker = biomarker,
                Result = result
            };
        }
    }

    private async ValueTask<IReadOnlyDictionary<string, Biomarker>> GetOrInsertBiomarkers(IEnumerable<BiomarkerResultDto> results)
    {
        /* NB: This method is a subtle optimisation
         * Most of the time all necessary biomarkers will be present, so we don't need to lock the table for inserts
         * However, as there will be many biomarkers per sample this becomes a notable cost
         * Thus we only resort to calling 'FindOrCreateAsync' when any are missing
         */

        var allBiomarkers = results.Select(r =>
                FormatBiomarkerName(r.Biomarker)
            )
            .ToHashSet();

        var nameToBiomarker = await _biomarkers.FindAsync(biomarker => allBiomarkers.Contains(biomarker.Name))
            .ToDictionaryAsync(
                biomarker => FormatBiomarkerName(biomarker.Name),
                biomarker => biomarker,
                StringComparer.InvariantCultureIgnoreCase
            ).ConfigureAwait(false);
        
        allBiomarkers.ExceptWith(nameToBiomarker.Keys);
        
        await CreateMissingBiomarkers(allBiomarkers).ConfigureAwait(false);

        return nameToBiomarker;

        static string FormatBiomarkerName(string name) => name.ToUpperInvariant();

        async Task CreateMissingBiomarkers(IEnumerable<string> missingBiomarkers)
        {
            foreach (var missingBiomarker in missingBiomarkers)
            {
                var biomarker = await _biomarkers.FindOrCreateAsync(
                    () => _biomarkers.FindAsync(b => b.Name == missingBiomarker).FirstOrDefaultAsync(),
                    () => new Biomarker { Name = missingBiomarker }).ConfigureAwait(false);

                nameToBiomarker.Add(missingBiomarker, biomarker);
            }
        }
    }
}
