﻿using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class DevReportStorage : IReportStorage
{
    private readonly IWebHostEnvironment _env;

    public DevReportStorage(IWebHostEnvironment env)
    {
        _env = env;
    }

    private string GetDirectory(ReportData report) => Path.Combine(
        _env.WebRootPath,
        "Reports",
        report.Site.CompanyId,
        report.SiteId
    );

    private string GetFilePath(ReportData report) => Path.Combine(
        GetDirectory(report),
        $"Report{report.SiteLocalId}.pdf"
    );

    public async ValueTask Save(Stream reportData, Report report)
    {
        Directory.CreateDirectory(GetDirectory(report));
        
        await using var file = File.Create(GetFilePath(report));

        await reportData.CopyToAsync(file);
    }

    public ValueTask<Stream> Get(Report report)
    {
        return ValueTask.FromResult<Stream>(File.OpenRead(GetFilePath(report)));
    }
}