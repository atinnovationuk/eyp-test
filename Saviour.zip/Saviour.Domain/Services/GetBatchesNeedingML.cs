﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class GetBatchesNeedingML : IGetBatchesNeedingML
{
    private readonly IRepository<Batch> _batches;
    private readonly IGetMLModel _getMLModel;

    public GetBatchesNeedingML(IRepository<Batch> batches, IGetMLModel getMLModel)
    {
        _batches = batches;
        _getMLModel = getMLModel;
    }

    public IAsyncEnumerable<Batch> Get()
    {
        var latestModelId = _getMLModel.GetLatest(MLModelType.FishHealth).Id;

        return _batches
            .FindAsync(batch => batch.Samples.Any(sample => sample.FishHealthResults.FirstOrDefault(result => result.ModelId == latestModelId) == null))
            .AsAsyncEnumerable();
    }
}