﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class GetMLInputs : IGetMLInputs
{
    private readonly IRepository<MLBiomarker> _mlBiomarkers;

    public GetMLInputs(IRepository<MLBiomarker> mlBiomarkers)
    {
        _mlBiomarkers = mlBiomarkers;
    }

    public async ValueTask<MLInputData> Get(MLModel model, IQueryable<Sample> samples)
    {
        var biomarkers = _mlBiomarkers.FindAsync(b => b.ModelType == model.Type);

        var validSamples = samples
            .Include(s => s.BiomarkerResults)
            .ThenInclude(r => r.Biomarker)
            .ThenInclude(b => b.Parent)
            .Where(sample =>
                biomarkers.All(biomarker => sample.BiomarkerResults.Any(
                    result => result.BioMarkerId == biomarker.BiomarkerId
                              || biomarker.Biomarker.Children.Any(child => result.BioMarkerId == child.Id))
                )
            ).Select(sample =>
                new MLSampleData(sample.Id,
                    sample.BiomarkerResults.Select(result =>
                        new BiomarkerResultOnly(result.Biomarker.ParentId ?? result.BioMarkerId, result.Result)
                    ).ToList())
            );

        return new MLInputData(
            model,
            await validSamples.ToListAsync().ConfigureAwait(false),
            // NB: The use of SortOrder here is only necessary as the live ML model does not have an explicit signature
            // - meaning that inputs must perfectly align with the order used to generate the model.
            // We hope that this setup will go away with future ML models
            await biomarkers.OrderBy(b => b.SortOrder).ToListAsync().ConfigureAwait(false)
        );
    }

}
