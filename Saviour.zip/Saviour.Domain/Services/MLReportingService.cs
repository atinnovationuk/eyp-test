﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class MLReportingService : IMLReportingService
{
    private readonly IRepository<Sample> _samples;
    private readonly IRepository<FishHealthResult> _fishHealth;
    private readonly IRepository<ReportedFishHealthResult> _reportedFishHealth;

    public MLReportingService(IRepository<Sample> samples, IRepository<FishHealthResult> fishHealth,
        IRepository<ReportedFishHealthResult> reportedFishHealth)
    {
        _samples = samples;
        _fishHealth = fishHealth;
        _reportedFishHealth = reportedFishHealth;
    }

    public async ValueTask OnCreated(DraftReport draftReport)
    {
        var batches = draftReport.Batches.Select(b => b.Id).ToList();
        var sampleIds = _samples.FindAsync(s => batches.Contains(s.BatchId))
            .AsNoTracking()
            .Select(s => s.Id);

        var associatedResults = _fishHealth.FindAsync(
                result => sampleIds.Contains(result.SampleId)
            )
            .AsNoTracking()
            .Select(r => r.Id);

        await foreach (var resultId in associatedResults.AsAsyncEnumerable().ConfigureAwait(false))
        {
            await _reportedFishHealth.InsertAsync(new ReportedFishHealthResult
            {
                DraftReport = draftReport,
                MLResultId = resultId
            }).ConfigureAwait(false);
        }
    }

    public async ValueTask OnApproved(DraftReport draftReport, Report report)
    {
        var results = _reportedFishHealth
            .FindAsync(r => r.DraftReportId == draftReport.Id);
        await foreach (var result in results.AsAsyncEnumerable().ConfigureAwait(false))
        {
            result.DraftReportId = null;
            result.Report = report;
            _reportedFishHealth.Update(result);
        }
    }
}
