﻿using System;
using System.Linq;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class GetMLModel : IGetMLModel
{
    private readonly IRepository<MLModel> _mlModels;

    public GetMLModel(IRepository<MLModel> mlModels)
    {
        _mlModels = mlModels;
    }

    public MLModel GetLatest(MLModelType modelType)
    {
        return _mlModels.FindAsync(m => m.Type == modelType)
                   .OrderByDescending(m => m.Version)
                   .FirstOrDefault()
               ?? throw new InvalidOperationException($"No ML Model found for type {modelType}");
    }
}