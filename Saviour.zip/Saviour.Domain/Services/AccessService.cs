﻿using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class AccessService : IAccessService
{
    private readonly IUserTypeService _userTypeService;
    private readonly IRepository<Employee> _employees;

    public AccessService(IUserTypeService userTypeService, IRepository<Employee> employees)
    {
        _userTypeService = userTypeService;
        _employees = employees;
    }

    public ValueTask<bool> CanAccessCompanyData(ClaimsPrincipal user, string companyId)
    {
        var userType = _userTypeService.Get(user);
        return userType == UserType.WellfishAnalyst
            ? ValueTask.FromResult(true)
            : UserIsEmployeeOfCompany(companyId, user);
    }

    private async ValueTask<bool> UserIsEmployeeOfCompany(string companyId, ClaimsPrincipal user)
    {
        var userPrincipalName = user.FindFirst(ClaimTypes.Upn) ?? throw new InvalidUserException("Missing UserPrincipalName (UPN)");

        var loginIdentity = userPrincipalName.Value;
        
        return await _employees.FindAsync(
                employee => employee.CompanyId == companyId
                && employee.LoginIdentity == loginIdentity
            )
            .AnyAsync()
            .ConfigureAwait(false);
    }
}
