﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class CompanyService : ICompanyService
{
    private readonly IRepository<Company> _companyRepository;
    private readonly IRepository<Site> _siteRepository;
    private readonly IUnitOfWork _unitOfWork;

    public CompanyService(IRepository<Company> companyRepository, IRepository<Site> siteRepository, IUnitOfWork unitOfWork)
    {
        _companyRepository = companyRepository;
        _siteRepository = siteRepository;
        _unitOfWork = unitOfWork;
    }

    public IAsyncEnumerable<CompanyDto> GetCompaniesAsync()
    {
        return _companyRepository.GetAll()
            .AsNoTracking()
            .Select(company => new CompanyDto(company.Id, company.CompanyName, company.Address, company.Sites.Count))
            .AsAsyncEnumerable();
    }

    public async ValueTask<CompanyDto?> GetCompanyAsync(string companyId)
    {
        var company = await _companyRepository.GetByIdAsync(companyId).ConfigureAwait(false);

        return company is null
            ? null
            : CompanyDto.FromCompany(company);
    }

    public IAsyncEnumerable<SiteDto> GetSitesForCompanyAsync(string companyId)
    {
        return _siteRepository
            .GetAll()
            .Where(x => x.CompanyId == companyId)
            .AsNoTracking()
            .AsAsyncEnumerable()
            .Select(SiteDto.FromSite);
    }

    public async ValueTask<SiteDto?> GetSiteAsync(string siteId)
    {
        var site = await _siteRepository.GetByIdAsync(siteId).ConfigureAwait(false);

        return site is null
            ? null
            : SiteDto.FromSite(site);
    }

    public async ValueTask<CompanyDto> Create(EditCompanyDto companyData)
    {
        var createdCompany = await _companyRepository.InsertAsync(new Company
        {
            Id = companyData.Id,
            CompanyName = companyData.Name,
            Address = companyData.Address
        }).ConfigureAwait(false);
        
        await _unitOfWork.SaveChangesAsync()
            .ConfigureAwait(false);

        return CompanyDto.FromCompany(createdCompany);
    }

    public async ValueTask<bool> DeleteCompany(string companyId)
    {
        var company = await _companyRepository.FindAsync(company => company.Id == companyId
            && !company.Sites.Any())
            .FirstOrDefaultAsync();
        if (company is null)
        {
            return false;
        }

        _companyRepository.Delete(company);
        await _unitOfWork.SaveChangesAsync()
            .ConfigureAwait(false);
        return true;
    }

    public async ValueTask<CompanyDto> Update(EditCompanyDto companyData)
    {
        var company = await _companyRepository.GetByIdAsync(companyData.Id).ConfigureAwait(false);
        if (company is null)
        {
            throw EntityNotFoundException.Create<Company>(companyData.Id);
        }

        company.CompanyName = companyData.Name;
        company.Address = companyData.Address;

        _companyRepository.Update(company);
        
        await _unitOfWork.SaveChangesAsync()
            .ConfigureAwait(false);

        return CompanyDto.FromCompany(company);
    }
}
