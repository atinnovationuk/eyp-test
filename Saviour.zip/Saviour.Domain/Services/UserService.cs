﻿using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Utility;

namespace Saviour.Domain.Services;

public class UserService : IUserService
{
    private readonly IRepository<User> _users;

    public UserService(IRepository<User> users)
    {
        _users = users;
    }

    public ValueTask<User> FindOrCreate(ClaimsPrincipal userIdentity)
    {
        var name = GetName(userIdentity);
        var azureId = GetAzureId(userIdentity);

        return _users.FindOrCreateAsync(
            () => _users.FindAsync(u => u.AzureId == azureId).FirstOrDefaultAsync(),
            () => new User
            {
                Name = name,
                AzureId = azureId
            });
    }

    public async ValueTask<User> Find(int userId)
    {
        var entity = await _users.FindAsync(u => u.Id == userId)
            .FirstOrDefaultAsync();
        if (entity is null)
        {
            throw EntityNotFoundException.Create<User>(userId);
        }

        return entity;
    }

    private static string GetAzureId(ClaimsPrincipal user)
    {
        var claim = user.FindFirst(ClaimSchemas.ObjectIdentifier);
        return claim?.Value ?? throw new InvalidUserException("Missing Object Identifier (OID)");
    }

    private static string GetName(ClaimsPrincipal user)
        => user.FindFirst("name")?.Value 
           ?? user.Identity?.Name
           ?? throw new InvalidUserException("Missing name");

}