﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class FishHealthResultsService : IFishHealthResultsService
{
    private readonly IRepository<FishHealthResult> _fishHealth;
    
    public FishHealthResultsService(IRepository<FishHealthResult> fishHealth)
    {
        _fishHealth = fishHealth;
    }
    
    public async Task<IEnumerable<BatchFishHealthResultDto>> GetPenFishHealthResults(string siteId)
    {
        return (await _fishHealth
                .FindAsync(result => result.Sample.Batch.SiteId == siteId)
                .Include(result => result.Sample)
                .GroupBy(result => result.Sample.Batch.Id)
                .ToListAsync())
                .Select(group => new BatchFishHealthResultDto(group.Key, group.GroupBy(x => x.Sample.Pen)
                .ToDictionary(x => x.Key, innerGroup => 
                    Math.Round((decimal)innerGroup.Count(y => y.Result == FishHealthResultType.Healthy) / innerGroup.Count() * 100, 2))));
    }
}