﻿using System.Collections.Generic;
using System.Linq;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class PrepareMLInputs : IPrepareMLInputs
{
    public IEnumerable<SampleResults> GetInputs(MLInputData inputData)
    {
        var (_, samples, mlBiomarkers) = inputData;
        
        foreach (var sample in samples)
        {
            var results = mlBiomarkers
                .Select(biomarker => new
                {
                    biomarker,
                    result = sample.BiomarkerResults.First(r => r.BioMarkerId == biomarker.BiomarkerId)
                })
                .Select(t => Normalise(t.biomarker, t.result.Result))
                .ToArray();

            yield return new SampleResults(results);
        }
    }
    
    private static decimal Normalise(MLBiomarker biomarker, decimal result)
    {
        return (result - biomarker.Min) / (biomarker.Max - biomarker.Min);
    }
}