﻿using System.Linq;
using System.Threading.Tasks;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class RunMLModels : IRunMLModels
{
    private readonly IMLModelService _modelService;
    private readonly IGetMLInputs _getMlInputs;
    private readonly IRepository<Sample> _samplesRepository;
    private readonly IRepository<FishHealthResult> _fishHealthResults;
    private readonly IGetMLModel _getMLModel;

    public RunMLModels(IMLModelService modelService, IGetMLInputs getMlInputs, IRepository<Sample> samplesRepository,
        IRepository<FishHealthResult> fishHealthResults, IGetMLModel getMLModel)
    {
        _modelService = modelService;
        _getMlInputs = getMlInputs;
        _samplesRepository = samplesRepository;
        _fishHealthResults = fishHealthResults;
        _getMLModel = getMLModel;
    }

    public async Task Run(MLModelType modelType, Batch batch)
    {
        var batchId = batch.Id;

        var model = _getMLModel.GetLatest(modelType);
        var modelId = model.Id;

        var sampleIdsWithResults = _fishHealthResults
            .FindAsync(r => r.ModelId == modelId)
            .Select(r => r.SampleId);

        var samples = _samplesRepository.FindAsync(
                sample => sample.BatchId == batchId
            )
            .Where(sample => !sampleIdsWithResults.Contains(sample.Id));
        
        var inputData = await _getMlInputs.Get(model, samples)
            .ConfigureAwait(false);

        if (inputData.IsEmpty)
        {
            return;
        }

        await _modelService.Run(inputData)
            .ConfigureAwait(false);
    }
}
