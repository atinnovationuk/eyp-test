﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Saviour.Domain.Configuration;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class MLModelService : IMLModelService
{
    private readonly IMLRealtimeRequest _mlRealtimeRequest;
    private readonly IMLResultsHandler _mlResultsHandler;
    private readonly MLRealtimeConfiguration _configuration;
    private readonly IHttpClientFactory _httpClientFactory;

    public MLModelService(IMLRealtimeRequest mlRealtimeRequest, IMLResultsHandler mlResultsHandler,
        IOptionsSnapshot<MLRealtimeConfiguration> configuration, IHttpClientFactory httpClientFactory)
    {
        _mlRealtimeRequest = mlRealtimeRequest;
        _mlResultsHandler = mlResultsHandler;
        _httpClientFactory = httpClientFactory;
        _configuration = configuration.Value;
    }

    public async ValueTask Run(MLInputData inputData)
    {
        var model = inputData.Model;
        var modelType = model.Type;

        using var client = GetHttpClient(modelType);
        
        var result = await _mlRealtimeRequest.Post(client, new Uri(GetEndpoint(modelType)), inputData);

        await _mlResultsHandler.InsertResults(model, inputData.Samples, result);
    }

    private HttpClient GetHttpClient(MLModelType modelType)
    {
        var client = _httpClientFactory.CreateClient();

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", GetApiKey(modelType));

        return client;
    }

    private string GetApiKey(MLModelType modelType)
    {
        return modelType switch
        {
            MLModelType.FishHealth => _configuration.Model0ApiKey,
            _ => throw new ArgumentOutOfRangeException(nameof(modelType), modelType, null)
        };
    }

    private string GetEndpoint(MLModelType modelType) =>
        modelType switch
        {
            MLModelType.FishHealth => _configuration.Model0EndPoint,
            _ => throw new ArgumentOutOfRangeException(nameof(modelType), modelType, null)
        };
}