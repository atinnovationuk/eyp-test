﻿using System.IO;
using System.Threading.Tasks;
using System.Web;
using Azure.Storage.Files.Shares;
using Microsoft.Extensions.Options;
using Saviour.Domain.Configuration;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class ReportStorageService : IReportStorage
{
    private readonly FileStorageConfig _config;

    public ReportStorageService(IOptions<FileStorageConfig> config)
    {
        _config = config.Value;
    }

    public async ValueTask Save(Stream reportData, Report report)
    {
        GetDirectories(report, out var companyDir, out var siteDir);

        await companyDir.CreateIfNotExistsAsync();
        await siteDir.CreateIfNotExistsAsync();

        var file = GetFileClient(report, siteDir);
        await file.CreateAsync(reportData.Length);

        await file.UploadAsync(reportData);
    }

    public async ValueTask<Stream> Get(Report report)
    {
        GetDirectories(report, out _, out var directory);
        var file = GetFileClient(report, directory);

        var fileContent = await file.DownloadAsync();
        if (fileContent is null)
        {
            throw new FileNotFoundException();
        }

        return fileContent.Value.Content;
    }

    private static ShareFileClient GetFileClient(ReportData report, ShareDirectoryClient siteDir)
    {
        return siteDir.GetFileClient($"Report-{report.SiteLocalId}.pdf");
    }

    private void GetDirectories(ReportData report, out ShareDirectoryClient companyDir, out ShareDirectoryClient siteDir)
    {
        var share = new ShareClient(_config.ConnectionString, _config.ShareName);
        
        companyDir = share.GetDirectoryClient(Encode(report.Site.CompanyId));

        siteDir = companyDir.GetSubdirectoryClient(Encode(report.Site.Id));
    }

    private static string Encode(string component) => HttpUtility.UrlEncode(component);
}
