using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class UserDataService : IUserDataService
{
    private readonly IRepository<Employee> _employees;
    private readonly IRepository<Report> _reports;

    public UserDataService(IRepository<Employee> employees, IRepository<Report> reports)
    {
        _employees = employees;
        _reports = reports;
    }

    public async ValueTask<CompanyDto?> TryGetCompany(ClaimsPrincipal user)
    {
        var identity = user.Identity?.Name;
        if (identity is null)
        {
            return null;
        }

        var employee = await _employees.FindAsync(employee => employee.LoginIdentity == identity)
            .Include(e => e.Company)
            .AsNoTracking()
            .FirstOrDefaultAsync()
            .ConfigureAwait(false);

        return employee is null 
            ? null
            : CompanyDto.FromCompany(employee.Company);
    }

    public IAsyncEnumerable<PerSiteData<ReportSummary>> GetReports(string companyId)
    {
        var reports = _reports.FindAsync(report =>
                report.Site.CompanyId == companyId
            )
            .Include(report => report.Site)
            .AsNoTracking()
            .AsAsyncEnumerable();

        return CompanyAndSiteSorting.SortBySite(
            reports,
            report => SiteDto.FromSite(report.Site), 
            ReportSummary.FromReport
        );
    }
}
