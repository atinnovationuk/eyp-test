﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class MLResultsHandler : IMLResultsHandler
{
    private readonly IRepository<FishHealthResult> _fishHealthResults;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMLResultsReader _resultsReader;

    public MLResultsHandler(IRepository<FishHealthResult> fishHealthResults, IUnitOfWork unitOfWork, IMLResultsReader resultsReader)
    {
        _fishHealthResults = fishHealthResults;
        _unitOfWork = unitOfWork;
        _resultsReader = resultsReader;
    }

    public ValueTask InsertResults(MLModel model, IReadOnlyList<MLSampleData> samples, Stream resultsStream)
    {
        return model.Type switch
        {
            MLModelType.FishHealth => HandleFishHealthResults(model, samples, resultsStream),
            _ => throw new ArgumentOutOfRangeException(nameof(model), model.Type, null)
        };
    }

    private async ValueTask HandleFishHealthResults(MLModel model, IReadOnlyList<MLSampleData> samples,
        Stream resultsStream)
    {
        var results = _resultsReader.ReadFishHealthResults(resultsStream)
            .ToList();

        var time = DateTime.UtcNow;
        for (var i = 0; i < samples.Count; i++)
        {
            var sample = samples[i];
            var result = results[i];

            await _fishHealthResults.InsertAsync(new FishHealthResult
            {
                CreatedOn = time,
                SampleId = sample.Id,
                Result = result,
                Model = model
            }).ConfigureAwait(false);
        }
        
        await _unitOfWork.SaveChangesAsync()
            .ConfigureAwait(false);
    }
}
