﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class PendingWorkService : IPendingWorkService
{
    private readonly IRepository<Batch> _batches;
    private readonly IRepository<DraftReport> _draftReports;

    public PendingWorkService(IRepository<DraftReport> draftReports, IRepository<Batch> batches)
    {
        _draftReports = draftReports;
        _batches = batches;
    }

    public async ValueTask<PendingWork> Get()
    {
        return new PendingWork(
            await GetUnreportedBatches().ToListAsync()
                .ConfigureAwait(false),
            await GetReportsNeedingReview().ToListAsync()
                .ConfigureAwait(false)
        );
    }

    private record SiteReport(long Id, SiteDto Site, DateTime CreatedOn);

    public IAsyncEnumerable<PerSiteData<ReportSummary>> GetReports(string companyId)
    {
        var reports = _draftReports.FindAsync(report => report.Site.CompanyId == companyId)
            .AsNoTracking()
            .Select(report => new SiteReport(report.Id, SiteDto.FromSite(report.Site), report.CreatedOn))
            .AsAsyncEnumerable();

        return CompanyAndSiteSorting.SortBySite(
            reports,
            item => item.Site,
            item => new ReportSummary(item.Id, item.CreatedOn)
        );
    }

    private record BatchData(CompanyDto Company, SiteDto Site, long BatchId, string BatchNumber, int SampleCount, DateOnly DateCollected);

    private IAsyncEnumerable<CompanyAndSiteTree<BatchNeedingReport>> GetUnreportedBatches()
    {
        var batches = _batches.GetAll()
            .AsNoTracking()
            .Where(b => !b.Reports.Any())
            .Select(b => new BatchData(CompanyDto.FromCompany(b.Site.Company), SiteDto.FromSite(b.Site), b.Id, 
                b.BatchNumber, b.Samples.Count, b.DateCollected))
            .AsAsyncEnumerable();
        
        return CompanyAndSiteSorting.SortByCompanyThenSite(batches, batchData => batchData.Company, 
            batchData => batchData.Site,
            batchData => new BatchNeedingReport(batchData.BatchId, batchData.BatchNumber, batchData.SampleCount, batchData.DateCollected));
    }

    private record ReportData(CompanyDto Company, SiteDto Site, long ReportId, DateTime CreatedOn);

    private IAsyncEnumerable<CompanyAndSiteTree<ReportSummary>> GetReportsNeedingReview()
    {
        var reports = _draftReports.GetAll()
            .AsNoTracking()
            .Select(report => new ReportData(CompanyDto.FromCompany(report.Site.Company), 
                SiteDto.FromSite(report.Site),
                report.Id, report.CreatedOn))
            .AsAsyncEnumerable();

        return CompanyAndSiteSorting.SortByCompanyThenSite(reports, reportData => reportData.Company, 
            reportData => reportData.Site,
            reportData => new ReportSummary(reportData.ReportId, reportData.CreatedOn));
    }
}
