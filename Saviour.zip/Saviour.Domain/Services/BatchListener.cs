﻿using System.Threading.Channels;
using System.Threading.Tasks;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class BatchListener : IBatchListener
{
    private readonly Channel<Batch> _batchQueue;

    public BatchListener(Channel<Batch> batchQueue)
    {
        _batchQueue = batchQueue;
    }

    public ValueTask OnBatchUpdated(Batch batch)
    {
        return _batchQueue.Writer.WriteAsync(batch);
    }
}
