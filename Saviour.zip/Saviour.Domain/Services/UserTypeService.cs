﻿using System;
using System.Security.Claims;
using Microsoft.Extensions.Options;
using Microsoft.Identity.Web;
using Saviour.Domain.Auth;
using Saviour.Domain.Configuration;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class UserTypeService : IUserTypeService
{
    private readonly IOptionsSnapshot<AzureAdConfiguration> _azureAdConfig;

    public UserTypeService(IOptionsSnapshot<AzureAdConfiguration> azureAdConfig)
    {
        _azureAdConfig = azureAdConfig;
    }

    public UserType Get(ClaimsPrincipal user)
    {
        var userTenantId = user.GetTenantId();
        if (userTenantId is null || IsCustomerTenant(userTenantId))
        {
            return UserType.Customer;
        }

        return user.IsInRole(Roles.Analyst)
            ? UserType.WellfishAnalyst
            : UserType.Customer;
    }

    private bool IsCustomerTenant(string userTenantId)
    {
        var saviourTenant = _azureAdConfig.Value.TenantId;

        return !StringComparer.InvariantCultureIgnoreCase.Equals(saviourTenant, userTenantId);
    }
}
