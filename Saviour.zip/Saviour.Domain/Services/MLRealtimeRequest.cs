﻿using System;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;


public class MLRealtimeRequest : IMLRealtimeRequest
{
    private readonly IPrepareMLInputs _prepareMLInputs;
    private readonly ILogger _logger;

    public MLRealtimeRequest(ILogger<MLRealtimeRequest> logger, IPrepareMLInputs prepareMLInputs)
    {
        _logger = logger;
        _prepareMLInputs = prepareMLInputs;
    }

    public async ValueTask<Stream> Post(HttpClient client, Uri endPoint, MLInputData inputData)
    {
        var httpContent = GetRequestContent(inputData);

        var response = await client.PostAsync(endPoint, httpContent)
            .ConfigureAwait(false);
        if (!response.IsSuccessStatusCode)
        {
            var reason = await response.Content.ReadAsStringAsync();
            _logger.LogError("ML Realtime request failed with code {ResponseStatusCode}: {Reason}", response.StatusCode, reason);
            throw new Exception("ML Realtime request failed");
        }

        return await response.Content.ReadAsStreamAsync();
    }

    private HttpContent GetRequestContent(MLInputData inputData)
    {
        var requestData = GetRequestData(inputData);

        var json = JsonConvert.SerializeObject(requestData, Formatting.None);

        return new StringContent(json, Encoding.UTF8, "application/json");
    }

    private RequestData GetRequestData(MLInputData inputData)
    {
        var inputs = _prepareMLInputs.GetInputs(inputData);

        return new RequestData(new InputData(
            inputData.Biomarkers.Select(b => b.Name).ToArray(),
            inputData.Samples.Select((_, i) => $"Input {i}").ToArray(),
            inputs.Select(results => results.Results).ToArray()
        ));
    }

    private class RequestData
    {
        public RequestData(InputData inputData)
        {
            InputData = inputData;
        }

        [JsonProperty("input_data")]
        public InputData InputData { get; }
    }

    private class InputData
    {
        public InputData(string[] columns, string[] index, decimal[][] data)
        {
            Columns = columns;
            Index = index;
            Data = data;
        }

        /// <summary>
        /// Order of input data columns
        /// </summary>
        [JsonProperty("columns")]
        public string[] Columns { get; }
        /// <summary>
        /// Order of input datasets
        /// </summary>
        [JsonProperty("index")]
        public string[] Index { get; }
        /// <summary>
        /// Input data
        /// </summary>
        [JsonProperty("data")]
        public decimal[][] Data { get; }
    }
}
