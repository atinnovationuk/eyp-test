﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Services;

public class ReportService : IReportService
{
    private readonly IRepository<Report> _reports;
    private readonly IRepository<DraftReport> _draftReports;
    private readonly IRepository<Site> _sites;
    private readonly IRepository<Batch> _batches;
    private readonly IRepository<Analysis> _analyses;
    private readonly IReportStorage _reportStorage;
    private readonly IMLReportingService _mlReportingService;

    public ReportService(IRepository<Report> reports, IRepository<DraftReport> draftReports, IRepository<Site> sites, IRepository<Batch> batches, 
        IRepository<Analysis> analyses, IReportStorage reportStorage, IMLReportingService mlReportingService)
    {
        _reports = reports;
        _draftReports = draftReports;
        _sites = sites;
        _batches = batches;
        _reportStorage = reportStorage;
        _mlReportingService = mlReportingService;
        _analyses = analyses;
    }

    public async ValueTask<DraftReport> Create(NewReport data, User user)
    {
        var site = await FindSite(data.SiteId)
            .ConfigureAwait(false);
        var batches = await FindBatches(data.BatchIds)
            .ConfigureAwait(false);
        var analyses = await FindAnalyses(data.AnalysisIds)
            .ConfigureAwait(false);

        site.GeneratedReportCount++;
        _sites.Update(site);

        var draftReport = await _draftReports.InsertAsync(new DraftReport
        {
            Site = site,
            CreatedBy = user,
            CreatedOn = DateTime.UtcNow,
            Observations = data.Observations,
            ProcessDeviations = data.ProcessDeviations,
            Batches = batches,
            Analyses = analyses,
            SiteLocalId = site.GeneratedReportCount
        }).ConfigureAwait(false);

        await _mlReportingService.OnCreated(draftReport)
            .ConfigureAwait(false);
        
        return draftReport;
    }

    public async ValueTask<Report?> Get(long reportId)
    {
        return await _reports.FindAsync(r => r.Id == reportId)
            .AsNoTracking()
            .Include(r => r.CreatedBy)
            .Include(r => r.ReviewedBy)
            .Include(r => r.Site)
                .ThenInclude(s => s.Company)
            .Include(r => r.Batches)
                .ThenInclude(b => b.Site)
            .Include(r => r.Batches)
                .ThenInclude(b => b.Samples)
                    .ThenInclude(s => s.BiomarkerResults)
                        .ThenInclude(b => b.Biomarker)
                            .ThenInclude(b => b.Parent)
            .Include(r => r.Batches)
                .ThenInclude(b => b.Samples)
                    .ThenInclude(s => s.FishHealthResults)
                        .ThenInclude(r => r.Reports)
            .Include(r => r.Analyses)
            .FirstOrDefaultAsync()
            .ConfigureAwait(false);
    }

    public async ValueTask<DraftReport?> GetDraft(long draftReportId)
    {
        return await _draftReports.FindAsync(r => r.Id == draftReportId)
            .AsNoTracking()
            .Include(r => r.CreatedBy)
            .Include(r => r.Site)
                .ThenInclude(s => s.Company)
            .Include(r => r.Batches)
                .ThenInclude(b => b.Site)
            .Include(r => r.Batches)
                .ThenInclude(b => b.Samples)
                    .ThenInclude(s => s.BiomarkerResults)
                        .ThenInclude(b => b.Biomarker)
                            .ThenInclude(b => b.Parent)
            .Include(r => r.Batches)
                .ThenInclude(b => b.Samples)
                    .ThenInclude(s => s.FishHealthResults)
                        .ThenInclude(r => r.DraftReports)
            .Include(r => r.Analyses)
            .FirstOrDefaultAsync()
            .ConfigureAwait(false);
    }

    public async ValueTask<Report?> Approve(long draftReportId, User user, Stream file)
    {
        var draft = await _draftReports.FindAsync(draft => draft.Id == draftReportId)
            .Include(d => d.Site)
                .ThenInclude(s => s.Company)
            .Include(d => d.CreatedBy)
            .Include(d => d.Analyses)
            .Include(d => d.Batches)
                .ThenInclude(b => b.Site)
            .FirstOrDefaultAsync()
            .ConfigureAwait(false);
        if (draft is null)
        {
            throw EntityNotFoundException.Create<DraftReport>(draftReportId);
        }

        if (ReviewerIsCreator())
        {
            return null;
        }

        var report = await _reports.InsertAsync(new Report
        {
            Site = draft.Site,
            CreatedBy = draft.CreatedBy,
            ReviewedBy = user,
            CreatedOn = draft.CreatedOn,
            ApprovedOn = DateTime.UtcNow,
            Observations = draft.Observations,
            Batches = draft.Batches,
            Analyses = draft.Analyses,
            SiteLocalId = draft.SiteLocalId
        });
        
        await _mlReportingService.OnApproved(draft, report);
        
        _draftReports.Delete(draft);

        await _reportStorage.Save(file, report);

        return report;

        bool ReviewerIsCreator() => draft.CreatedById == user.Id;
    }

    public async ValueTask Delete(long draftReportId)
    {
        var report = await _draftReports.GetByIdAsync(draftReportId);
        if (report is not null)
        {
            _draftReports.Delete(report);
        }
    }

    private async ValueTask<ICollection<Analysis>> FindAnalyses(ICollection<int> analysisIds)
    {
        var analyses = await _analyses.FindAsync(a => analysisIds.Contains(a.Id))
            .ToListAsync()
            .ConfigureAwait(false);

        if (analyses.Count == analysisIds.Count)
        {
            return analyses;
        }

        var notFoundIds = analysisIds.Except(analyses.Select(b => b.Id));

        throw EntitiesNotFoundException.Create<Batch>(notFoundIds.Cast<object>());
    }

    private async ValueTask<ICollection<Batch>> FindBatches(ICollection<long> batchIds)
    {
        var batches = await _batches.FindAsync(b => batchIds.Contains(b.Id))
            .Include(b => b.Site)
            .ToListAsync()
            .ConfigureAwait(false);

        if (batches.Count == batchIds.Count)
        {
            return batches;
        }

        var notFoundIds = batchIds.Except(batches.Select(b => b.Id));

        throw EntitiesNotFoundException.Create<Batch>(notFoundIds.Cast<object>());
    }

    private async ValueTask<Site> FindSite(string siteId)
    {
        var site = await _sites.FindAsync(site => site.Id == siteId)
            .Include(s => s.Company)
            .FirstOrDefaultAsync()
            .ConfigureAwait(false);
        if (site is null)
        {
            throw EntityNotFoundException.Create<Site>(siteId);
        }

        return site;
    }
}