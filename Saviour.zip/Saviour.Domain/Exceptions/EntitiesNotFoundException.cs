﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace Saviour.Domain.Exceptions;

public class EntitiesNotFoundException : Exception
{
    public EntitiesNotFoundException(MemberInfo type, IEnumerable<object> ids)
        : base($"Failed to locate entity of type {type.Name} with id's {string.Join(',', ids)}")
    {
    }

    public static EntitiesNotFoundException Create<T>(IEnumerable<object> ids) => new(typeof(T), ids);
}