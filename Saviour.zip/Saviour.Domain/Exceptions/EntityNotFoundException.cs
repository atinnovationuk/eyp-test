﻿using System;
using System.Reflection;

namespace Saviour.Domain.Exceptions;

public class EntityNotFoundException : Exception
{
    public EntityNotFoundException(MemberInfo type, object id)
        : base($"Failed to locate entity of type {type.Name} with id {id}")
    {
    }

    public static EntityNotFoundException Create<T>(object id) => new(typeof(T), id);
}