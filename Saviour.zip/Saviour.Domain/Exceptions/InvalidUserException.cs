﻿using System;

namespace Saviour.Domain.Exceptions;

public class InvalidUserException : Exception
{
    public InvalidUserException(string reason)
        : base($"Invalid user data for request: {reason}")
    {
        
    }
}