﻿using System.ComponentModel.DataAnnotations;

namespace Saviour.Domain.Validation;

public class RequiredStringAttribute : StringLengthAttribute
{
    public RequiredStringAttribute(int maximumLength) : base(maximumLength)
    {
        MinimumLength = 1;
    }

    public override bool IsValid(object? value)
    {
        return value is not null && base.IsValid(value);
    }
}