﻿namespace Saviour.Domain.Validation;

public static class Limits
{
    public static class Companies
    {
        public const int Id = 158;
        public const int Name = 126;
        public const int Address = 500;
    }

    public static class Sites
    {
        public const int Id = 20;
        public const int Name = 158;
    }
    
    public static class Batches
    {
        public const int BatchNumber = 40;
        public const int FishHealthHistory = 2000;
        public const int ConfirmedCondition = 2000;
    }
    
    public static class Samples
    {
        public const int Id = 160;
        public const int Instrument = 400;
        public const int Species = 158;
        public const int Pen = 10;
        public const int FishNumber = 158;
        public const int Strain = 158;
    }

    public static class Hatcheries
    {
        public const int Code = 160;
    }

    public static class Biomarkers
    {
        public const int Name = 1000;
    }

    public static class Analyses
    {
        public const int MethodName = 1000;
    }

    public static class Countries
    {
        public const int Code = 20;
    }

    public static class Employees
    {
        public const int Name = 128;
        public const int LoginIdentity = 256;
    }

    public static class Users
    {
        public const int AzureId = 64;
        public const int Name = 128;
    }

    public static class MLBiomarkers
    {
        public const int Name = 256;
    }
}
