﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Saviour.Domain.Validation;

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
public class CollectionStringLengthAttribute : StringLengthAttribute
{
    public CollectionStringLengthAttribute(int maximumLength) : base(maximumLength)
    {
    }

    public override bool IsValid(object? value)
    {
        if (value is null)
        {
            return true;
        }

        if (value is not IEnumerable<string> range)
        {
            return false;
        }

        return range.All(s => base.IsValid(s));
    }
}