﻿using System.Collections;
using System.ComponentModel.DataAnnotations;

namespace Saviour.Domain.Validation;

public class RequiredNonEmptyAttribute : ValidationAttribute
{
    public override string FormatErrorMessage(string name)
    {
        return $"{name} must be a non-empty collection";
    }

    public override bool IsValid(object? value)
    {
        return value is ICollection {Count: > 0};
    }
}