﻿using System;
using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public class ReportData
{
    public DateTime CreatedOn { get; set; }

    public User CreatedBy { get; set; } = null!;
    public int CreatedById { get; set; }

    public string Observations { get; set; } = string.Empty;

    public string ProcessDeviations { get; set; } = string.Empty;

    public string SiteId { get; set; } = string.Empty;
    public Site Site { get; set; } = null!;
    
    /// <summary>
    /// The ID of the report relative to this site
    /// </summary>
    public int SiteLocalId { get; set; }

    public ICollection<Batch> Batches { get; set; } = new List<Batch>();
    public ICollection<Analysis> Analyses { get; set; } = new List<Analysis>();
}