﻿using System;
using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public abstract class MLResult
{
    public long Id { get; set; }
    
    public DateTime CreatedOn { get; set; }

    public long SampleId { get; set; }
    public Sample Sample { get; set; } = null!;
    
    public int ModelId { get; set; }
    public MLModel Model { get; set; } = null!;

    public ICollection<DraftReport> DraftReports { get; set; } = new List<DraftReport>();
    public ICollection<Report> Reports { get; set; } = new List<Report>();
}
