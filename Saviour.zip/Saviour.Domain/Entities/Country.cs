﻿namespace Saviour.Domain.Entities;

public class Country
{
    public string Code { get; set; } = string.Empty;
}