﻿using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public class Company
{
    public string Id { get; set; } = string.Empty;

    public string CompanyName { get; set; } = string.Empty;

    public string Address { get; set; } = string.Empty;

    public ICollection<Site> Sites { get; set; } = new List<Site>();
}