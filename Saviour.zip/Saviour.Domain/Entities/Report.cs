﻿using System;

namespace Saviour.Domain.Entities;

public class Report : ReportData
{
    public long Id { get; set; }

    public DateTime ApprovedOn { get; set; }
    public User ReviewedBy { get; set; } = null!;
    public int ReviewedById { get; set; }
}
