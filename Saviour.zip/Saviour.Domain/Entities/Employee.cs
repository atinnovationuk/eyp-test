﻿namespace Saviour.Domain.Entities;

public class Employee
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;
    public string LoginIdentity { get; set; } = string.Empty;

    public string CompanyId { get; set; } = string.Empty;
    public Company Company { get; set; } = null!;
}