﻿namespace Saviour.Domain.Entities;

/// <summary>
/// Defines the red/amber/green ranges for the linked biomarker during the linked analysis.
/// </summary>
public class BiomarkerRange
{
    public int Id { get; set; }

    public int AnalysisId { get; set; }
    public Analysis Analysis { get; set; } = null!;

    public int BiomarkerId { get; set; }
    public Biomarker Biomarker { get; set; } = null!;

    /// <summary>
    /// Null if this should be considered the default range
    /// </summary>
    public string? CountryCode { get; set; }
    public Country? Country { get; set; }

    /// <summary>
    /// Minimum value to plot
    /// </summary>
    public double Min { get; set; }
    /// <summary>
    /// Upper-bound of the 'low red' region
    /// </summary>
    public double LowRed { get; set; }
    /// <summary>
    /// Upper-bound of the 'low amber' region
    /// </summary>
    public double LowAmber { get; set; }
    /// <summary>
    /// Upper-bound of the 'green' region
    /// </summary>
    public double Reference { get; set; }
    /// <summary>
    /// Upper-bound of the 'upper amber' region
    /// </summary>
    public double HighAmber { get; set; }
    /// <summary>
    /// Maximum value to plot
    /// </summary>
    public double Max { get; set; }
}
