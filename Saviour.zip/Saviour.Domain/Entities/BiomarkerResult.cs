﻿namespace Saviour.Domain.Entities;

public class BiomarkerResult
{
    public long Id { get; set; }

    public int BioMarkerId { get; set; }
    public Biomarker Biomarker { get; set; } = null!;

    public decimal Result { get; set; }

    public long SampleId { get; set; }
    public Sample Sample { get; set; } = null!;
}
