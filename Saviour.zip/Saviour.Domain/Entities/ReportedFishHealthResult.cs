﻿namespace Saviour.Domain.Entities;

public class ReportedFishHealthResult : ReportedMLResult
{
    public FishHealthResult Result { get; set; } = null!;
}
