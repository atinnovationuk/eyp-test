﻿using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public class Hatchery
{
    public int Id { get; set; }

    public string HatcheryCode { get; set; } = string.Empty;

    public ICollection<Sample> Samples { get; set; } = new List<Sample>();
}
