﻿using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public record BiomarkerResultOnly(int BioMarkerId, decimal Result);

public record MLSampleData(long Id, IReadOnlyList<BiomarkerResultOnly> BiomarkerResults);

public record MLInputData(MLModel Model, IReadOnlyList<MLSampleData> Samples, IReadOnlyList<MLBiomarker> Biomarkers)
{
    public bool IsEmpty => Samples.Count == 0;
}