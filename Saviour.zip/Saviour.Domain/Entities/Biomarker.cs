﻿using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public class Biomarker
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public Biomarker? Parent { get; set; }
    /// <summary>
    /// Link to a synonymous biomarker that should be used instead of this one, e.g. in analyses
    /// </summary>
    public int? ParentId { get; set; }
    
    /// <summary>
    /// Link to biomarkers that are synonymous with this biomarker
    /// </summary>
    public ICollection<Biomarker> Children { get; set; } = new List<Biomarker>();
}
