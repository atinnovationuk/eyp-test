﻿namespace Saviour.Domain.Entities;

public class DraftReportAnalysis
{
    public long DraftReportId { get; set; }
    public int AnalysisId { get; set; }
}