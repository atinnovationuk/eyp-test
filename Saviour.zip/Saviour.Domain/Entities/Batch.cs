﻿using System;
using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public class Batch
{
    public long Id { get; set; }
    
    public string BatchNumber { get; set; } = string.Empty;
    public DateOnly DateCollected { get; set; }
    public DateTime DateAnalysed { get; set; }
    public DateTime DateReceived { get; set; }

    public string SiteId { get; set; } = string.Empty;

    public string FishHealthHistory { get; set; } = string.Empty;
    
    public string ConfirmedCondition { get; set; } = string.Empty;
    
    public Site Site { get; set; } = null!;

    public ICollection<Sample> Samples { get; set; } = new List<Sample>();
    public ICollection<Report> Reports { get; set; } = new List<Report>();
}
