﻿namespace Saviour.Domain.Entities;

public class ReportedBatch
{
    public long ReportId { get; set; }
    public long BatchId { get; set; }
}