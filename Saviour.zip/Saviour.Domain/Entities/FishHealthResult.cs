﻿using System;

namespace Saviour.Domain.Entities;

public enum FishHealthResultType
{
    Unhealthy,
    Healthy
}

public class FishHealthResult : MLResult
{
    public FishHealthResultType Result { get; set; }
}

public static class FishHealthResultExtensions
{
    public static FishHealthResultType ParseFishHealthResult(this double result)
        => result switch
        {
            0.0 => FishHealthResultType.Healthy,
            2.0 => FishHealthResultType.Unhealthy,
            _ => throw new InvalidOperationException($"Invalid result value for Fish Health: {result}")
        };
}
