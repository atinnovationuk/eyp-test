﻿namespace Saviour.Domain.Entities;

public abstract class ReportedMLResult
{
    public long Id { get; set; }
    
    public long MLResultId { get; set; }
    
    public long? DraftReportId { get; set; }
    public DraftReport? DraftReport { get; set; }

    public long? ReportId { get; set; }
    public Report? Report { get; set; }
}
