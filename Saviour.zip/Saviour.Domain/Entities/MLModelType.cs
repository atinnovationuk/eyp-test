﻿namespace Saviour.Domain.Entities;

public enum MLModelType
{
    // Model 0
    FishHealth
}
