﻿namespace Saviour.Domain.Entities;

public class ReportAnalysis
{
    public long ReportId { get; set; }
    public int AnalysisId { get; set; }
}