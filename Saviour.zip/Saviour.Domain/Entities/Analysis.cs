﻿using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public class Analysis
{
    public int Id { get; set; }

    public string MethodName { get; set; } = string.Empty;

    public ICollection<BiomarkerRange> BiomarkerRanges { get; set; } = new List<BiomarkerRange>();
}