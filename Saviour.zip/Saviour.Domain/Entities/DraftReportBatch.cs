﻿namespace Saviour.Domain.Entities;

public class DraftReportBatch
{
    public long DraftReportId { get; set; }
    public long BatchId { get; set; }
}