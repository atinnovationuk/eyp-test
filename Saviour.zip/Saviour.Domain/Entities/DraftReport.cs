﻿namespace Saviour.Domain.Entities;

public class DraftReport : ReportData
{
    public long Id { get; set; }
}
