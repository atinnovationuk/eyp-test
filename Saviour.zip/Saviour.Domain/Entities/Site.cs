﻿using System.Collections.Generic;

namespace Saviour.Domain.Entities;

public class Site
{
    public string Id { get; set; } = string.Empty;

    public string SiteName { get; set; } = string.Empty;

    public string CompanyId { get; set; } = string.Empty;
    public Company Company { get; set; } = null!;

    public string CountryCode { get; set; } = string.Empty;
    public Country Country { get; set; } = null!;
    
    public int GeneratedReportCount { get; set; }

    public ICollection<Batch> Batches { get; set; } = new List<Batch>();
}
