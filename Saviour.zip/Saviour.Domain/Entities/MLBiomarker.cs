﻿namespace Saviour.Domain.Entities;

public class MLBiomarker
{
    public int Id { get; set; }
    
    public MLModelType ModelType { get; set; }

    public string Name { get; set; } = string.Empty;
    
    public int BiomarkerId { get; set; }
    public Biomarker Biomarker { get; set; } = null!;

    public decimal Min { get; set; }
    public decimal Max { get; set; }
    
    public short SortOrder { get; set; }
}