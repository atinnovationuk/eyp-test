﻿namespace Saviour.Domain.Entities;

public class MLModel
{
    public int Id { get; set; }
    public MLModelType Type { get; set; }
    public int Version { get; set; }
}
