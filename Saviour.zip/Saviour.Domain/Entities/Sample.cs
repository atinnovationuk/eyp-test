﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Validation;

namespace Saviour.Domain.Entities;

public class Sample
{
    [Required]
    [Key]
    public long Id { get; set; }

    public long BatchId { get; set; }
    public Batch Batch { get; set; } = null!;

    [Required]
    [StringLength(Limits.Samples.Id)]
    public string SampleCode { get; set; } = string.Empty;

    [Required]
    [StringLength(Limits.Samples.Instrument)]
    public string Instrument { get; set; } = string.Empty;

    [Required]
    [StringLength(Limits.Samples.Species)]
    public string Species { get; set; } = string.Empty;

    [Required]
    public WaterType WaterType { get; set; }

    [Required]
    [StringLength(Limits.Samples.Pen)]
    public string Pen { get; set; } = string.Empty;

    [Required]
    [StringLength(Limits.Samples.FishNumber)]
    public string FishNumber { get; set; } = string.Empty;

    public decimal AverageWeightInGrams { get; set; }

    public decimal TemperatureInCelsius { get; set; }

    public decimal? OxygenLevelInMg { get; set; }

    public decimal MortalityRatePercentage { get; set; }

    [StringLength(Limits.Samples.Strain)]
    public string? Strain { get; set; }

    public ICollection<Hatchery> Hatcheries { get; set; } = new List<Hatchery>();

    public ICollection<BiomarkerResult> BiomarkerResults { get; set; } = new List<BiomarkerResult>();

    public ICollection<FishHealthResult> FishHealthResults { get; set; } = new List<FishHealthResult>();
}
