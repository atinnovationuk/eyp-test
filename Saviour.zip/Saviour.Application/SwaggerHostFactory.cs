﻿namespace Saviour.Application;


// ReSharper disable once UnusedType.Global - Used by Swagger code generation
public static class SwaggerHostFactory
{
    // ReSharper disable once UnusedMember.Global - Used by Swagger code generation
    public static IHost CreateHost()
    {
        return Host.CreateDefaultBuilder()
            .ConfigureWebHostDefaults(webHostBuilder => webHostBuilder.UseStartup<Startup>())
            .Build();
    }
}
