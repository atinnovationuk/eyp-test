﻿namespace Saviour.Application.Security;

public static class PolicyNames
{
    public const string RequireAnalyst = "RequireAnalyst";
}