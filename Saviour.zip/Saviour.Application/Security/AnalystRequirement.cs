﻿using Microsoft.AspNetCore.Authorization;

namespace Saviour.Application.Security;

public class AnalystRequirement : IAuthorizationRequirement
{
    
}