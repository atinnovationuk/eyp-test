using Microsoft.AspNetCore.Authorization;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Security;

public class AnalystRequirementHandler : AuthorizationHandler<AnalystRequirement>
{
    private readonly IUserTypeService _userTypeService;

    public AnalystRequirementHandler(IUserTypeService userTypeService)
    {
        _userTypeService = userTypeService;
    }

    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, AnalystRequirement requirement)
    {
        if (_userTypeService.Get(context.User) == UserType.WellfishAnalyst)
        {
            context.Succeed(requirement);
        }
        
        return Task.CompletedTask;
    }
}