import {defineConfig, devices} from '@playwright/test';
// @ts-ignore
import {baseConfig} from './base.playwright.config.ts';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
// require('dotenv').config();

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
    ...baseConfig, projects: [
        {
            name: 'chromium',
            use: {...devices['Desktop Chrome']},
        }]
});