﻿import {AnalysisDto, BatchDto} from "../../api/models";
import {PlainObject, stringify} from 'csv-stringify/browser/esm/sync';

export default function GenerateCsvReport(analyses: AnalysisDto[], batches: BatchDto[]) {
  const biomarkers = analyses.flatMap(a => a.biomarkers.map(b => b.name));

  const columns = {
    'batchNumber': 'Batch Number',
    'dateCollected': 'Date Collected',
    'dateAnalysed': 'Date Analysed',
    'sampleCode': 'Sample Code',
    'pen': 'Pen',
    'species': 'Species',
    'waterType': 'Water Type',
    'fishNumber': 'Fish Number',
    'averageWeight': 'Average Weight (g)',
    'temperature': 'Temperature (°C)',
    'oxygenLevel': 'Oxygen Level (mg)',
    'mortalityRate': 'Mortality Rate (%)',
    'strain': 'Strain',
    'hatcheries': 'Hatcheries'
  } as PlainObject<string>;
  
  biomarkers.forEach(biomarker => {
    columns[biomarker] = biomarker;
  })

  return stringify(
    batches.flatMap(batch => {
      return batch.samples.map(sample => {
        const record = {
          batchNumber: batch.batchNumber,
          dateCollected: batch.dateCollected.toLocaleDateString(),
          dateAnalysed: batch.dateAnalysed.toLocaleDateString(),
          sampleCode: sample.sampleCode,
          pen: sample.pen,
          species: sample.species,
          waterType: sample.waterType,
          fishNumber: sample.fishNumber,
          averageWeight: sample.averageWeightInGrams,
          temperature: sample.temperatureInCelsius,
          oxygenLevel: sample.oxygenLevelInMg ?? '',
          mortalityRate: sample.mortalityRatePercentage,
          strain: sample.strain ?? '',
          hatcheries: sample.hatcheries.join(",")
        } as PlainObject<any>;

        biomarkers.forEach(biomarker => {
          record[biomarker] = sample.biomarkerResults[biomarker] ?? '';
        });

        return record;
      });
    }),
    {
      header: true,
      columns: columns
    }
  );
}
