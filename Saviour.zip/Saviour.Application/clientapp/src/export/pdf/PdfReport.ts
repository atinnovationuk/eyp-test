﻿import { PageSizes, PDFDocument, PDFImage, PDFPage, rgb } from 'pdf-lib';
import { ReportDataModel } from '../../components/report/ReportDataModel';
import logoPath from '../../assets/wellfish.png';
import { PageBuilderOptions, PdfPageBuilder } from './PdfPageBuilder';
import { FontStyle } from './FontStyle';
import { FontStyles } from './FontStyles';
import PdfBuilder from './PdfBuilder';
import ReportGraph, { GetGraphSize } from '../../components/report/ReportGraph';
import { AnalysisDto, BatchDto } from '../../api/models';
import { writeHorizontalTable, writeVerticalTable } from './PdfTables';
import { embedImage, reactNodeToImage } from './PdfImages';
import fontkit from '@pdf-lib/fontkit';
import regularFont from '../../fonts/LeagueSpartan-Regular.ttf';
import boltFont from '../../fonts/LeagueSpartan-Bold.ttf';
import { PdfPoint } from './PdfPoint';

const graphsPerPage = 2;

const fontColour = rgb(0, 31 / 255, 96 / 255);
const borderColour = fontColour;

function drawRectangleFromPosition(pageBuilder: PdfPageBuilder, topLeft: PdfPoint) {
  const margin = 5;
  const height = topLeft.y - pageBuilder.getCurrentPosition().y;

  pageBuilder.page.drawRectangle({
    x: topLeft.x - margin,
    y: pageBuilder.getY(topLeft.y - margin),
    width: pageBuilder.getAvailableWidth() + margin * 2,
    height: height - margin * 2,
    opacity: 0,
    borderOpacity: 1,
    borderWidth: 1,
    borderColor: borderColour,
  });
}

function writeHeading(pageBuilder: PdfPageBuilder, heading: string) {
  return pageBuilder.write(heading, {
    fontStyle: FontStyles.Heading2,
    lineSpacing: 5,
  });
}

function writeTextRegion(pageBuilder: PdfPageBuilder, heading: string, content: string) {
  const headingRegion = writeHeading(pageBuilder, heading);

  pageBuilder.write(content, {
    fontStyle: FontStyles.Paragraph,
    lineSpacing: 5,
  });

  drawRectangleFromPosition(pageBuilder, headingRegion.topLeft);
}

function drawFooter(
  page: PDFPage,
  options: PageBuilderOptions,
  pageNumber: number,
  pageCount: number,
  reportId: string
) {
  const { font, size } = options.styles.get(FontStyles.Footer)!;

  const reportIdWidth = font.widthOfTextAtSize(reportId, size);
  page.drawText(reportId, {
    x: (page.getWidth() - reportIdWidth) / 2,
    y: options.margin.y,
    size,
    font,
    color: rgb(0.4, 0.4, 0.4),
  });

  const pageCountText = `Page ${pageNumber} of ${pageCount}`;
  const pageCountWidth = font.widthOfTextAtSize(pageCountText, size);
  page.drawText(pageCountText, {
    x: (page.getWidth() - pageCountWidth) / 2,
    y: options.margin.y - font.heightAtSize(size),
    size,
    font,
    color: rgb(0.4, 0.4, 0.4),
  });
}

function buildNewPage(
  page: PDFPage,
  options: PageBuilderOptions,
  companyLogo: PDFImage,
  isDraft: boolean,
  reportId: string,
  pageNumber: number,
  pageCount: number
) {
  const logoWidth = companyLogo.width * 0.5;
  const logoHeight = companyLogo.height * 0.5;
  page.drawImage(companyLogo, {
    x: page.getWidth() - logoWidth - 15,
    y: (page.getHeight() - logoHeight) / 2,
    width: logoWidth,
    height: logoHeight,
    opacity: 0.2,
  });

  if (isDraft) {
    const { font, size } = options.styles.get(FontStyles.Heading)!;
    const draftText = 'Draft';

    const draftWidth = font.widthOfTextAtSize(draftText, size);
    const draftHeight = font.heightAtSize(size);

    page.drawText(draftText, {
      x: (page.getWidth() - draftWidth) / 2,
      y: page.getHeight() - draftHeight - options.margin.y,
      size,
      font,
      color: fontColour,
    });
  }

  drawFooter(page, options, pageNumber, pageCount, reportId);
}

function addDetailsPage(pdfBuilder: PdfBuilder, report: ReportDataModel) {
  const page = pdfBuilder.newPage();

  page.write('Results Report', {
    fontStyle: FontStyles.Heading,
  });

  page.addBlankLink(FontStyles.Heading);

  const summaryStart = page.getCurrentPosition();

  writeVerticalTable(
    page,
    [
      { heading: 'Company Name', content: report.company.name },
      { heading: 'Site Name', content: report.site.name },
      {
        heading: 'Processing Laboratory',
        content: 'Scotland',
      },
      { heading: 'Issue Date', content: report.reviewedOn?.toLocaleDateString() ?? '-' },
      { heading: 'Created By', content: report.createdBy.name },
      { heading: 'Authorised By', content: report.reviewedBy?.name ?? '-' },
    ],
    borderColour
  );

  drawRectangleFromPosition(page, summaryStart);

  page.addBlankLink(FontStyles.Heading);

  const clinicalHistoryRegion = writeHeading(page, 'Clinical History');

  writeHorizontalTable(
    page,
    [
      { heading: 'Batch Number', relativeWidth: 1 },
      { heading: '', relativeWidth: 3 },
    ],
    report.batches
      .filter((b) => b.fishHealthHistory)
      .map((batch) => [batch.batchNumber, batch.fishHealthHistory]),
    borderColour
  );

  drawRectangleFromPosition(page, clinicalHistoryRegion.topLeft);

  page.addBlankLink(FontStyles.Heading);

  writeTextRegion(page, 'Clinical Observations', report.observations);
  page.addBlankLink(FontStyles.Heading);

  const healthInformation = page.write('Fish Health Information', {
    fontStyle: FontStyles.Heading,
  });
  page.write('(information provided by the customer)', {
    fontStyle: FontStyles.Heading2,
    lineSpacing: 5,
  });

  writeHorizontalTable(
    page,
    [
      { heading: 'Batch Number', relativeWidth: 1 },
      { heading: 'Confirmed Condition', relativeWidth: 3 },
    ],
    report.batches
      .filter((b) => b.confirmedCondition)
      .map((batch) => [batch.batchNumber, batch.confirmedCondition]),
    borderColour
  );

  drawRectangleFromPosition(page, healthInformation.topLeft);
}

async function getAnalysisImage(
  pdf: PDFDocument,
  batches: BatchDto[],
  analysis: AnalysisDto
): Promise<PDFImage> {
  const sizeSettings = {
    heightPerBiomarker: 250,
    widthPerPen: 40,
  };

  const { width, height } = GetGraphSize(batches, sizeSettings);

  return reactNodeToImage(
    pdf,
    width,
    height,
    ReportGraph({
      batches,
      analysisGrouping: analysis,
      sizeSettings,
    })
  );
}

async function addAnalysisPages(pdf: PDFDocument, pdfBuilder: PdfBuilder, report: ReportDataModel) {
  const marginX = 50;
  const marginY = 75;

  let page = pdfBuilder.newPage();
  for (let i = 0; i < report.analyses.length; i++) {
    const analysis = report.analyses[i];

    if (i > 0 && i % graphsPerPage === 0) {
      page = pdfBuilder.newPage();
    }

    page.addBlankLink(FontStyles.Heading);

    const maxWidth = page.page.getWidth() - marginX * 2;
    const maxHeight = (page.page.getHeight() - marginY * 2) / graphsPerPage;

    const image = await getAnalysisImage(pdf, report.batches, analysis);

    const { width, height } = image.scaleToFit(maxWidth, maxHeight);

    const headingPosition = page.write(analysis.name, {
      fontStyle: FontStyles.Heading2,
    });

    const lineHeight = headingPosition.bottomRight.y - headingPosition.topLeft.y;
    const lineCount = Math.ceil(height / lineHeight);
    for (let j = 0; j < lineCount; j++) {
      page.addBlankLink(FontStyles.Heading2);
    }

    page.page.drawImage(image, {
      x: marginX,
      y: page.getY(headingPosition.bottomRight.y + height + 10),
      width,
      height,
    });
  }
}

function addDisclaimer(page: PdfPageBuilder, report: ReportDataModel) {
  const regionStart = writeHeading(page, 'Wellfish Information');

  writeVerticalTable(
    page,
    [
      { heading: 'Company House Number', content: 'SC687885' },
      { heading: 'Contact Email', content: 'reports@wellfishtech.com' },
      {
        heading: 'Laboratory Address',
        content:
          'Wellfish Tech\n' +
          'University of the West of Scotland,\n' +
          'Paisley, PA1 2BE, Scotland.',
      },
    ],
    borderColour
  );

  writeVerticalTable(
    page,
    [
      { heading: 'Company Name', content: report.company.name },
      { heading: 'Company Address', content: report.company.address },
    ],
    borderColour
  );

  drawRectangleFromPosition(page, regionStart.topLeft);

  page.addBlankLink(FontStyles.Heading);

  const disclaimers = writeHeading(page, 'Disclaimers');

  page.write(
    'Clinical history provided by the customer has been ' +
      'used to aid in interpretation of the results on the assumption that the information provided is correct.',
    { fontStyle: FontStyles.Disclaimer }
  );

  page.addBlankLink(FontStyles.Paragraph);

  page.write(
    'Results and interpretation provided are generated from the clinical history provided and serum samples selected, processed, and ' +
      'provided by the customer which are intended to be a representative sampling of the pen/site population. ' +
      'The results are valid only for the samples tested and relate only to the population from which they were taken. ' +
      'Wellfish Tech is not liable for damage claims or other matters that may arise as a result of, or in connection with, ' +
      'the use of the results given in this report. Incorrect or missing information from the customer ' +
      '(e.g. location, health status, sampling method) can lead to inaccurate results. ' +
      'Wellfish Tech cannot be held responsible for claims, damages, or other liabilities as a result of, ' +
      'or in connection with incorrect or missing information provided by the customer, ' +
      'or incorrect results due to deviation from specified sampling procedure. ' +
      'This report may not be edited and must only be reproduced in its entirety unless otherwise agreed in writing with Wellfish Tech.',
    { fontStyle: FontStyles.Disclaimer }
  );

  drawRectangleFromPosition(page, disclaimers.topLeft);
}

async function embedFont(pdfDocument: PDFDocument, path: string) {
  const fetchResponse = await fetch(path);
  if (!fetchResponse.ok) {
    throw new Error('Failed to download font');
  }

  const fontBytes = await fetchResponse.arrayBuffer();

  return pdfDocument.embedFont(fontBytes);
}

function addNotesPage(pdfBuilder: PdfBuilder, report: ReportDataModel) {
  const page = pdfBuilder.newPage();

  page.addBlankLink(FontStyles.Heading);
  page.addBlankLink(FontStyles.Heading);

  writeTextRegion(
    page,
    'Additions to, deviations, or exclusions from the method',
    report.processDeviations
  );
  page.addBlankLink(FontStyles.Heading);

  writeTextRegion(
    page,
    'Method Used',
    'Clinical chemistry analysis of fish serum separated from whole blood for 18 biomarkers using high-throughput spectrophotometry on Cobas503 platform'
  );
  page.addBlankLink(FontStyles.Heading);

  writeTextRegion(
    page,
    'Sample Description',
    'Eppendorf tubes:\n' +
      '> Labelled with the associated fish number\n' +
      '> Containing ~300µl of serum extracted from whole fish blood\n' +
      '> Sealed in plastic bag labelled with the pen number and number of samples\n' +
      '> Packaged in thermal pockets and delivered to the laboratory.'
  );

  page.addBlankLink(FontStyles.Heading);

  const batchInformation = writeHeading(page, 'Batch Information');
  writeHorizontalTable(
    page,
    ['Batch Number', 'Sampling Date', 'Processing Date', 'Receipt Date'],
    report.batches.map((batch) => [
      batch.batchNumber,
      batch.dateCollected.toLocaleDateString(),
      batch.dateAnalysed.toLocaleDateString(),
      batch.dateReceived.toLocaleDateString(),
    ]),
    borderColour
  );

  drawRectangleFromPosition(page, batchInformation.topLeft);

  page.addBlankLink(FontStyles.Heading);

  addDisclaimer(page, report);
}

export async function GeneratePdfReport(report: ReportDataModel, isDraft: boolean) {
  const pdfDocument = await PDFDocument.create();
  pdfDocument.registerFontkit(fontkit);

  const companyLogo = await embedImage(pdfDocument, logoPath);

  const font = await embedFont(pdfDocument, regularFont);
  const fontBold = await embedFont(pdfDocument, boltFont);

  const pageCount = 2 + Math.ceil(report.analyses.length / graphsPerPage);
  const reportId = `${report.company.name}-${report.site.name}-${report.siteLocalId}`;

  const pdfBuilder = new PdfBuilder(pdfDocument, {
    styles: new Map<FontStyles, FontStyle>([
      [FontStyles.Heading, { font: fontBold, size: 18, color: fontColour }],
      [FontStyles.Heading2, { font: fontBold, size: 14, color: fontColour }],
      [FontStyles.Paragraph, { font, size: 12, color: fontColour }],
      [FontStyles.Disclaimer, { font, size: 11, color: fontColour }],
      [FontStyles.Footer, { font, size: 10, color: fontColour }],
    ]),
    margin: { x: 25, y: 40 },
    pageSize: PageSizes.A4,
    buildNewPage: (newPage, options, pageNumber) =>
      buildNewPage(
        newPage,
        options,
        companyLogo,
        isDraft,
        reportId,
        pageNumber,
        pageCount
      ),
  });

  addDetailsPage(pdfBuilder, report);
  await addAnalysisPages(pdfDocument, pdfBuilder, report);
  addNotesPage(pdfBuilder, report);
  return pdfDocument.save();
}

export function getPdfReportName(report: ReportDataModel) {
  const batchName = report.batches.map((b) => b.batchNumber).join('-');
  return `Report-${batchName}.pdf`;
}
