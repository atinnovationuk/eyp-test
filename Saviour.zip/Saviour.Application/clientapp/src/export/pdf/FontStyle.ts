﻿import { PDFFont, RGB } from 'pdf-lib';

export interface FontStyle {
  font: PDFFont;
  size: number;
  color: RGB;
}
