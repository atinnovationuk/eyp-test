﻿import { PDFFont, PDFPage } from 'pdf-lib';
import { PdfPoint } from './PdfPoint';
import { FontStyle } from './FontStyle';
import { FontStyles } from './FontStyles';

export interface PageBuilderOptions {
  margin: PdfPoint;
  styles: Map<FontStyles, FontStyle>;
}

export interface TextRegion {
  topLeft: PdfPoint;
  bottomRight: PdfPoint;
}

export class PdfPageBuilder {
  public readonly page: PDFPage;

  private y: number;

  private options: PageBuilderOptions;

  constructor(page: PDFPage, options: PageBuilderOptions) {
    this.page = page;
    this.options = options;

    this.y = options.margin.y;
  }

  /**
   * Writes text at the current position, and advances internal state tracking the current line position on the page
   * Splits text on new line characters and applies basic word-wrapping
   * @param text Input text
   * @param fontStyle Style to apply to text
   * @param lineSpacing (Optional) Pixel-sized whitespace to apply after each text line
   * @param margin (Optional) Pixel-sized margin to apply before the text on each line
   */
  public write(
    text: string,
    {
      fontStyle,
      lineSpacing = 0,
      margin = 0,
    }: { fontStyle: FontStyles; lineSpacing?: number; margin?: number }
  ): TextRegion {
    const { font, size, color } = this.getStyle(fontStyle);

    const availableWidth = this.getAvailableWidth() - margin;
    const lines = this.splitLinesWithLinebreaks(text, font, size, availableWidth);

    const initialY = this.y;

    const x = this.options.margin.x + margin;
    const lineHeight = font.heightAtSize(size);
    let textWidth = 0;
    lines.forEach((line) => {
      textWidth = Math.max(textWidth, font.widthOfTextAtSize(line, size));

      // NB: x, y is from the bottom-left of the page
      this.page.drawText(line, {
        x,
        y: this.getY(this.y + lineHeight),
        size,
        font,
        color,
      });

      this.y += lineHeight + lineSpacing;
    });

    return {
      topLeft: {
        x,
        y: initialY,
      },
      bottomRight: {
        x: x + textWidth,
        y: this.y,
      },
    };
  }

  public getStyle(fontStyle: FontStyles) {
    const style = this.options.styles.get(fontStyle);
    if (!style) {
      throw new Error('Invalid setup: style not found');
    }
    return style;
  }

  /**
   * Places text horizontally from the specified coordinates
   * Does not affect internal position tracking
   * Splits text on new line characters and applies basic word-wrapping
   * @param text Text to write
   * @param fontStyle Style to apply to text
   * @param x X-position from the left of the document
   * @param y Y-position from the top of the document
   * @param width Available width for text
   * @param lineSpacing (optional) spacing between lines
   * @return the number of lines written
   */
  public placeText(
    text: string,
    {
      fontStyle,
      x,
      y,
      width,
      lineSpacing = 0,
    }: { fontStyle: FontStyles; x: number; y: number; width: number; lineSpacing?: number }
  ) {
    const { font, size, color } = this.getStyle(fontStyle);
    const lineHeight = font.heightAtSize(size);

    const lines = this.splitLinesWithLinebreaks(text, font, size, width);

    const startY = y + lineHeight;
    lines.forEach((line, lineIndex) => {
      const rowOffset = lineIndex * (lineHeight + lineSpacing);
      this.page.drawText(line, {
        x,
        y: this.getY(startY + rowOffset),
        size,
        font,
        color,
      });
    });

    return lines.length;
  }

  public addBlankLink(fontStyle: FontStyles, lineSpacing?: number) {
    const { font, size } = this.getStyle(fontStyle);
    this.y += font.heightAtSize(size) + (lineSpacing ?? 0);
  }

  private splitLinesWithLinebreaks(
    text: string,
    font: PDFFont,
    size: number,
    availableWidth: number
  ) {
    return text
      .split('\n')
      .flatMap((line) => this.splitIntoLines(line, font, size, availableWidth));
  }

  /**
   * Splits the input text into lines using basic word-breaks
   */
  private splitIntoLines(text: string, font: PDFFont, size: number, availableWidth: number) {
    const words = text.split(' ').reverse();
    const lines: string[] = [];

    let currentLine = '';
    let currentLength = 0;
    while (words.length > 0) {
      const nextWord = `${words.pop()} `;
      const nextWordLength = font.widthOfTextAtSize(nextWord, size);

      if (currentLength + nextWordLength > availableWidth) {
        lines.push(currentLine.trimEnd());
        currentLine = nextWord;
        currentLength = nextWordLength;
      } else {
        currentLine += nextWord;
        currentLength += nextWordLength;
      }
    }

    lines.push(currentLine.trimEnd());

    return lines;
  }

  /**
   * Returns the available width of the page for content
   */
  public getAvailableWidth() {
    return this.page.getWidth() - 2 * this.options.margin.x;
  }

  /**
   * Correct the input y-value from based on the top of the page to the bottom, as required by API's
   * @param y y value indexed from the top of the page
   */
  public getY(y: number) {
    return this.page.getHeight() - y;
  }

  public getCurrentPosition() {
    return {
      x: this.options.margin.x,
      y: this.y,
    };
  }
}
