﻿export interface PdfPoint {
  x: number;
  y: number;
}