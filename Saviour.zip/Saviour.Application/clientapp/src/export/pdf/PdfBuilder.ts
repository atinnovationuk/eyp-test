﻿import {PageBuilderOptions, PdfPageBuilder} from "./PdfPageBuilder";
import {PdfPoint} from "./PdfPoint";
import {FontStyle} from "./FontStyle";
import {FontStyles} from "./FontStyles";
import {PDFDocument, PDFPage} from "pdf-lib";

export interface PdfBuilderOptions {
  styles: Map<FontStyles, FontStyle>;
  pageSize: [number, number];
  margin: PdfPoint;
  buildNewPage: (page: PDFPage, options: PageBuilderOptions, pageNumber: number) => void;
}

export default class PdfBuilder {
  
  private readonly pdf: PDFDocument;
  private readonly options: PdfBuilderOptions;
  private pageCounter: number = 1;
  
  constructor(pdf: PDFDocument, options: PdfBuilderOptions) {
    this.pdf = pdf;
    this.options = options;
  }
  
  newPage(): PdfPageBuilder {
    const page = this.pdf.addPage(this.options.pageSize);

    const options: PageBuilderOptions = {
      margin: this.options.margin,
      styles: this.options.styles
    };
    
    this.options.buildNewPage(page, options, this.pageCounter++);

    return new PdfPageBuilder(page, options);
  }
}
