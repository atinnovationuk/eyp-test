﻿import { PdfPageBuilder } from './PdfPageBuilder';
import { FontStyles } from './FontStyles';
import { RGB } from 'pdf-lib';

export interface TableRow {
  heading: string;
  content: string;
}

export function writeVerticalTable(
  pageBuilder: PdfPageBuilder,
  contents: TableRow[],
  lineColour: RGB
) {
  const { font: headerFont, size: headerSize } = pageBuilder.getStyle(FontStyles.Heading2);
  const headerRowWidth = contents
    .map((row) => headerFont.widthOfTextAtSize(`${row.heading}    `, headerSize))
    .reduce((previousValue, currentValue) => Math.max(previousValue, currentValue), 0);

  contents.forEach((row, index) => {
    const currentPosition = pageBuilder.getCurrentPosition();
    pageBuilder.placeText(row.heading, {
      fontStyle: FontStyles.Heading2,
      x: currentPosition.x,
      y: currentPosition.y,
      width: headerRowWidth,
    });

    pageBuilder.write(row.content, {
      fontStyle: FontStyles.Paragraph,
      lineSpacing: 5,
      margin: headerRowWidth,
    });

    if (index !== contents.length - 1) {
      drawLine(pageBuilder, lineColour);
    }
  });
}

export interface HorizontalTableColumn {
  heading: string;
  relativeWidth: number;
}

interface HorizontalColumnData {
  heading: string;
  offset: number;
  span: number;
}

function evaluateColumns(columns: (HorizontalTableColumn | string)[]) {
  const output: HorizontalColumnData[] = [];

  let offset = 0;
  columns.forEach((column) => {
    const item = typeof column === 'string' ? { heading: column, relativeWidth: 1 } : column;

    output.push({
      heading: item.heading,
      offset: offset,
      span: item.relativeWidth,
    });

    offset += item.relativeWidth;
  });

  return output;
}

export function writeHorizontalTable(
  pageBuilder: PdfPageBuilder,
  columns: (HorizontalTableColumn | string)[],
  contents: string[][],
  lineColour: RGB
) {
  if (contents.length === 0) {
    return;
  }

  const columnData = evaluateColumns(columns);
  const columnCount = columnData
    .map((data) => data.span)
    .reduce((previousValue, currentValue) => previousValue + currentValue, 0);

  const lineSpacing = 5;
  const columnWidth = pageBuilder.getAvailableWidth() / columnCount;

  columnData.forEach(({ heading, span, offset }) => {
    const margin = offset * columnWidth;
    const position = pageBuilder.getCurrentPosition();

    pageBuilder.placeText(heading, {
      fontStyle: FontStyles.Heading2,
      x: position.x + margin,
      y: position.y,
      width: (span * pageBuilder.getAvailableWidth()) / columnCount,
    });
  });

  pageBuilder.addBlankLink(FontStyles.Heading2, lineSpacing);

  contents.forEach((row) => {
    const position = pageBuilder.getCurrentPosition();

    let lineCount = 0;
    row.forEach((item, columnIndex) => {
      const { offset, span } = columnData[columnIndex];
      const margin = offset * columnWidth;
      const writtenLines = pageBuilder.placeText(item, {
        fontStyle: FontStyles.Paragraph,
        x: position.x + margin,
        y: position.y,
        lineSpacing,
        width: (span * pageBuilder.getAvailableWidth()) / columnCount,
      });

      lineCount = Math.max(writtenLines);
    });

    drawLine(pageBuilder, lineColour);
    for (let i = 0; i < lineCount; i++) {
      pageBuilder.addBlankLink(FontStyles.Paragraph, lineSpacing);
    }
  });
}

function drawLine(pageBuilder: PdfPageBuilder, colour: RGB) {
  const { x, y } = pageBuilder.getCurrentPosition();

  pageBuilder.page.drawLine({
    start: {
      x,
      y: pageBuilder.getY(y),
    },
    end: {
      x: x + pageBuilder.getAvailableWidth(),
      y: pageBuilder.getY(y),
    },
    thickness: 1,
    color: colour,
  });
}
