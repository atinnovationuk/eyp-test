﻿export enum FontStyles {
  Heading = 'h',
  Heading2 = 'h2',
  Paragraph = 'p',
  Disclaimer = 'd',
  Footer = 'f',
}
