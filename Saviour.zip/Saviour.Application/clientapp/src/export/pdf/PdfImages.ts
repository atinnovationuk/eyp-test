﻿import { PDFDocument, PDFImage } from 'pdf-lib';
import { createRoot } from 'react-dom/client';
import { ReactNode } from 'react';

function sleep(milliseconds: number) {
  return new Promise((r) => setTimeout(r, milliseconds));
}

async function waitForSvg(element: HTMLElement) {
  const maxWait = 5000;
  const waitPerLoop = 10;

  let remainingWait = maxWait;
  while (remainingWait > 0) {
    // Wait until the SVG has been rendered
    const svg = element.querySelector('svg');
    if (svg != null) {
      return svg;
    }

    await sleep(waitPerLoop);
    remainingWait -= waitPerLoop;
  }

  throw new Error(`Failed to render report SVG after ${maxWait} milliseconds`);
}

function loadImage(source: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = reject;
    image.src = source;
  });
}

export async function embedImage(pdf: PDFDocument, path: string) {
  const fetchResult = await fetch(path);
  const imageBytes = await fetchResult.arrayBuffer();
  return pdf.embedPng(imageBytes);
}

export async function reactNodeToImage(
  pdf: PDFDocument,
  width: number,
  height: number,
  node: ReactNode
): Promise<PDFImage> {
  const element = document.createElement('div');
  const root = createRoot(element);

  root.render(node);

  const svg = await waitForSvg(element);
  const svgXml = new XMLSerializer().serializeToString(svg);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  document.body.appendChild(canvas);

  try {
    const context = canvas.getContext('2d')!;

    const image = await loadImage(`data:image/svg+xml;base64,${window.btoa(svgXml)}`);

    context.drawImage(image, 0, 0, width, height);

    const dataUrl = canvas.toDataURL('image/png', 1.0);

    return await embedImage(pdf, dataUrl);
  } finally {
    document.body.removeChild(canvas);
    canvas.remove();
  }
}
