
export const loginRequest = {
    scopes: ["User.Read"]
};
