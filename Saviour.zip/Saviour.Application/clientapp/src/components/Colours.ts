﻿export const primaryBlue = 'rgb(0 31 96)';
export const primaryGreen = 'rgb(0 175 154)';
