import { Box } from '@mantine/core';
import React from 'react';
import wellFishLogoPath from '../../assets/Wellfish-Report-Logo.png';
import classes from './Brand.module.css';
import {Link} from "react-router-dom";

export default function Brand() {
  return (
    <Box
      sx={(theme) => ({
        paddingLeft: theme.spacing.xs,
        paddingRight: theme.spacing.xs,
      })}
    >
      <Link to="/">
        <img src={wellFishLogoPath} alt="wellfish logo" className={classes.wellFishLogo} />
      </Link>
    </Box>
  );
}
