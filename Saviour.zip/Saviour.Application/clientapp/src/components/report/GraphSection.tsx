import React, { ReactElement } from 'react';
import { scalePoint, scaleLinear } from '@visx/scale';
import { Circle } from '@visx/shape';
import { Group } from '@visx/group';
import { Axis } from '@visx/axis';
import { Text } from '@visx/text';
import { useMantineTheme } from '@mantine/core';
import { AnalysisBiomarkerDto, SampleDto } from '../../api/models';
import { MinMaxValues } from './ResultScale';
import { primaryBlue } from '../Colours';

export interface GraphSectionProps {
  height: number;
  widthPerPen: number;
  allPens: string[];
  minMax: MinMaxValues;
  startX: number;
  startY: number;
  samples: SampleDto[];
  samplesGroupedByPen: { [key: string]: SampleDto[] };
  biomarker: AnalysisBiomarkerDto;
  showLeftLabel: boolean;
  showBottomAxis: boolean;
  batchDate: string;
  index: number;
}

export default function GraphSection({
  height,
  widthPerPen,
  allPens,
  minMax: { min: minScale, max: maxScale },
  startX,
  startY,
  samples,
  samplesGroupedByPen,
  biomarker,
  batchDate,
  showBottomAxis,
  showLeftLabel,
  index,
}: GraphSectionProps) {
  const biomarkerName = biomarker.name.toUpperCase();

  const totalPens = allPens.length;
  const innerWidth = widthPerPen * totalPens;

  const x = (d: SampleDto) => d.pen;
  const y = (d: SampleDto) =>
    d.biomarkerResults[biomarkerName] > biomarker.max
      ? biomarker.max
      : d.biomarkerResults[biomarkerName];

  const xScale = scalePoint({
    range: [0, innerWidth - widthPerPen],
    domain: allPens,
  });

  const { fontFamily } = useMantineTheme();

  // Extra X scale with blank at the end of the domain
  // so the numbers can be moved to the center of the ticks
  const xScaleForAxis = scalePoint({
    range: [0, innerWidth],
    domain: [...allPens, ''],
  });

  const generateRangeSections = () => {
    const generatedSections: ReactElement[] = [];
    const generatedAveragePoints: ReactElement[] = [];
    const generatedPoints: ReactElement[] = [];

    const red = 'rgb(255,155,155)';
    const amber = 'rgb(254,255,127)';
    const green = 'rgb(127,254,128)';

    const rectColours = [red, amber, green, amber, red];

    const range = [
      maxScale,
      biomarker.highAmber,
      biomarker.reference,
      biomarker.lowAmber,
      biomarker.lowRed,
      minScale,
    ];

    const totalRange = maxScale - minScale;

    const yScale = scaleLinear({
      range: [0, height],
      domain: [maxScale, minScale], // This may look odd, but the y-value is an offset from the top of the graph, i.e. the max is at coordinate 0
    });

    let yOffset = 0;
    for (let i = 0; i < range.length - 1; i++) {
      const rangeStart = range[i];
      const rangeEnd = range[i + 1];
      const fraction = (rangeStart - rangeEnd) / totalRange;
      const calculatedHeight = fraction * height;

      generatedSections.push(
        <rect
          key={`range ${i}`}
          y={yOffset}
          width={innerWidth}
          fill={rectColours[i]}
          height={calculatedHeight}
        />
      );

      yOffset += calculatedHeight;
    }

    const getAverageForPen = (pen: string) => {
      const samples = samplesGroupedByPen[pen];

      const sumOfBiomarkerResults = samples.reduce(
        (acc, sample) => acc + sample.biomarkerResults[biomarkerName],
        0
      );
      return sumOfBiomarkerResults / samples.length;
    };

    generatedAveragePoints.push(
      ...Object.keys(samplesGroupedByPen).map((pen, j) => {
        const average = getAverageForPen(pen);
        return (
          <rect
            width={widthPerPen}
            height={1}
            key={`average ${j}`}
            x={xScale(pen)}
            y={yScale(average)}
            fillOpacity={1}
            stroke="rgb(0, 0, 0)"
            fill="rgb(0, 0, 0)"
          />
        );
      })
    );

    generatedPoints.push(
      ...samples.map((point, j) => (
        <Circle
          key={`circle ${j}`}
          cx={xScale(x(point))! + widthPerPen / 2}
          cy={yScale(y(point))}
          r={1}
          fillOpacity={1}
          stroke="rgb(75, 0, 130)"
          fill="rgb(75, 0, 130)"
          id={`${point.sampleCode} - ${point.biomarkerResults[biomarkerName]}}`}
        />
      ))
    );

    return [generatedSections, generatedPoints, generatedAveragePoints];
  };

  const [sections, points, averagePoints] = generateRangeSections();

  const dateOffset = index % 2 === 0 ? 35 : 20;

  return (
    <>
      {batchDate ? (
        <Text
          width={totalPens * widthPerPen}
          x={innerWidth / 2 + startX}
          y={dateOffset}
          textAnchor="middle"
          fontWeight="bold"
          fontFamily={fontFamily}
          fill={primaryBlue}
        >
          {batchDate}
        </Text>
      ) : null}
      <Group pointerEvents="none" left={startX} top={startY}>
        {showLeftLabel ? (
          <Text
            width={totalPens * widthPerPen}
            x={-20}
            y={height / 2}
            fontSize={18}
            fontWeight="bold"
            fontFamily={fontFamily}
            textAnchor="middle"
            angle={270}
            fill={primaryBlue}
          >
            {biomarkerName}
          </Text>
        ) : null}
        <rect fill="none" stroke={primaryBlue} height={height} width={innerWidth} strokeWidth={1} />
        <Group pointerEvents="none">
          {sections}
          {points}
          {averagePoints}
          {showBottomAxis ? (
            <Axis
              orientation="bottom"
              scale={xScaleForAxis}
              top={height}
              numTicks={totalPens}
              stroke={primaryBlue}
              tickStroke={primaryBlue}
              tickLabelProps={() => ({
                transform: `translate(${widthPerPen / 2}, 0)`,
                textAnchor: 'middle',
                scaleToFit: 'shrink-only',
                fill: primaryBlue,
              })}
            />
          ) : null}
        </Group>
      </Group>
    </>
  );
}
