﻿import React, { useEffect, useState } from 'react';
import { DatesRangeValue, MonthPickerInput } from '@mantine/dates';
import BatchList from '../batch-list/BatchList';
import { BatchDto } from '../../api/models';

function DateRangePicker({
  batchDateRange,
  setBatchDateRange,
  batches,
  filteredBatchesCount,
}: {
  batchDateRange: DatesRangeValue | undefined;
  setBatchDateRange: (value: DatesRangeValue | undefined) => void;
  batches: BatchDto[];
  filteredBatchesCount: number;
}) {
  return (
    <MonthPickerInput
      type="range"
      label="Date Range"
      placeholder="Pick two dates"
      description={`Showing ${filteredBatchesCount} of ${batches.length} batches`}
      inputWrapperOrder={['label', 'input', 'description', 'error']}
      value={batchDateRange}
      onChange={setBatchDateRange}
      allowSingleDateInRange
      clearable
      minDate={batches[0].dateCollected}
      maxDate={batches[batches.length - 1].dateCollected}
      mx="auto"
      maw={400}
      style={{ margin: 0 }}
    />
  );
}

export interface DataFilteringProps {
  allBatches: BatchDto[];
  selectedBatchIds: Set<number>;
  setSelectedBatchIds: (ids: Set<number>) => void;
  setFilteredBatches: (batches: BatchDto[]) => void;
}

export default function DataFiltering({
  allBatches,
  selectedBatchIds,
  setSelectedBatchIds,
  setFilteredBatches,
}: DataFilteringProps) {
  const getDefaultRange = (): DatesRangeValue | undefined => (allBatches.length > 0
    ? [allBatches[0].dateCollected, allBatches[allBatches.length - 1].dateCollected]
    : undefined);

  const [batchDateRange, setBatchDateRange] = useState<DatesRangeValue | undefined>(
    getDefaultRange(),
  );

  const batchesFilteredByDateRange = batchDateRange && batchDateRange[0] && batchDateRange[1]
    ? allBatches.filter((b) => {
      const dateWithoutTime = new Date(b.dateCollected.toDateString());
      const lowerBound = new Date(batchDateRange[0]!.toDateString());
      const upperBound = new Date(
        batchDateRange[1]!.getFullYear(),
        batchDateRange[1]!.getMonth() + 1,
        1,
      );

      return dateWithoutTime >= lowerBound && dateWithoutTime < upperBound;
    })
    : allBatches;

  const selectableBatchIds = batchesFilteredByDateRange.map((b) => b.id);

  useEffect(() => {
    setBatchDateRange(getDefaultRange());
  }, [allBatches]);

  useEffect(() => {
    setSelectedBatchIds(new Set(selectableBatchIds));
  }, [batchDateRange]);

  useEffect(() => {
    setFilteredBatches(batchesFilteredByDateRange.filter((b) => selectedBatchIds.has(b.id)));
  }, [batchDateRange, selectedBatchIds]);

  const toggleBatch = (batchId: number) => () => {
    const newSelectedBatchIds = new Set(selectedBatchIds);

    if (selectedBatchIds.has(batchId)) {
      newSelectedBatchIds.delete(batchId);
    } else {
      newSelectedBatchIds.add(batchId);
    }

    setSelectedBatchIds(newSelectedBatchIds);
  };

  const toggleSelectAllBatches = () => {
    const selectedBatchIdsSet = new Set(selectedBatchIds);
    const allBatchesSelected = selectableBatchIds.every((id) => selectedBatchIdsSet.has(id));

    if (allBatchesSelected) {
      setSelectedBatchIds(new Set<number>());
    } else {
      setSelectedBatchIds(new Set(selectableBatchIds));
    }
  };

  return (
    <>
      {batchesFilteredByDateRange.length ? (
        <DateRangePicker
          batchDateRange={batchDateRange}
          setBatchDateRange={setBatchDateRange}
          batches={batchesFilteredByDateRange}
          filteredBatchesCount={batchesFilteredByDateRange.length}
        />
      ) : null}
      <BatchList
        batches={batchesFilteredByDateRange}
        selectedBatchIds={selectedBatchIds}
        toggleBatch={toggleBatch}
        toggleSelectAllBatches={toggleSelectAllBatches}
      />
    </>
  );
}
