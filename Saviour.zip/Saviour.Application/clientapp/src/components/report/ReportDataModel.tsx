﻿import {
  AnalysisDto, BatchDto, ReportCompanyDto, SiteDto, UserDto,
} from '../../api/models';

export interface ReportDataModel {
  id: number;
  siteLocalId: number;
  createdOn: Date;
  createdBy: UserDto;
  reviewedBy?: UserDto;
  reviewedOn?: Date;
  company: ReportCompanyDto;
  site: SiteDto;
  observations: string;
  processDeviations: string;
  batches: BatchDto[];
  analyses: AnalysisDto[]
}
