﻿import classes from "./Reports.module.css";

export default function ErrorMessage({message}: { message?: string }) {
  return message == undefined
    ? null
    : <p className={classes.errorText}>{message}</p>
}