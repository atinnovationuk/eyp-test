﻿import React, { useEffect, useState } from 'react';
import { Tabs, TabsValue } from '@mantine/core';
import { faFileExport } from '@fortawesome/free-solid-svg-icons';
import fileDownload from 'js-file-download';
import { GraphSizeSettings } from './ReportGraph';
import GenerateCsvReport from '../../export/csv/CsvExport';
import { AnalysisDto, BatchDto } from '../../api/models';
import ErrorMessage from './ErrorMessage';
import DataFiltering from './DataFiltering';
import GraphZoom from './GraphZoom';
import ReportData from './ReportData';
import { DataDisplayOption, ToggleDataDisplay } from './DataDisplayOption';
import HaemolysisTable from './HaemolysisTable';
import { IconButton } from '../IconButton';
import { MLPredictionPane } from '../MLModel/MLPredictionPane';
import { BatchInformationPane } from "./BatchInformationPane";

function CsvExportButton({ doExport }: { doExport: () => Promise<void> }) {
  return (
    <IconButton icon={faFileExport} onClick={doExport}>
      Export data
    </IconButton>
  );
}

function applySorting(batches: BatchDto[]) {
  // sort batches in descending date order
  batches.sort((a, b) => a.dateCollected.valueOf() - b.dateCollected.valueOf());

  // sort samples by pen
  batches.forEach((batch) => batch.samples.sort((a, b) => a.pen.localeCompare(b.pen)));
}

export function ReportDataView({
  analyses,
  batches,
  selectedBatchIds,
  setSelectedBatchIds,
  filteringEnabled,
  dataTableEnabled,
  exportEnabled,
  showHaemolysisTable,
}: {
  analyses: AnalysisDto[];
  batches: BatchDto[];
  selectedBatchIds: Set<number>;
  setSelectedBatchIds: (ids: Set<number>) => void;
  filteringEnabled: boolean;
  dataTableEnabled: boolean;
  exportEnabled: boolean;
  showHaemolysisTable: boolean;
}) {
  const [activeTab, setActiveTab] = useState<TabsValue>(
    analyses.length > 0 ? analyses[0].name : '',
  );
  const [displayOption, setDisplayOption] = useState<DataDisplayOption>(DataDisplayOption.Graph);

  const isInvalid = analyses.length === 0 || batches.length === 0;

  const [filteredBatches, setFilteredBatches] = useState<BatchDto[]>(batches);

  const [scale, setScale] = useState(1.0);

  const sizeSettings: GraphSizeSettings = {
    widthPerPen: 40 * scale,
    heightPerBiomarker: 200 * scale,
  };

  useEffect(() => {
    applySorting(batches);

    setFilteredBatches(batches);
  }, [batches]);

  const exportCsv = async () => {
    const csv = GenerateCsvReport(analyses, filteredBatches);

    fileDownload(csv, 'Batch-Export.csv');
  };

  if (isInvalid) {
    return <ErrorMessage message="Invalid report" />;
  }

  return (
    <div>
      <Tabs value={activeTab} onTabChange={setActiveTab}>
        <Tabs.List>
          {analyses.map((analysis) => (
            <Tabs.Tab key={analysis.name} value={analysis.name}>
              {analysis.name}
            </Tabs.Tab>
          ))}
          <Tabs.Tab key="ML Predictions" value="ML">
            ML PREDICTIONS
          </Tabs.Tab>
          <Tabs.Tab key="Batch Information" value="BI">
            BATCH INFORMATION
          </Tabs.Tab>          
        </Tabs.List>
      </Tabs>

      { activeTab === 'BI' ? <BatchInformationPane siteId={batches[0].siteId} batches={batches} /> :
        activeTab === 'ML' ? <MLPredictionPane siteId={batches[0].siteId} batches={batches} />
        : (
          <div
            style={{
              display: 'inline-flex',
              gap: '12px',
            }}
          >
            <div>
              {filteringEnabled ? (
                <DataFiltering
                  allBatches={batches}
                  selectedBatchIds={selectedBatchIds}
                  setSelectedBatchIds={setSelectedBatchIds}
                  setFilteredBatches={setFilteredBatches}
                />
              ) : null}

              {dataTableEnabled ? (
                <ToggleDataDisplay
                  displayOption={displayOption}
                  setDisplayOption={setDisplayOption}
                />
              ) : null}

              {exportEnabled ? <CsvExportButton doExport={exportCsv} /> : null}
            </div>

            <div>
              {displayOption === DataDisplayOption.Graph ? (
                <GraphZoom scale={scale} setScale={setScale} />
              ) : null}

              <ReportData
                batches={filteredBatches}
                analysis={analyses.find((analysis) => analysis.name === activeTab)!}
                displayOption={displayOption}
                sizeSettings={sizeSettings}
              />
            </div>
          </div>
        )}

      {showHaemolysisTable ? <HaemolysisTable batches={filteredBatches} /> : null}
    </div>
  );
}
