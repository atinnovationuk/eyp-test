﻿import { AnalysisDto, BatchDto } from '../../api/models';
import ReportGraph, { GraphSizeSettings } from './ReportGraph';
import { ReportTable } from './ReportTable';
import { DataDisplayOption } from './DataDisplayOption';

export default function ReportData({
  batches,
  analysis,
  displayOption,
  sizeSettings,
}: {
  batches: BatchDto[];
  analysis: AnalysisDto;
  displayOption: DataDisplayOption;
  sizeSettings: GraphSizeSettings;
}) {
  return displayOption === DataDisplayOption.Graph ? (
    <ReportGraph batches={batches} analysisGrouping={analysis} sizeSettings={sizeSettings} />
  ) : (
    <ReportTable batches={batches} analysis={analysis} />
  );
}
