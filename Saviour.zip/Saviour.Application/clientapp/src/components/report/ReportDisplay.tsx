﻿import { Button, Table } from '@mantine/core';
import React from 'react';
import { ProblemDetails } from '../../api/models';
import { ErrorType } from '../../../orvalCustomAxiosInstance';
import LoadingPrompt from '../LoadingPrompt';
import { ReportDataModel } from './ReportDataModel';
import { ReportDataView } from './ReportDataView';
import { useIdentityContext } from '../../auth/IdentityContext';
import { IdentityType } from '../../auth/IdentityType';

interface ReportDisplayProps {
  isLoading: boolean;
  error: ErrorType<ProblemDetails> | null;
  data?: ReportDataModel;
  downloadPdf: () => Promise<void>;
}

export function ReportDisplay(props: ReportDisplayProps) {
  const identity = useIdentityContext();
  const isAnalyst = identity === IdentityType.Analyst;

  const { isLoading, error, data: report, downloadPdf } = props;

  if (isLoading) {
    return <LoadingPrompt />;
  }

  if (error) {
    return (
      <p>
        Failed to load report:
        {error.message}
      </p>
    );
  }

  if (!report) {
    return <p>Failed to load report</p>;
  }

  return (
    <div>
      <h2>Results Report</h2>

      <Table>
        <tbody>
          <tr>
            <th>Company Name</th>
            <td>{report.company.name}</td>
          </tr>
          <tr>
            <th>Site Name</th>
            <td>{report.site.name}</td>
          </tr>
          <tr>
            <th>Issue Date</th>
            <td>{report.createdOn.toLocaleDateString()}</td>
          </tr>
          <tr>
            <th>Created By</th>
            <td>{report.createdBy.name}</td>
          </tr>
          <tr>
            <th>Authorised By</th>
            <td>{report.reviewedBy?.name ?? '-'}</td>
          </tr>
        </tbody>
      </Table>

      <Table>
        <thead>
          <tr>
            <th>Batch Number</th>
            <th>Sampling Date</th>
            <th>Processing Date</th>
            <th>Receipt Date</th>
          </tr>
        </thead>
        <tbody>
          {report.batches.map((batch) => (
            <tr key={batch.batchNumber}>
              <td>{batch.batchNumber}</td>
              <td>{batch.dateCollected.toLocaleDateString()}</td>
              <td>{batch.dateAnalysed.toLocaleDateString()}</td>
              <td>{batch.dateReceived.toLocaleDateString()}</td>
            </tr>
          ))}
        </tbody>
      </Table>

      <h3>Clinical Observations</h3>
      <p>{report.observations}</p>

      <h3>Process Deviations</h3>
      <p>{report.processDeviations || 'None'}</p>

      <ReportDataView
        analyses={report.analyses}
        batches={report.batches}
        filteringEnabled={false}
        selectedBatchIds={new Set(report.batches.map((b) => b.id))}
        setSelectedBatchIds={() => {}}
        dataTableEnabled={isAnalyst}
        exportEnabled={false}
        showHaemolysisTable={isAnalyst}
      />

      <Button onClick={() => downloadPdf()}>Download as PDF</Button>
    </div>
  );
}
