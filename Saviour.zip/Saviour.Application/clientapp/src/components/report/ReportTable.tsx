﻿import { Table } from '@mantine/core';
import React from 'react';
import { AnalysisDto, BatchDto, WaterType } from '../../api/models';
import classes from './Reports.module.css';

function waterTypeToString(waterType: WaterType) {
  switch (waterType) {
    case 'FreshWater':
      return 'Fresh Water';
    case 'SeaWater':
      return 'Sea Water';
  }
}

export function ReportTable(
  {
    batches,
    analysis,
  }: { batches: BatchDto[], analysis: AnalysisDto },
) {
  return (
    <div>
      {batches.map((batch) => (
        <div key={batch.batchNumber}>
          <Table className={classes.batchTable}>
            <thead>
              <tr>
                <th>Batch</th>
                <th>Date Collected</th>
                <th>Date Analysed</th>
                <th>Receipt Date</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{batch.batchNumber}</td>
                <td>{batch.dateCollected.toLocaleDateString()}</td>
                <td>{batch.dateAnalysed.toLocaleDateString()}</td>
                <td>{batch.dateAnalysed.toLocaleDateString()}</td>
              </tr>
            </tbody>
          </Table>
          <Table
            highlightOnHover
            withColumnBorders
          >
            <thead>
              <tr>
                <th>Sample</th>
                <th>Pen</th>
                {
                analysis.biomarkers.map((b) => <th key={b.name}>{b.name}</th>)
              }
                <th>Species</th>
                <th>Water Type</th>
                <th>Fish Number</th>
                <th>Average Weight</th>
                <th>Temperature</th>
                <th>Oxygen Level</th>
                <th>Mortality Rate</th>
                <th>Strain</th>
                <th>Hatcheries</th>
              </tr>
            </thead>
            <tbody>
              {batch.samples.map((sample) => (
                <tr key={sample.sampleCode}>
                  <td>{sample.sampleCode}</td>
                  <td>{sample.pen}</td>
                  {
                analysis.biomarkers.map((b) => <td key={b.name}>{sample.biomarkerResults[b.name] ?? '-'}</td>)
              }
                  <td>{sample.species}</td>
                  <td>{waterTypeToString(sample.waterType)}</td>
                  <td>{sample.fishNumber}</td>
                  <td>
                    {sample.averageWeightInGrams}
                    g
                </td>
                  <td>
                    {sample.temperatureInCelsius}
                    °C
                </td>
                  <td>{sample.oxygenLevelInMg == null ? '-' : `${sample.oxygenLevelInMg}mg`}</td>
                  <td>
                    {sample.mortalityRatePercentage}
                    %
                </td>
                  <td>{sample.strain ? sample.strain : '-'}</td>
                  <td>{sample.hatcheries.join(', ')}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      ))}
    </div>
  );
}
