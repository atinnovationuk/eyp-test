﻿import {Link} from "react-router-dom";
import React from "react";
import classes from "./Reports.module.css";

export function GetReportRoute(reportId: number, isDraft: boolean) {
  return isDraft
    ? `/reports/draft/${reportId}`
    : `/reports/${reportId}`;
}

export default function ReportLink({ report, isDraft }: { report: { id: number, createdOn: Date }, isDraft: boolean }) {

  const destination = GetReportRoute(report.id, isDraft);

  return <Link to={destination} className={classes.link}>
    {report.createdOn.toLocaleDateString()}
  </Link>;
}
