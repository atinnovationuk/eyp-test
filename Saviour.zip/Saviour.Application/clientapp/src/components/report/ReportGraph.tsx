import { groupBy } from 'lodash-es';
import { AnalysisDto, BatchDto, SampleDto } from '../../api/models';
import GraphSection from './GraphSection';
import { getMinMaxBiomarkerResults } from './ResultScale';
import { Group } from '@visx/group';
import { primaryBlue } from '../Colours';

const margin = {
  left: 40,
  right: 40,
  top: 40,
  bottom: 40,
};

const spacing = 3;

export interface GraphSizeSettings {
  widthPerPen: number;
  heightPerBiomarker: number;
}

export function GetGraphSize(
  batches: BatchDto[],
  { widthPerPen, heightPerBiomarker }: GraphSizeSettings
) {
  const height = heightPerBiomarker * 3 + margin.top + margin.bottom + 2 * spacing;

  const totalPens = batches
    .map((b) => new Set(b.samples.map((sample) => sample.pen)).size)
    .reduce((previousValue, currentValue) => previousValue + currentValue, 0);

  const width = widthPerPen * totalPens + margin.left + margin.right;

  return {
    width,
    height,
  };
}

export default function ReportGraph({
  batches,
  analysisGrouping,
  sizeSettings,
}: {
  batches: BatchDto[];
  analysisGrouping: AnalysisDto;
  sizeSettings: GraphSizeSettings;
}) {
  const { width, height } = GetGraphSize(batches, sizeSettings);

  const { widthPerPen, heightPerBiomarker } = sizeSettings;

  const biomarkers = analysisGrouping.biomarkers;
  return (
    <div>
      <svg width={width} height={height} preserveAspectRatio="xMinYMin meet">
        {biomarkers.map((biomarker, biomarkerIndex) => {
          let nextStartX = margin.left;

          const minMax = getMinMaxBiomarkerResults(biomarker, batches);

          return batches.map((batch, batchIndex) => {
            const allSamples = batch.samples;
            const validSamples = allSamples.filter((s) => !!s.biomarkerResults[biomarker.name]);

            const allPens = new Set(allSamples.map((s) => s.pen));
            const samplesGroupedByPen: { [key: string]: SampleDto[] } = groupBy(
              validSamples,
              (s) => s.pen
            );

            const startX = nextStartX;
            const numberOfPens = allPens.size;
            nextStartX += numberOfPens * widthPerPen;

            const isLastBiomarker = biomarkerIndex == biomarkers.length - 1;
            const sectionWidth = widthPerPen * numberOfPens;

            const startY = (heightPerBiomarker + spacing) * biomarkerIndex + margin.top;
            return (
              <Group pointerEvents="none" key={batch.batchNumber}>
                <GraphSection
                  height={heightPerBiomarker}
                  samples={validSamples}
                  samplesGroupedByPen={samplesGroupedByPen}
                  biomarker={biomarker}
                  minMax={minMax}
                  startX={startX}
                  startY={startY}
                  widthPerPen={widthPerPen}
                  allPens={Array.from(allPens)}
                  showBottomAxis={isLastBiomarker}
                  batchDate={biomarkerIndex === 0 ? batch.dateCollected.toLocaleDateString() : ''}
                  showLeftLabel={batchIndex === 0}
                  index={batchIndex}
                />

                {isLastBiomarker ? null : (
                  <rect
                    stroke={primaryBlue}
                    fill={primaryBlue}
                    x={startX - 0.5}
                    y={startY + heightPerBiomarker}
                    strokeWidth={1}
                    height={spacing}
                    width={sectionWidth + 1}
                  />
                )}
              </Group>
            );
          });
        })}
      </svg>
    </div>
  );
}
