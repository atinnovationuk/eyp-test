import {Loader, Select} from '@mantine/core';
import {useState} from 'react';
import {useGetApiFishHealthResult} from '../../api/fish-health-result/fish-health-result';
import {BatchDto} from '../../api/models';
import classes from './BatchInformationPane.module.css';

export function BatchInformationPane({siteId, batches}: { siteId: string, batches: BatchDto[] }) {
    const [selectedBatchId, setSelectedBatchId] = useState<string | null>(batches[0]?.id?.toString());

    function GetChildToRender() {
        const batch = batches
            .find((p) => p.id === +selectedBatchId!);

        if (batch) {
            return <div>
                <div>Fish Health History: {batch.fishHealthHistory} </div>
                <div>Confirmed Condition: {batch.confirmedCondition}</div>
            </div>
        } else {
            return <div>Please select a batch</div>;
        }
    }

    return (
        <div className={classes.container}>
            <Select
                label="Select a batch"
                placeholder="Pick one"
                data={batches.map((b) => ({value: b.id.toString(), label: b.dateCollected.toLocaleDateString()}))}
                onChange={setSelectedBatchId}
                value={selectedBatchId}
                className={classes.select}
            />
            {GetChildToRender()}
        </div>
    );
}
