﻿import {ReportSummary, ReportSummaryPerSiteData} from "../../api/models";
import {ErrorType} from "../../../orvalCustomAxiosInstance";
import LoadingPrompt from "../../components/LoadingPrompt";
import {LoadFailedMessage} from "../LoadFailedMessage";
import {PerSiteData} from "../../models/CompanySortedData";
import ReportLink from "../../components/report/ReportLink";
import React from "react";

export function ReportList({isLoading, data, error, isDraft}: {
  isLoading: boolean,
  data?: ReportSummaryPerSiteData[]
  error: ErrorType<any> | null,
  isDraft: boolean
}) {

  if (isLoading) {
    return <LoadingPrompt/>
  }

  if (data == undefined) {
    return <LoadFailedMessage error={error}/>
  }

  const dataPerSite = data as unknown as PerSiteData<ReportSummary>[];
  
  const noReports = dataPerSite.every(site => site.data.length === 0);
  if (noReports) {
    return <p>None</p>
  }

  return (
    <>
      {
        dataPerSite.map((site, siteIndex) => (
          <div key={`site-${siteIndex}`}>
            <h3>{site.site.name}</h3>
            {site.data.map(report => (
              <p key={`report-${report.id}`}>
                <ReportLink
                  report={report}
                  isDraft={isDraft}
                />
              </p>
            ))}
          </div>
        ))
      }
    </>
  );
}