﻿import { DefaultProps } from '@mantine/styles/lib/theme/types/DefaultProps';
import { Radio } from '@mantine/core';
import classes from './Reports.module.css';
export enum DataDisplayOption {
  Graph = 'Graph',
  Table = 'Table',
}

export function ToggleDataDisplay({
  displayOption,
  setDisplayOption,
  ...props
}: {
  displayOption: DataDisplayOption;
  setDisplayOption: (value: DataDisplayOption) => void;
} & DefaultProps) {
  return (
    <Radio.Group
      label="Display Data As"
      value={displayOption}
      onChange={setDisplayOption}
      {...props}
    >
      <Radio className={classes.radio} label="Graph" value={DataDisplayOption.Graph} />
      <Radio className={classes.radio} label="Table" value={DataDisplayOption.Table} />
    </Radio.Group>
  );
}
