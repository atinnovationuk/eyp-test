﻿import { BatchDto, SampleDto } from '../../api/models';
import { Accordion, Table } from '@mantine/core';
import React, { useState } from 'react';

function findHaemolysisScore(sample: SampleDto) {
  const haemolysis = sample.biomarkerResults['SI2-H'];
  return haemolysis == null ? '-' : haemolysis;
}

export default function HaemolysisTable({ batches }: { batches: BatchDto[] }) {
  const [value, setValue] = useState<string | null>(null);

  const title = value == null ? 'Show Haemolysis Scores' : 'Hide Haemolysis Scores';

  return (
    <Accordion value={value} onChange={setValue}>
      <Accordion.Item value={'haemolysis'}>
        <Accordion.Control>{title}</Accordion.Control>
        <Accordion.Panel>
          <Table>
            <thead>
              <tr>
                <th>Batch</th>
                <th>Sample</th>
                <th>Haemolysis Score</th>
              </tr>
            </thead>
            <tbody>
              {batches.map((batch) =>
                batch.samples.map((sample) => (
                  <tr key={sample.sampleCode}>
                    <td>{batch.dateCollected.toLocaleDateString()}</td>
                    <td>{sample.sampleCode}</td>
                    <td>{findHaemolysisScore(sample)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </Table>
        </Accordion.Panel>
      </Accordion.Item>
    </Accordion>
  );
}
