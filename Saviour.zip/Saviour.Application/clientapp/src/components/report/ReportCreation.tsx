﻿import { useForm } from '@mantine/form';
import { faCloudArrowUp } from '@fortawesome/free-solid-svg-icons';
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Textarea, Button } from '@mantine/core';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { usePostApiReports } from '../../api/reports/reports';
import { CompanyDto, NewReport } from '../../api/models';
import { GetReportRoute } from './ReportLink';
import ErrorMessage from './ErrorMessage';

export default function ReportCreation({
  company,
  siteId,
  batchIds,
  analysisIds,
}: {
  company: CompanyDto;
  siteId: string;
  batchIds: Set<number>;
  analysisIds: number[];
}) {
  const { mutateAsync: sendNewReport } = usePostApiReports({});
  const navigate = useNavigate();
  const [error, setError] = useState<string>();
  const [disabled, setDisabled] = useState<boolean>(false);

  const form = useForm<NewReport>({
    initialValues: {
      siteId,
      batchIds: [],
      analysisIds,
      observations: '',
      processDeviations: '',
    },
  });

  useEffect(() => {
    const addressIsMissing = company.address.trim() === '';
    setDisabled(addressIsMissing);
    if (addressIsMissing) {
      setError(
        'Cannot create report: Company address is missing\n' +
          'Please enter this in the Company Management page and try again'
      );
    }
  }, [company]);

  async function postNewReport(data: NewReport) {
    try {
      data.batchIds = Array.from(batchIds);

      const createdReport = await sendNewReport({ data });

      navigate(GetReportRoute(createdReport.id, true), { replace: true });
    } catch (e) {
      const reason = e instanceof Error ? e.message : 'Unknown';

      setError(`Failed to create report: ${reason}`);
    }
  }

  return (
    <form onSubmit={form.onSubmit(postNewReport)}>
      <Textarea
        {...form.getInputProps('observations')}
        placeholder="Enter Clinical Observations..."
        required
        label="Clinical Observations"
      />

      <Textarea
        {...form.getInputProps('processDeviations')}
        placeholder="Enter Any Process Deviations (Optional)..."
        label="Process Deviations"
      />

      <Button
        style={{ marginTop: '6px' }}
        leftIcon={<FontAwesomeIcon icon={faCloudArrowUp} />}
        type="submit"
        disabled={batchIds.size === 0 || disabled}
      >
        Save
      </Button>

      <ErrorMessage message={error} />
    </form>
  );
}
