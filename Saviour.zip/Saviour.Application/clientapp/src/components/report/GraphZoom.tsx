﻿import { Slider } from '@mantine/core';

export default function GraphZoom({
  scale,
  setScale,
}: {
  scale: number;
  setScale: (newScale: number) => void;
}) {
  return (
    <Slider
      styles={{
        root: {
          marginBottom: '1.5em',
          width: '20em',
        },
      }}
      value={scale}
      onChange={setScale}
      min={0.5}
      max={5.0}
      step={0.25}
      label={(value) => `${Math.round(value * 100)}%`}
      marks={[
        { value: 0.5, label: '50%' },
        { value: 1.0, label: '100%' },
        { value: 2.0, label: '200%' },
        { value: 3.0, label: '300%' },
        { value: 4.0, label: '400%' },
        { value: 5.0, label: '500%' },
      ]}
    />
  );
}
