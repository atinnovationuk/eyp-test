import { AnalysisBiomarkerDto, BatchDto } from '../../api/models';

export interface MinMaxValues {
  min: number;
  max: number;
}

export function getMinMaxBiomarkerResults(
  biomarker: AnalysisBiomarkerDto,
  batches: BatchDto[]
): MinMaxValues {
  let min = Number.MAX_VALUE;
  let max = Number.MIN_VALUE;

  batches.forEach((batch) =>
    batch.samples.forEach((sample) => {
      const result = sample.biomarkerResults[biomarker.name];
      if (result == null) {
        return;
      }

      min = Math.min(min, result);
      max = Math.max(max, result);
    })
  );

  // add a small offset so that points at the boundaries aren't trimmed
  const smallOffset = (max - min) / 500;
  min -= smallOffset;
  max += smallOffset;

  // Keep the red regions at least 10% of the size of the adjacent amber region
  const lowestMin = biomarker.lowRed - (biomarker.lowAmber - biomarker.lowRed) / 10;
  min = Math.min(min, lowestMin);

  const highestMax = biomarker.highAmber + (biomarker.highAmber - biomarker.reference) / 10;
  max = Math.max(max, highestMax);

  // prevent going out of range
  min = Math.max(min, biomarker.min);
  max = Math.min(max, biomarker.max);

  return { min, max };
}
