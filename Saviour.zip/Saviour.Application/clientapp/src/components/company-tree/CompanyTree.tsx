import { NodeApi, NodeRendererProps, Tree, TreeApi } from 'react-arborist';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Loader } from '@mantine/core';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleRight, faAngleDown } from '@fortawesome/free-solid-svg-icons';
import clsx from 'clsx';
import { BatchDto, CompanyDto, SiteDto } from '../../api/models';
import classes from './CompanyTree.module.css';
import { useGetApiCompany, useGetApiCompanyCompanyId } from '../../api/company/company';
import FillFlexParent from '../FillFlexParent';
import LoadingPrompt from '../LoadingPrompt';

enum NodeType {
  CompanyNode = 'CompanyNode',
  SiteNode = 'SiteNode',
}

type TreeNodeData = SiteDto | BatchDto | CompanyDto;

type TreeRow<T> = {
  id: string;
  dto: T;
  canExpand: boolean;
  isChildrenLoading?: boolean;
  name: string;
  type: NodeType;
  route: string;
  children?: TreeRow<SiteDto | BatchDto | CompanyDto>[];
};

interface RowQuery {
  isLoading: boolean;
  hasData: boolean;
  getChildren: () => TreeRow<TreeNodeData>[];
}

function useRowQuery(node: NodeApi<TreeRow<TreeNodeData>>): RowQuery {
  const runQuery = node.data.isChildrenLoading ?? false;

  switch (node.data.type) {
    case NodeType.CompanyNode: {
      const company = node.data.dto as CompanyDto;

      const { isLoading, data: sites } = useGetApiCompanyCompanyId(company.id, {
        query: { enabled: runQuery },
      });

      return {
        isLoading,
        hasData: sites != null,
        getChildren: () =>
          sites?.map((site) => {
            return {
              id: `site-${site.id}`,
              name: site.name,
              canExpand: false,
              dto: site,
              type: NodeType.SiteNode,
              route: `/company/${company.id}/site/${site.id}`,
            };
          }) ?? [],
      };
    }

    case NodeType.SiteNode: {
      return {
        isLoading: false,
        hasData: false,
        getChildren: () => [],
      };
    }
  }
}

type UpdateNodeCallback = (
  node: NodeApi<TreeRow<TreeNodeData>>,
  action: (rowData: TreeRow<TreeNodeData>) => TreeRow<TreeNodeData>
) => void;
type ToggleNodeCallback = (node: NodeApi<TreeRow<TreeNodeData>>) => void;

function Row(
  { node, style }: NodeRendererProps<TreeRow<TreeNodeData>>,
  updateNode: UpdateNodeCallback,
  toggleNode: ToggleNodeCallback
) {
  const { isLoading, hasData, getChildren } = useRowQuery(node);

  useEffect(() => {
    if (hasData && node.data.isChildrenLoading) {
      updateNode(node, (row) => {
        return {
          ...row,
          isChildrenLoading: false,
          children: getChildren(),
        };
      });
    }
  }, [isLoading, hasData]);

  const onExpanderClick = (
    event: React.MouseEvent<HTMLElement> | React.KeyboardEvent<HTMLElement>
  ) => {
    event.stopPropagation();
    toggleNode(node);
  };

  const getCaretIcon = () => {
    if (node.data.isChildrenLoading) {
      return <Loader size={15} className={classes.loader} />;
    }

    return node.data.canExpand ? (
      <span
        role="button"
        aria-expanded={node.isOpen}
        aria-label={`Load ${node.data.name}`}
        onClick={onExpanderClick}
        className={classes.caret}
      >
        <FontAwesomeIcon size="lg" icon={node.isOpen ? faAngleDown : faAngleRight} />
      </span>
    ) : null;
  };

  return (
    <div style={style} className={clsx(classes.item, node.isOnlySelection && classes.activeItem)}>
      {getCaretIcon()}
      <span role="link" onClick={() => node.select()} title={node.data.name}>
        {node.data.name}
      </span>
    </div>
  );
}

export default function CompanyTree() {
  const { isLoading, data: companies, error } = useGetApiCompany({});
  const [treeData, setTreeData] = useState<TreeRow<TreeNodeData>[]>([]);
  const treeRef = useRef<TreeApi<any>>();
  const navigate = useNavigate();

  const updateNode = useCallback(
    (
      node: NodeApi<TreeRow<TreeNodeData>>,
      update: (rowData: TreeRow<TreeNodeData>) => TreeRow<TreeNodeData>
    ) => {
      function updateRow(row: TreeRow<TreeNodeData>): TreeRow<TreeNodeData> {
        if (row.id === node.id) {
          return update(row);
        }

        return {
          ...row,
          children: row.children?.map(updateRow),
        };
      }

      setTreeData((tree) => tree.map(updateRow));
    },
    [setTreeData]
  );

  useEffect(() => {
    if (companies != undefined) {
      setTreeData(
        companies
          .filter((company) => company.siteCount != null && company.siteCount > 0)
          .map((company) => ({
            id: `company-${company.id}`,
            dto: company,
            canExpand: true,
            isChildrenLoading: false,
            type: NodeType.CompanyNode,
            name: company.name,
            route: `/company/${company.id}`,
          }))
      );
    } else {
      setTreeData([]);
    }
  }, [companies]);

  const toggleNode = (node: NodeApi<TreeRow<TreeNodeData>>) => {
    if (!node.data.canExpand) {
      return;
    }

    if (!node.isOpen && node.children == null) {
      updateNode(node, (data) => {
        return {
          ...data,
          isChildrenLoading: true,
        };
      });
    } else {
      node.toggle();
    }
  };

  const onNodeSelect = ([node]: NodeApi<TreeRow<TreeNodeData>>[]) => {
    if (!node) {
      return;
    }

    if (!node.isOpen) {
      toggleNode(node);
    }

    navigate(node.data.route.toLowerCase());
  };

  if (isLoading) {
    return <LoadingPrompt />;
  }

  if (error) {
    return (
      <div>
        Failed to load Customers:
        {error.message}
      </div>
    );
  }

  return (
    <FillFlexParent>
      {({ width, height }) => (
        <Tree
          data={treeData}
          disableDrag
          disableDrop
          disableEdit
          disableMultiSelection
          width={width}
          height={height}
          onSelect={onNodeSelect}
          ref={treeRef}
        >
          {(props) => Row(props, updateNode, toggleNode)}
        </Tree>
      )}
    </FillFlexParent>
  );
}
