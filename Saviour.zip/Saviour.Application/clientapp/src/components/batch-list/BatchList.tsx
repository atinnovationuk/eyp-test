import { Checkbox, Paper } from '@mantine/core';
import { BatchDto } from '../../api/models';
import classes from './BatchList.module.css';

export default function BatchList({
  batches,
  toggleBatch,
  toggleSelectAllBatches,
  selectedBatchIds,
}: { 
  batches: BatchDto[],
  selectedBatchIds: Set<number>,
  toggleBatch: (batchId: number) => () => void,
  toggleSelectAllBatches: () => void }
) {

  return (
    <Paper className={classes.paper} withBorder p="md">
      
      <h4 className={classes.title}>Batches</h4>

        {batches.length > 1 ? <Checkbox
        className={classes.Batch}
        label="Select All"
        onChange={toggleSelectAllBatches}
        checked={batches.every((b) => selectedBatchIds.has(b.id))}
      /> : null}
      
      {batches.map((b) => (
        <Checkbox
          key={b.id}
          className={classes.Batch}
          checked={selectedBatchIds.has(b.id)}
          label={`${b.dateCollected.toLocaleDateString()}`}
          onChange={toggleBatch(b.id)}
        />
      ))}
    </Paper>
  );
}
