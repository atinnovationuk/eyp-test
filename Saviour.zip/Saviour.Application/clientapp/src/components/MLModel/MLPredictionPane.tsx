import { Loader, Select } from '@mantine/core';
import { useState } from 'react';
import { useGetApiFishHealthResult } from '../../api/fish-health-result/fish-health-result';
import { BatchDto } from '../../api/models';
import { MLPieChart } from './MLPieChart';
import classes from './MLPredictionPane.module.css';

export function MLPredictionPane({ siteId, batches }: { siteId: string, batches: BatchDto[] }) {
  const fishHealthResults = useGetApiFishHealthResult({ siteId });
  const [selectedBatchId, setSelectedBatchId] = useState<string | null>(batches[0]?.id?.toString());

  function GetChildToRender() {
    if (fishHealthResults.isLoading) {
      return <Loader size={48} />;
    }

    const healthResultsForBatch = fishHealthResults.data!
      .find((p) => p.batchId === +selectedBatchId!);

    if (!healthResultsForBatch) {
      return <div>No ML data processed for selected batch</div>;
    }

    return Object.entries(healthResultsForBatch.penFishHealthResults)
      .sort(([a], [b]) => a.localeCompare(b, 'en', { numeric: true }))
      .map(([pen, healthyRatio]) => <MLPieChart key={pen} width={300} height={300} penFishHealthResult={{ index: pen, healthyRatio }} />);
  }

  return (
    <div className={classes.container}>
      <Select
        label="Select a batch"
        placeholder="Pick one"
        data={batches.map((b) => ({ value: b.id.toString(), label: b.dateCollected.toLocaleDateString() }))}
        onChange={setSelectedBatchId}
        value={selectedBatchId}
        className={classes.select}
      />
      {GetChildToRender()}
    </div>
  );
}
