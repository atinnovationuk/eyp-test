import React from 'react';
import { Pie } from '@visx/shape';
import { Group } from '@visx/group';
import { Text } from '@visx/text';

const defaultMargin = {
  top: 20, right: 20, bottom: 20, left: 20,
};

export type PieProps = {
  width: number;
  height: number;
  margin?: typeof defaultMargin;
  penFishHealthResult: { index: string, healthyRatio: number }
};

export function MLPieChart({
  width,
  height,
  margin = defaultMargin,
  penFishHealthResult,
}: PieProps) {
  const innerWidth = width - margin.left - margin.right;
  const innerHeight = height - margin.top - margin.bottom;
  const radius = Math.min(innerWidth, innerHeight) / 2;
  const centerY = innerHeight / 2;
  const centerX = innerWidth / 2;
  const top = centerY + margin.top;
  const left = centerX + margin.left;

  const unhealthyRatio = 100 - penFishHealthResult.healthyRatio;

  return (
    <svg width={width} height={height}>
      <Group top={margin?.top} left={margin?.left}>
        <Text textAnchor="start">
          {`Pen - ${penFishHealthResult.index}`}
        </Text>
      </Group>
      <Group top={top} left={left}>
        <Pie
          data={[{ label: 'Healthy', value: penFishHealthResult.healthyRatio }, { label: 'Unhealthy', value: unhealthyRatio }]}
          pieValue={(d) => d.value}
          outerRadius={radius}
        >
          {(pie) => pie.arcs.map((arc, index) => {
            const [centroidX, centroidY] = pie.path.centroid(arc);
            const arcPath = pie.path(arc);
            const arcFill = index === 0 ? '#4677af' : '#e78533';
            return (
              <g key={`arc-${arc.data.label}-${index}`}>
                <path d={arcPath!} fill={arcFill} />
                <Text
                  x={centroidX}
                  y={centroidY}
                  dy=".36em"
                  fill="#ffffff"
                  fontSize={14}
                  textAnchor="middle"
                  pointerEvents="none"
                >
                  {`${arc.data.label} (${arc.data.value}%)`}
                </Text>
              </g>
            );
          })}
        </Pie>
      </Group>
    </svg>
  );
}
