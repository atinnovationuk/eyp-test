﻿
export default function LoadingPrompt() {
  return <p>Loading...</p>
}