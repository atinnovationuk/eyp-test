﻿import React from "react";
import {ErrorType} from "../../orvalCustomAxiosInstance";
import ErrorMessage from "./report/ErrorMessage";

function GetErrorAndDetails(error: ErrorType<any> | null) {
  if (error == null) {
    return {
      reason: "Unknown error",
      details: null
    }
  }
  
  const response = error.response;
  
  const isTextResponse = response?.headers["content-type"] === "text/plain";
  
  const details = isTextResponse
    ? response!.data as string
    : null;
  
  return {
    reason: error.message,
    details
  }
}

export function LoadFailedMessage({error}: { error: ErrorType<any> | null }) {
  
  const { reason, details } = GetErrorAndDetails(error);

  let message = `Failed to load data: ${reason}. Consult browser logs for more information`;
  if (details != null) {
    message += '\n' + details;
  }

  return <ErrorMessage 
    message={message}
  />
}