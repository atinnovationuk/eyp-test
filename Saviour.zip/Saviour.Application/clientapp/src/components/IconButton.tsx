import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { ButtonHTMLAttributes } from 'react';
import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import { Button } from '@mantine/core';

export interface IconButtonProps extends ButtonHTMLAttributes<any> {
  icon: IconDefinition;
}

export function IconButton(props: IconButtonProps) {
  const { icon, children, ...buttonProps } = props;

  function Icon() {
    return <FontAwesomeIcon icon={icon} />;
  }

  const hasChildren = children != null;

  return (
    <Button leftIcon={hasChildren ? <Icon /> : null} {...buttonProps}>
      {hasChildren ? children : <Icon />}
    </Button>
  );
}
