import { test, expect } from 'vitest';

test('App', () => {
  expect(1 + 1).toEqual(2);
});
