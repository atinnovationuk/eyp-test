import { useParams } from 'react-router-dom';
import { useGetApiAnalysis } from '../../../api/analysis/analysis';
import LoadingPrompt from '../../../components/LoadingPrompt';
import ReportCreation from '../../../components/report/ReportCreation';
import {
  useGetApiCompanyCompanyCompanyId,
  useGetApiCompanySiteSiteId,
} from '../../../api/company/company';
import { ReportDataView } from '../../../components/report/ReportDataView';
import { useGetApiBatch } from '../../../api/batch/batch';
import { useEffect, useState } from 'react';

export default function SitePage() {
  const { companyId, siteId } = useParams();

  const { data: company, isLoading: companyLoading } = useGetApiCompanyCompanyCompanyId(
    companyId as string
  );
  const { data: site, isLoading: siteLoading } = useGetApiCompanySiteSiteId(siteId as string);
  const { data: batches, isLoading: batchesLoading } = useGetApiBatch({ siteId });
  const { data: analyses, isLoading: analysisLoading } = useGetApiAnalysis(
    { countryCode: site?.countryCode },
    {
      query: {
        enabled: site?.countryCode != undefined,
      },
    }
  );

  const getAllBatchIds = () => batches?.map((b) => b.id) ?? [];

  useEffect(() => {
    setSelectedBatchIds(new Set(getAllBatchIds()));
  }, [batches]);

  const [selectedBatchIds, setSelectedBatchIds] = useState<Set<number>>(new Set(getAllBatchIds()));

  const isLoading = analysisLoading || batchesLoading || siteLoading || companyLoading;

  return !isLoading && company && site && analyses && batches ? (
    <>
      <h2>{`${company.name} - ${site.name}`}</h2>

      <ReportDataView
        analyses={analyses}
        batches={batches}
        selectedBatchIds={selectedBatchIds}
        setSelectedBatchIds={setSelectedBatchIds}
        filteringEnabled={true}
        dataTableEnabled={true}
        exportEnabled={true}
        showHaemolysisTable={true}
      />

      <ReportCreation
        company={company}
        siteId={siteId!}
        batchIds={selectedBatchIds}
        analysisIds={analyses.map((a) => a.id)}
      />
    </>
  ) : (
    <LoadingPrompt />
  );
}
