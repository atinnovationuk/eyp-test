﻿import { useParams } from 'react-router-dom';
import {
  useGetApiUsersCompanyId,
  usePostApiUsersCompanyId,
  usePutApiUsers,
  useDeleteApiUsers,
} from '../../../api/users/users';
import { EmployeeDto } from '../../../api/models';
import { Input, Table } from '@mantine/core';
import { faCheck, faEdit, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { IconButton } from '../../../components/IconButton';
import React from 'react';
import { useForm } from '@mantine/form';
import { GetInputProps } from '@mantine/form/lib/types';
import { modals } from '@mantine/modals';
import LoadingPrompt from '../../../components/LoadingPrompt';
import { LoadFailedMessage } from '../../../components/LoadFailedMessage';
import { useGetApiCompanyCompanyCompanyId } from '../../../api/company/company';
import classes from './UserManagement.module.css';

interface EmployeeTableProps {
  data: EmployeeDto[];
  create: (employee: EmployeeDto) => Promise<any>;
  update: (employee: EmployeeDto) => Promise<any>;
  delete: (employee: EmployeeDto) => void;
}

interface EmployeeInputProps {
  employee?: EmployeeDto;
  formName: string;
  getInputProps: GetInputProps<EmployeeDto>;
}

interface ExistingEmployeeProps {
  employee: EmployeeDto;
  doUpdate: (employee: EmployeeDto) => Promise<any>;
  doDelete: (employee: EmployeeDto) => void;
}

function EmployeeInputs(props: EmployeeInputProps) {
  return (
    <>
      <td>
        <Input
          form={props.formName}
          {...props.getInputProps('name')}
          placeholder="Enter Name..."
          required={true}
          maxLength={128}
        />
      </td>
      <td>
        <Input
          form={props.formName}
          {...props.getInputProps('identity')}
          placeholder="Enter Email..."
          required={true}
          maxLength={256}
        />
      </td>
    </>
  );
}

function ExistingEmployeeRow({ employee, doDelete, doUpdate }: ExistingEmployeeProps) {
  const form = useForm<EmployeeDto>({
    initialValues: {
      id: employee.id,
      name: employee.name,
      identity: employee.identity,
    },
  });

  const formName = `edit-${employee.id}`;

  return (
    <>
      <EmployeeInputs employee={employee} formName={formName} getInputProps={form.getInputProps} />

      <td>
        <input type="hidden" form={formName} {...form.getInputProps('id')} />

        <IconButton form={formName} title="Update Employee" type="submit" icon={faEdit} />
        <IconButton
          title={'Delete ' + employee.name}
          icon={faTrashCan}
          onClick={() => doDelete(employee)}
        />

        <form id={formName} onSubmit={form.onSubmit(doUpdate)} />
      </td>
    </>
  );
}

function EmployeeTable(props: EmployeeTableProps) {
  const form = useForm<EmployeeDto>({
    initialValues: {
      id: -1,
      name: '',
      identity: '',
    },
  });

  async function createNew(employee: EmployeeDto) {
    await props.create(employee);
    form.reset();
  }

  const createNewForm = 'createNewEmployee';

  return (
    <>
      <form id={createNewForm} onSubmit={form.onSubmit(createNew)} />
      <Table className={classes.table}>
        <thead>
          <tr>
            <th>Name</th>
            <th>Email</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {props.data.map((employee) => (
            <tr key={employee.id}>
              <ExistingEmployeeRow
                employee={employee}
                doUpdate={props.update}
                doDelete={props.delete}
              />
            </tr>
          ))}

          <tr>
            <th>Add New Employee</th>
            <th></th>
            <th></th>
          </tr>
          <tr>
            <EmployeeInputs formName={createNewForm} getInputProps={form.getInputProps} />

            <td>
              <IconButton form={createNewForm} title="Create" type="submit" icon={faCheck} />
            </td>
          </tr>
        </tbody>
      </Table>
    </>
  );
}

export default function EmployeeManagementPage() {
  const { companyId } = useParams();

  const { data: company, isLoading: companyLoading } = useGetApiCompanyCompanyCompanyId(companyId!);
  const { data, isLoading: usersLoading, error, refetch } = useGetApiUsersCompanyId(companyId!);

  const isLoading = companyLoading || usersLoading;

  const mutationOptions = {
    mutation: {
      onSuccess: () => refetch(),
    },
  };

  const { mutateAsync: sendNewEmployee } = usePostApiUsersCompanyId(mutationOptions);
  const { mutateAsync: sendUpdateEmployee } = usePutApiUsers(mutationOptions);
  const { mutateAsync: sendDeleteEmployee } = useDeleteApiUsers(mutationOptions);

  if (isLoading) {
    return <LoadingPrompt />;
  }

  if (data == undefined) {
    return <LoadFailedMessage error={error} />;
  }

  function createEmployee(employee: EmployeeDto) {
    return sendNewEmployee({ companyId: companyId!, data: employee });
  }

  function updateEmployee(employee: EmployeeDto) {
    return sendUpdateEmployee({ data: employee });
  }

  function deleteEmployee(employee: EmployeeDto) {
    modals.openConfirmModal({
      title: 'Confirm deletion of ' + employee.name,
      labels: {
        confirm: 'Delete',
        cancel: 'Cancel',
      },
      onConfirm: () => sendDeleteEmployee({ params: { employeeId: employee.id } }),
      onCancel() {},
    });
  }

  return (
    <>
      <h2>User Management: {company!.name}</h2>

      <EmployeeTable
        data={data}
        create={createEmployee}
        update={updateEmployee}
        delete={deleteEmployee}
      />
    </>
  );
}
