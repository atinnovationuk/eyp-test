﻿import { Link } from 'react-router-dom';
import {
  useDeleteApiCompany,
  useGetApiCompany,
  usePostApiCompany,
  usePutApiCompany,
} from '../../../api/company/company';
import { CompanyDto, EditCompanyDto } from '../../../api/models';
import { faCheck, faCloudArrowUp, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import { IconButton } from '../../../components/IconButton';
import { Input, Table, Textarea } from '@mantine/core';
import { useForm } from '@mantine/form';
import { modals } from '@mantine/modals';
import LoadingPrompt from '../../../components/LoadingPrompt';
import classes from './UserManagement.module.css';

function CompanyRow({
  company,
  updateCompany,
  deleteCompany,
}: {
  company: CompanyDto;
  updateCompany: (data: EditCompanyDto) => Promise<void>;
  deleteCompany: () => void;
}) {
  const form = useForm<EditCompanyDto>({
    initialValues: {
      id: company.id,
      name: company.name,
      address: company.address,
    },
  });

  async function onSubmit(data: EditCompanyDto) {
    await updateCompany(data);
    form.resetDirty(data);
  }

  const formName = `update-${company.id}`;

  return (
    <tr key={company.id}>
      <td>
        <Link to={`./${company.id}`}>
          <div>{company.id}</div>
        </Link>
      </td>
      <td>
        <Link to={`./${company.id}`}>
          <div>{company.name}</div>
        </Link>
      </td>
      <td>
        <Textarea
          form={formName}
          {...form.getInputProps('address')}
          placeholder="Enter Address..."
          required={true}
          maxLength={500}
        />
      </td>
      <td>
        <IconButton
          form={formName}
          title={`Update ${company.name}`}
          icon={faCloudArrowUp}
          type="submit"
          disabled={!form.isDirty()}
        />

        <input type="hidden" form={formName} {...form.getInputProps('id')} />
        <input type="hidden" form={formName} {...form.getInputProps('name')} />
      </td>
      <td>
        {company.siteCount === 0 ? (
          <IconButton
            title={`Delete ${company.name}`}
            icon={faTrashCan}
            onClick={() => deleteCompany()}
          />
        ) : undefined}

        <form id={formName} onSubmit={form.onSubmit(onSubmit)} />
      </td>
    </tr>
  );
}

export default function CompanyManagementPage() {
  const { data, isLoading, refetch } = useGetApiCompany();

  const mutationOptions = {
    mutation: {
      onSuccess: () => refetch(),
    },
  };

  const { mutateAsync: sendNewCompany } = usePostApiCompany(mutationOptions);
  const { mutateAsync: sendDeleteCompany } = useDeleteApiCompany(mutationOptions);
  const { mutateAsync: sendUpdateCompany } = usePutApiCompany(mutationOptions);

  const form = useForm<EditCompanyDto>({
    initialValues: {
      id: '',
      name: '',
      address: '',
    },
  });

  async function postNewCompany(companyData: EditCompanyDto) {
    await sendNewCompany({ data: companyData });

    form.reset();
  }

  if (isLoading) {
    return <LoadingPrompt />;
  }

  async function updateCompany(data: EditCompanyDto) {
    await sendUpdateCompany({ data });
  }

  function deleteCompany(company: CompanyDto) {
    modals.openConfirmModal({
      title: 'Confirm deletion of ' + company.name,
      labels: {
        confirm: 'Delete',
        cancel: 'Cancel',
      },
      onConfirm: () => sendDeleteCompany({ params: { companyId: company.id } }),
      onCancel() {},
    });
  }

  const createNewForm = 'createNew';

  return (
    <>
      <h2>Company Management</h2>

      <form id={createNewForm} onSubmit={form.onSubmit(postNewCompany)} />

      <Table className={classes.table}>
        <thead>
          <tr>
            <th>Company Code</th>
            <th>Name</th>
            <th style={{ width: '40%' }}>Address</th>
            <th style={{ width: '5%' }}></th>
            <th style={{ width: '5%' }}></th>
          </tr>
        </thead>
        <tbody>
          {data?.map((company) => (
            <CompanyRow
              key={company.id}
              company={company}
              updateCompany={(data) => updateCompany(data)}
              deleteCompany={() => deleteCompany(company)}
            />
          ))}

          <tr>
            <th>Create New Company</th>
            <th></th>
            <th></th>
            <th></th>
          </tr>
          <tr>
            <td>
              <Input
                form={createNewForm}
                {...form.getInputProps('id')}
                placeholder="Enter Code..."
                required={true}
                maxLength={158}
              />
            </td>
            <td>
              <Input
                form={createNewForm}
                {...form.getInputProps('name')}
                placeholder="Enter Name..."
                required={true}
                maxLength={126}
              />
            </td>
            <td>
              <Textarea
                form={createNewForm}
                {...form.getInputProps('address')}
                placeholder="Enter Address..."
                required={true}
                maxLength={500}
              />
            </td>

            <td>
              <IconButton form={createNewForm} title="Create" icon={faCheck} type="submit" />
            </td>
          </tr>
        </tbody>
      </Table>
    </>
  );
}
