import { useParams } from 'react-router-dom';
import React from 'react';
import { useGetApiCompanyCompanyCompanyId } from "../../../api/company/company";
import LoadingPrompt from "../../../components/LoadingPrompt";
import {ReportList} from "../../../components/report/ReportList";
import {useGetApiUserDataCompanyCompanyId} from "../../../api/user-data/user-data";
import {LoadFailedMessage} from "../../../components/LoadFailedMessage";
import {useGetApiPendingWorkReportsCompanyId} from "../../../api/pending-work/pending-work";

export default function CompanyPage() {
  const { companyId } = useParams();
  
  const { data: company, isLoading: companyLoading, error: companyError } = useGetApiCompanyCompanyCompanyId(companyId!);

  const { isLoading: reportLoading, data: reportData, error: reportError } = useGetApiUserDataCompanyCompanyId(companyId!);
  const { isLoading: draftReportsLoading, data: draftReportData, error: draftReportError } = useGetApiPendingWorkReportsCompanyId(companyId!);

  if (companyLoading) {
    return <LoadingPrompt />
  }

  if (company == undefined) {
    return <LoadFailedMessage error={companyError} />
  }

  return (
    <>
      <h2>{company.name}</h2>
  
      <h2>Draft Reports</h2>
      <ReportList
        isLoading={draftReportsLoading}
        data={draftReportData}
        error={draftReportError}
        isDraft={true}
      />
      
      <h2>Reports</h2>
      <ReportList
        isLoading={reportLoading}
        data={reportData}
        error={reportError}
        isDraft={false}
      />
    </>
  );
}
