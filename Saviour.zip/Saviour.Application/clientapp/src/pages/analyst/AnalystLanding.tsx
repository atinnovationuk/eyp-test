﻿import { useGetApiPendingWork } from '../../api/pending-work/pending-work';
import classes from './Analyst.module.css';
import { BatchNeedingReport, ReportSummary } from '../../api/models';
import React from 'react';
import { CompanySortedData, DisplaySortedData } from '../../models/CompanySortedData';
import ReportLink from '../../components/report/ReportLink';
import LoadingPrompt from '../../components/LoadingPrompt';
import { LoadFailedMessage } from '../../components/LoadFailedMessage';
import { Link } from 'react-router-dom';

export default function AnalystLanding() {
  const { isLoading, data, error } = useGetApiPendingWork();

  if (isLoading) {
    return <LoadingPrompt />;
  }

  if (data == undefined) {
    return <LoadFailedMessage error={error} />;
  }

  // a bit of a hack to enable code reuse
  const typedBatches =
    data.batchesNeedingReport as unknown as CompanySortedData<BatchNeedingReport>[];
  const typedReports = data.reportsPendingReview as unknown as CompanySortedData<ReportSummary>[];

  return (
    <div className={classes.landing}>
      {DisplaySortedData(
        typedBatches,
        (needsReportCount) =>
          needsReportCount === 1 ? (
            <h2>There is 1 new batch requiring analysis</h2>
          ) : (
            <h2>There are {needsReportCount} new batches requiring analysis</h2>
          ),
        (batch, company, site) => (
          <p key={`batch-${batch.id}`}>
            <Link to={`company/${company.id}/site/${site.id}`}>
              {`${batch.dateCollected.toLocaleDateString()} ${batch.batchNumber}: ${
                batch.sampleCount
              } Samples`}
            </Link>
          </p>
        ),
        (a, b) => a.dateCollected.valueOf() - b.dateCollected.valueOf()
      )}

      {DisplaySortedData(
        typedReports,
        (needsReviewedCount) =>
          needsReviewedCount === 1 ? (
            <h2>There is 1 new report requiring review</h2>
          ) : (
            <h2>There are {needsReviewedCount} new reports requiring review</h2>
          ),
        (report) => (
          <p key={`report-${report.id}`}>
            <ReportLink report={report} isDraft={true} />
          </p>
        ),
        (a, b) => a.createdOn.valueOf() - b.createdOn.valueOf()
      )}
    </div>
  );
}
