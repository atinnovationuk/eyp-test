import React from 'react';
import { useGetApiUserData } from '../../api/user-data/user-data';
import { HttpStatusCode } from 'axios';
import { ReportList } from '../../components/report/ReportList';

export default function CustomerLanding() {
  const { isLoading, data, error } = useGetApiUserData();

  if (error?.response?.status === HttpStatusCode.Forbidden) {
    return (
      <div role="alert" aria-label="Unauthorised user account">
        <p>Your user account has not been associated with a place of work.</p>
        <p>
          Please contact a system administrator in Wellfish Tech to obtain appropriate
          access.
        </p>
      </div>
    );
  }

  return (
    <>
      <h2>{data?.company.name}</h2>
      <h2>Reports</h2>
      <ReportList isLoading={isLoading} data={data?.reports} error={error} isDraft={false} />
    </>
  );
}
