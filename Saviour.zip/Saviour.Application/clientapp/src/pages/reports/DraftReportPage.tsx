﻿import { useNavigate, useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useMsal } from '@azure/msal-react';
import { IPublicClientApplication } from '@azure/msal-browser';
import { faCheck, faTrashCan } from '@fortawesome/free-solid-svg-icons';
import fileDownload from 'js-file-download';
import {
  deleteApiReportsDraftsReportId,
  postApiReportsDraftsReportId,
  useGetApiReportsDraftsReportId,
} from '../../api/reports/reports';
import { GetReportRoute } from '../../components/report/ReportLink';
import { ReportDisplay } from '../../components/report/ReportDisplay';
import ErrorMessage from '../../components/report/ErrorMessage';
import { DraftReportDto } from '../../api/models';
import { IconButton } from '../../components/IconButton';
import { GeneratePdfReport, getPdfReportName } from '../../export/pdf/PdfReport';
import { useGetApiWhoAmIData } from '../../api/who-am-i/who-am-i';

interface ParamTypes {
  reportId: string;
}

interface State {
  disableButton: boolean;
  errorMessage?: string;
}

function getCurrentUserId(msal: IPublicClientApplication) {
  const activeUser = msal.getActiveAccount();

  return activeUser?.idTokenClaims?.oid;
}

function isReportCreatedByCurrentUser(report: DraftReportDto, msal: IPublicClientApplication) {
  const currentUserId = getCurrentUserId(msal);

  return report.createdBy.azureId === currentUserId;
}

function ApproveButton({
  disableButton,
  handleApprove,
}: {
  disableButton: boolean;
  handleApprove: () => Promise<void>;
}) {
  return (
    <IconButton icon={faCheck} disabled={disableButton} onClick={() => handleApprove()}>
      Approve
    </IconButton>
  );
}

function DeleteButton({ handleDelete }: { handleDelete: () => Promise<void> }) {
  return (
    <IconButton icon={faTrashCan} onClick={() => handleDelete()}>
      Delete
    </IconButton>
  );
}

export default function DraftReportPage() {
  const { reportId } = useParams<keyof ParamTypes>();
  const reportIdNumber = reportId != undefined ? parseInt(reportId) : NaN;

  const navigate = useNavigate();

  const { instance: msal } = useMsal();

  const { data: user, isLoading: userLoading } = useGetApiWhoAmIData();
  const { data, isLoading: reportLoading, error } = useGetApiReportsDraftsReportId(reportIdNumber);

  const [state, setState] = useState<State>({
    disableButton: false,
    errorMessage: undefined,
  });

  useEffect(() => {
    if (data == null) {
      return;
    }
    const createdByCurrentUser = isReportCreatedByCurrentUser(data, msal);
    if (createdByCurrentUser) {
      setState(() => ({
        disableButton: true,
        errorMessage: 'Cannot approve a report which was created by yourself',
      }));
    }
  }, [data, setState]);

  function ToErrorMessage(e: any) {
    const reason = e instanceof Error ? e.message : 'Unknown Error';

    return (
      `${reason}\n` + 'Please check report is still present and in a draft state then try again'
    );
  }

  async function handleApprove() {
    if (data == null || user == null) {
      return;
    }

    setState({ disableButton: true });

    try {
      const pdfBlob = await GeneratePdfReport(
        {
          ...data,
          reviewedBy: user,
          reviewedOn: new Date(),
        },
        false
      );

      const report = await postApiReportsDraftsReportId(
        reportIdNumber,
        {
          reportFile: new Blob([pdfBlob]),
        },
        {
          userId: user.id,
        }
      );

      navigate(GetReportRoute(report.id, false), { replace: true });
    } catch (e) {
      const errorMessage = `Failed to approve report: ${ToErrorMessage(e)}`;

      setState({ disableButton: false, errorMessage });
    }
  }

  async function generatePdf() {
    const pdfBytes = await GeneratePdfReport(data!, true);

    fileDownload(pdfBytes, getPdfReportName(data!), 'application/pdf');
  }

  async function handleDelete() {
    if (data == null) {
      return;
    }
    try {
      await deleteApiReportsDraftsReportId(reportIdNumber);
    } catch (e) {
      const errorMessage = `Failed to delete report: ${ToErrorMessage(e)}`;

      setState((current) => ({
        disableButton: current.disableButton,
        errorMessage,
      }));
      return;
    }

    navigate(`/company/${data.company.id}`, { replace: true });
  }

  const isLoading = reportLoading || userLoading;

  return (
    <>
      <ReportDisplay isLoading={isLoading} error={error} data={data} downloadPdf={generatePdf} />

      {isLoading || error ? null : (
        <div
          style={{
            marginTop: 5,
          }}
        >
          <ApproveButton disableButton={state.disableButton} handleApprove={handleApprove} />

          <DeleteButton handleDelete={handleDelete} />
        </div>
      )}

      <ErrorMessage message={state.errorMessage} />
    </>
  );
}
