﻿import {useParams} from "react-router-dom";
import {getApiReportsReviewedReportIdPdf, useGetApiReportsReviewedReportId} from "../../api/reports/reports";
import {ReportDisplay} from "../../components/report/ReportDisplay";
import fileDownload from "js-file-download";
import {getPdfReportName} from "../../export/pdf/PdfReport";

interface ParamTypes {
  reportId: string;
}

export default function ReportPage() {

  const { reportId } = useParams<keyof ParamTypes>();

  const reportIdNumber = reportId != undefined
    ? parseInt(reportId)
    : NaN;
  
  const { data, isLoading, error } = useGetApiReportsReviewedReportId(reportIdNumber)

  async function downloadPdf() {
    const reportData = await getApiReportsReviewedReportIdPdf(reportIdNumber);

    fileDownload(reportData, getPdfReportName(data!), "application/pdf");
  }

  return <ReportDisplay
    isLoading={isLoading}
    error={error}
    data={data}
    downloadPdf={downloadPdf}
  />
}
