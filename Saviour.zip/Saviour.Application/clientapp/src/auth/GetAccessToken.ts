﻿import {IPublicClientApplication, SilentRequest} from "@azure/msal-browser";
import {AzureAdConfiguration} from "../api/models";

export default async function getAccessToken(pca: IPublicClientApplication, azureAd: AzureAdConfiguration) {
  const accounts = pca.getAllAccounts();
  if (accounts.length === 0) {
    return null;
  }

  const request: SilentRequest = {
    scopes: [`api://${azureAd.clientId}/user_impersonation`],
    account: pca.getActiveAccount() ?? accounts[0]
  };

  try {
    const token = await pca.acquireTokenSilent(request);
    return token.accessToken;
  } catch {
    return null;
  }
}
