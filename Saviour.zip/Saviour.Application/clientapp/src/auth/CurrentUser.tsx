﻿import {useMsal} from "@azure/msal-react";
import React, {HTMLProps} from "react";

export function CurrentUser(props: HTMLProps<HTMLDivElement>) {

  const {instance} = useMsal();

  const currentAccount = instance.getActiveAccount();

  if (currentAccount == null) {
    return null;
  }

  return <div {...props}>
    <div>{currentAccount.name}</div>
    <div>{currentAccount.username}</div>
  </div>;
}