﻿import * as React from "react";
import {IdentityType} from "./IdentityType";
import {useIdentityContext} from "./IdentityContext";
import classes from "../App.module.css";

/**
 * Guard to only render child nodes when the user identity is of the specified type
 * @param target Target IdentityType value
 * @param children Child node
 */
export function IdentityGuard({children, target}: { children: React.ReactNode, target: IdentityType }) {
  const identity = useIdentityContext();

  return identity === target
    ? <>{ children }</>
    : <h2 className={classes.unauthenticatedContent}>
      You are not authorised to view this content
    </h2>;
}
