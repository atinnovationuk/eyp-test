﻿import React from 'react';
import { useMsal } from '@azure/msal-react';
import { Button } from '@mantine/core';

/**
 * Renders a button for logging out with a redirect
 */
export function SignOutButton() {
  const { instance } = useMsal();

  const handleLogout = async () => {
    await instance.logoutRedirect({
      postLogoutRedirectUri: '/',
    });
  };

  return <Button onClick={handleLogout}>Sign Out</Button>;
}
