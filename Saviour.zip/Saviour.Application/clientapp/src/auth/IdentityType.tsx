﻿export enum IdentityType {
  None,
  Customer,
  Analyst
}
