﻿import {createContext, useContext, useEffect, useState} from "react";
import {IdentityType} from "./IdentityType";
import {
  AccountInfo,
  AuthenticationResult,
  EventMessage,
  EventType,
  IPublicClientApplication
} from "@azure/msal-browser";
import {getApiWhoAmI} from "../api/who-am-i/who-am-i";

export const IdentityContext = createContext<IdentityType>(IdentityType.None);

export function useIdentityContext() {
  return useContext(IdentityContext);
}

/**
 * Sets up login/logout event listeners to update the IdentityType of the current user
 * @param pca msal authentication object
 */
export function useIdentity(pca: IPublicClientApplication) {
  const [ identity, setIdentity ] = useState<IdentityType>(IdentityType.None);

  useEffect(() => {
    async function setAccount(account: AccountInfo | null) {
      pca.setActiveAccount(account);

      if (account == null || account.idTokenClaims == null) {
        setIdentity(IdentityType.None);
        return;
      }
      
      const userType = await getApiWhoAmI();

      const isAnalyst = userType === "WellfishAnalyst";
      if (isAnalyst) {
        setIdentity(IdentityType.Analyst);
      } else {
        setIdentity(IdentityType.Customer);
      }
    }

    async function setFirstAccount() {
      const accounts = pca.getAllAccounts();
      await setAccount(accounts.length > 0 ? accounts[0] : null);
    }

    setFirstAccount().then();

    pca.addEventCallback(async (event: EventMessage) => {
      if (event.eventType === EventType.LOGIN_SUCCESS && event.payload) {
        const payload = event.payload as AuthenticationResult;
        const account = payload.account;
        await setAccount(account);
      }

      if (event.eventType === EventType.LOGOUT_SUCCESS) {
        await setFirstAccount();
      }
    });
  }, [pca]);

  return identity;
}
