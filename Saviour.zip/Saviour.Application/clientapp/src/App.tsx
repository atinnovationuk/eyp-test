import { Route, Routes } from 'react-router-dom';
import { MsalProvider } from '@azure/msal-react';
import { IPublicClientApplication } from '@azure/msal-browser';
import * as React from 'react';
import CustomerLanding from './pages/customer/CustomerLanding';
import SitePage from './pages/analyst/site-page/SitePage';
import { IdentityType } from './auth/IdentityType';
import { Layout } from './layout/Layout';
import { IdentityContext, useIdentity, useIdentityContext } from './auth/IdentityContext';
import { IdentityGuard } from './auth/IdentityGuard';
import CompanyPage from './pages/analyst/company-page/CompanyPage';
import AnalystLanding from './pages/analyst/AnalystLanding';
import ReportPage from './pages/reports/ReportPage';
import EmployeeManagementPage from './pages/analyst/user-management/EmployeeManagementPage';
import CompanyManagementPage from './pages/analyst/user-management/CompanyManagementPage';
import DraftReportPage from './pages/reports/DraftReportPage';
import LoadingPrompt from './components/LoadingPrompt';

export interface AppProps {
  pca: IPublicClientApplication;
}

function LandingPage() {
  const identity = useIdentityContext();

  switch (identity) {
    case IdentityType.None:
      return <LoadingPrompt />;

    case IdentityType.Customer:
      return <CustomerLanding />;

    case IdentityType.Analyst:
      return <AnalystLanding />;
  }
}

export function App({ pca }: AppProps) {
  const identity = useIdentity(pca);

  return (
    <IdentityContext.Provider value={identity}>
      <MsalProvider instance={pca}>
        <Routes>
          <Route path="/" element={<Layout />}>
            <Route index element={<LandingPage />} />
            <Route
              path="/company/:companyId"
              element={
                <IdentityGuard target={IdentityType.Analyst}>
                  <CompanyPage />
                </IdentityGuard>
              }
            />
            <Route
              path="/company/:companyId/site/:siteId"
              element={
                <IdentityGuard target={IdentityType.Analyst}>
                  <SitePage />
                </IdentityGuard>
              }
            />
            <Route path="/reports/:reportId" element={<ReportPage />} />
            <Route
              path="/reports/draft/:reportId"
              element={
                <IdentityGuard target={IdentityType.Analyst}>
                  <DraftReportPage />
                </IdentityGuard>
              }
            />
            <Route
              path="/company-management"
              element={
                <IdentityGuard target={IdentityType.Analyst}>
                  <CompanyManagementPage />
                </IdentityGuard>
              }
            />
            <Route
              path="/company-management/:companyId"
              element={
                <IdentityGuard target={IdentityType.Analyst}>
                  <EmployeeManagementPage />
                </IdentityGuard>
              }
            />
            <Route path="/system-settings" element={<div>System Settings Page</div>} />
          </Route>
        </Routes>
      </MsalProvider>
    </IdentityContext.Provider>
  );
}
