import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import { BrowserRouter } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from 'react-query';
import { App } from './App';
import { PublicClientApplication } from '@azure/msal-browser';
import getAccessToken from './auth/GetAccessToken';
import { AXIOS_INSTANCE } from '../orvalCustomAxiosInstance';
import { getApiConfiguration } from './api/configuration/configuration';
import { ModalsProvider } from '@mantine/modals';
import { MantineProvider } from '@mantine/core';
import { Configuration } from '@azure/msal-browser/dist/config/Configuration';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
    },
  },
});

const azureAdConfig = await getApiConfiguration();

/**
 * Configuration object to be passed to MSAL instance on creation.
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
 */
const msalConfig: Configuration = {
  auth: {
    clientId: azureAdConfig.clientId,
    authority: azureAdConfig.authority,
    redirectUri: azureAdConfig.redirectUri,
    postLogoutRedirectUri: azureAdConfig.redirectUri,
  },
  cache: {
    cacheLocation: 'localStorage', // Configures cache location. "sessionStorage" is more secure, but "localStorage" gives you SSO between tabs.
    storeAuthStateInCookie: false,
  },
};

const msalInstance = new PublicClientApplication(msalConfig);

// Optional - This will update account state if a user signs in from another tab or window
msalInstance.enableAccountStorageEvents();

// Apply access token to API requests
AXIOS_INSTANCE.interceptors.request.use(async function (config) {
  const accessToken = await getAccessToken(msalInstance, azureAdConfig);
  if (accessToken) {
    config.headers.setAuthorization(`Bearer ${accessToken}`);
  }

  return config;
});

ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <MantineProvider
          theme={{
            fontFamily: "'League Spartan', sans-serif",
            fontSizes: {
              xs: '0.8rem',
              sm: '1rem',
              md: '1.2rem',
              lg: '1.33rem',
              xl: '1.6rem',
            },
            colors: {
              brandBlack: [
                "#000000",
                "#000000",
                "#000000",
                "#000000",
                "#000000",
                "#000000",
                "#000000",
                "#000000",
                "#000000",
                "#000000"
              ]
            },
            primaryColor: 'brandBlack',
          }}
        >
          <ModalsProvider>
            <App pca={msalInstance} />
          </ModalsProvider>
        </MantineProvider>
      </BrowserRouter>
    </QueryClientProvider>
  </React.StrictMode>
);
