﻿import React, {ReactNode} from "react";
import {Accordion} from "@mantine/core";
import {CompanyDto, SiteDto} from "../api/models";

export interface PerSiteData<T> {
  site: SiteDto;
  data: T[];
}

export interface CompanySortedData<T> {
  company: CompanyDto;
  siteData: PerSiteData<T>[];
}

export function DisplaySortedData<T>(
  data: CompanySortedData<T>[],
  getHeader: (totalCount: number) => ReactNode,
  styleData: (data: T, company: CompanyDto, site: SiteDto) => ReactNode,
  sortData: (a: T, b: T) => number
) : ReactNode {

  const totalCount = data.map(b => b.siteData.map(s => s.data.length)
    .reduce((sum, a) => sum + a, 0)).reduce((sum, a) => sum + a, 0);

  return (
    <>
      {getHeader(totalCount)}
      <Accordion
        multiple
      >
        {
          data
            .sort((a, b) => a.company.name.localeCompare(b.company.name))
            .map((perCompanyData, companyIndex) => (
            <Accordion.Item 
              value={`company-${companyIndex}`}
              key={`company-${companyIndex}`}>
              <Accordion.Control>{perCompanyData.company.name}</Accordion.Control>
              <Accordion.Panel>
                <Accordion
                  multiple
                >
                {perCompanyData.siteData
                  .sort((a, b) => a.site.name.localeCompare(b.site.name))
                  .map((perSiteData, siteIndex) => (
                  <Accordion.Item
                    value={`site-${companyIndex}-${siteIndex}`}
                    key={`site-${companyIndex}-${siteIndex}`}
                  >
                    <Accordion.Control>{perSiteData.site.name}</Accordion.Control>
                    <Accordion.Panel>
                      {perSiteData.data
                        .sort(sortData)
                        .map(item => styleData(item, perCompanyData.company, perSiteData.site))}
                    </Accordion.Panel>
                  </Accordion.Item>
                ))}
                </Accordion>
              </Accordion.Panel>
            </Accordion.Item>
          ))
        }
      </Accordion>
    </>
  )
}
