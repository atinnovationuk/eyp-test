﻿import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useIsAuthenticated,
} from '@azure/msal-react';
import {
  AppShell,
  Burger,
  MediaQuery,
  Header,
  Navbar,
  useMantineTheme,
  getBreakpointValue,
  em,
} from '@mantine/core';
import { Outlet } from 'react-router-dom';
import { IdentityType } from '../auth/IdentityType';
import classes from './Layout.module.css';
import appClasses from '../App.module.css';
import Brand from '../components/brand/Brand';
import { useIdentityContext } from '../auth/IdentityContext';
import { SignOutButton } from '../auth/SignOutButton';
import { SignInButton } from '../auth/SignInButton';
import { AnalystNav } from './AnalystNav';
import { useState } from 'react';
import { CurrentUser } from '../auth/CurrentUser';
import { MantineTheme } from '@mantine/styles/lib/theme/types/MantineTheme';
import { useMediaQuery } from '@mantine/hooks';
import { primaryGreen } from '../components/Colours';

const smallDeviceBreakpoint = 'sm';

function IdentityNavContent() {
  const identity = useIdentityContext();

  switch (identity) {
    case IdentityType.None:
      return <></>;

    case IdentityType.Customer:
      return <></>;

    case IdentityType.Analyst:
      return <AnalystNav />;
  }
}

function NavContent() {
  return (
    <>
      <IdentityNavContent />

      <MediaQuery largerThan={smallDeviceBreakpoint} styles={{ display: 'none' }}>
        <Navbar.Section
          sx={(theme: MantineTheme) => ({
            padding: theme.spacing.xs,
            textAlign: 'center',
          })}
        >
          <CurrentUser />
          <SignInSignOut />
        </Navbar.Section>
      </MediaQuery>
    </>
  );
}

function SignInSignOut() {
  const isAuthenticated = useIsAuthenticated();

  return isAuthenticated ? <SignOutButton /> : <SignInButton />;
}

function NavBarToggle({ open, toggleOpen }: { open: boolean; toggleOpen: () => void }) {
  return (
    <Burger opened={open} onClick={() => toggleOpen()} size="sm" color={primaryGreen} mr="xl" />
  );
}

function HeaderSignInOrOutButton() {
  return (
    <div
      style={{
        flexGrow: 1,
        display: 'flex',
        flexDirection: 'row-reverse',
        margin: '0 1rem',
      }}
    >
      <MediaQuery smallerThan={smallDeviceBreakpoint} styles={{ display: 'none' }}>
        <div>
          <div
            style={{
              flexGrow: 1,
              display: 'flex',
              flexDirection: 'row-reverse',
              margin: '0 1rem',
              textAlign: 'center',
            }}
          >
            <SignInSignOut />

            <CurrentUser
              style={{
                marginRight: '1rem',
              }}
            />
          </div>
        </div>
      </MediaQuery>
    </div>
  );
}

function NavPanel() {
  const [navbarExpanded, setNavbarExpanded] = useState(false);
  const theme = useMantineTheme();
  const isLargeDevice = useMediaQuery(
    `(min-width: ${em(getBreakpointValue(theme.breakpoints.sm))})`
  );

  const collapseNavBar = !isLargeDevice && !navbarExpanded;
  const showContent = !collapseNavBar;

  function getNavBarWidth() {
    if (isLargeDevice) {
      return 250;
    }

    return navbarExpanded
      ? undefined // using undefined causes the navbar to take up the whole width
      : 30;
  }

  return (
    <Navbar p="xs" width={{ base: getNavBarWidth() }} className={classes.navbar}>
      {showContent ? <NavContent /> : null}

      {collapseNavBar ? (
        <Navbar.Section grow>
          <></>
        </Navbar.Section>
      ) : null}

      {!isLargeDevice ? (
        <Navbar.Section>
          <NavBarToggle open={navbarExpanded} toggleOpen={() => setNavbarExpanded((o) => !o)} />
        </Navbar.Section>
      ) : null}
    </Navbar>
  );
}

export function Layout() {
  return (
    <AppShell
      className={classes.app}
      header={
        <Header height={{ base: 70 }} className={classes.header}>
          <Brand />

          <HeaderSignInOrOutButton />
        </Header>
      }
      navbar={<NavPanel />}
    >
      <div className={classes.mainContent}>
        <AuthenticatedTemplate>
          <Outlet />
        </AuthenticatedTemplate>

        <UnauthenticatedTemplate>
          <h2 className={appClasses.unauthenticatedContent}>Please sign in to continue</h2>
        </UnauthenticatedTemplate>
      </div>
    </AppShell>
  );
}
