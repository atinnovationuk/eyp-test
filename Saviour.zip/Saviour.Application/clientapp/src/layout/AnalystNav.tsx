﻿import { Navbar, rem } from '@mantine/core';
import { Link } from 'react-router-dom';
import CompanyTree from '../components/company-tree/CompanyTree';
import { MantineTheme } from '@mantine/styles/lib/theme/types/MantineTheme';
import userGuide from '../user-guides/UserGuide.pdf';

export function AnalystNav() {
  return (
    <>
      <Navbar.Section
        sx={(theme: MantineTheme) => ({
          padding: theme.spacing.xs,
          borderBottom: `${rem(1)} solid`,
        })}
      >
        <Link to="/company-management">Company Management</Link>
      </Navbar.Section>
      <Navbar.Section
        grow
        sx={() => ({
          borderBottom: `${rem(1)} solid`,
        })}
      >
        <CompanyTree />
      </Navbar.Section>
      <Navbar.Section
        sx={(theme: MantineTheme) => ({
          padding: theme.spacing.xs,
          borderBottom: `${rem(1)} solid`,
        })}
      >
        <a href={userGuide} target="_blank">
          User Guide
        </a>
      </Navbar.Section>
    </>
  );
}
