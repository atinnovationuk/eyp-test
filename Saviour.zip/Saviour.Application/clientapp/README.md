﻿
# Client App

## Authentication

App authentication is performed via Azure Active Directory (AD), and is controlled via an App Registration defined in Azure.

The packages `azure/msal-react` and `azure/msal-browser` provide the functionality to access and control authentication tokens.

Configuration settings are defined as environment variables and applied in [authConfig.ts](src/authConfig.ts).
For more information on these variables [see here](https://learn.microsoft.com/en-us/azure/active-directory/develop/msal-js-initializing-client-applications) 

- These are defined in [.env](.env) for local development. This file is not deployed.
- These must be defined in the App Service 

Currently there are 2 App Roles defined in the App Registration:

- Analysts: Can view all customer data and generate or review reports.
- Customer: Can data and reports for their own sites.
    - TODO: Mapping of specific customers to their own data has not been configured

A user must be assigned to one of these roles via Azure 'Enterprise Applications' section, else they cannot do anything.
Note that an AD User Group can be assigned to an App Role to simplify this process, but only for upgraded Active Directory plans.
