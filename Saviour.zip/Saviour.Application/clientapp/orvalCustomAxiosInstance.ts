﻿import Axios, { AxiosError, AxiosRequestConfig } from 'axios';

export const AXIOS_INSTANCE = Axios.create({ baseURL: '' });

// Date-time parsing
AXIOS_INSTANCE.interceptors.response.use((originalResponse) => {
  handleDates(originalResponse.data);

  return originalResponse;
});

enum DateType {
  None,
  DateOnly,
  DateTime
}

const isoDateFormat =  /^\d{4}-\d{2}-\d{2}$/;
const isoDateTimeFormat =  /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d*)?(?:[-+]\d{2}:?\d{2}|Z)?$/;

function getDateType(value: any): DateType {
  if (value == null || typeof value !== 'string') {
    return DateType.None;
  }
  if (isoDateFormat.test(value)) {
    return DateType.DateOnly;
  }
  if (isoDateTimeFormat.test(value)) {
    return DateType.DateTime;
  }
  return DateType.None;
}

export function handleDates(body: any) {

  if (body === null || body === undefined || typeof body !== 'object') {
    return body;
  }

  for (const key of Object.keys(body)) {
    const value = body[key];

    switch (getDateType(value)) {
      case DateType.None:
        if (typeof value === 'object') {
          handleDates(value);
        }
        break;

      case DateType.DateOnly:
        body[key] = new Date(`${value}T00:00:00`); // strip all time from date-only strings
        break;

      case DateType.DateTime:
        body[key] = new Date(value);
        break;
    }
  }
}

export const customInstance = <T>(config: AxiosRequestConfig): Promise<T> => {
  const source = Axios.CancelToken.source();
  const promise = AXIOS_INSTANCE({ ...config, cancelToken: source.token }).then(
    ({ data }) => data,
  );

  // eslint-disable-next-line @typescript-eslint/ban-ts-comment
  // @ts-ignore
  promise.cancel = () => {
    source.cancel('Query was cancelled');
  };

  return promise;
};

export default customInstance;

export type ErrorType<Error> = AxiosError<Error>;
