import { defineConfig } from 'vitest/config'

export default defineConfig({
    test: {
        include: ['./src/**.spec.{ts,tsx}'],
        coverage: {
            provider: 'c8',
            reporter: ['cobertura', 'text'],
        },
        reporters: "junit",
        outputFile: "test-results/frontend-test-results.xml"
    },
})