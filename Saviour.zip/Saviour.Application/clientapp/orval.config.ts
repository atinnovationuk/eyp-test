import { defineConfig } from 'orval';

export default defineConfig({
  api: {
    output: {
      clean: true,
      mode: 'tags-split',
      target: 'src/api/',
      schemas: 'src/api/models',
      client: 'react-query',
      override: {
        useDates: true,
        mutator: {
          path: './orvalCustomAxiosInstance.ts',
          name: 'customInstance',
        },
      }
    },
    input: {
      target: '../api.json',
    }
  },
});