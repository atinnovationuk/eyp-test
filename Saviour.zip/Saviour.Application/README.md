# Saviour.Application


## SQL Server Setup

For local development, an MS SQL Server database must be set up, either via installation of SQL Server Management Studio or a Docker image. An example command to create a Docker image is shown:

```shell
docker run -it -e "ACCEPT_EULA=Y" -e "SA_PASSWORD=A&VeryComplex123Password" -p 1433:1433 --name sql-server-2022 mcr.microsoft.com/mssql/server:2022-latest
```

The application connects via a connection string, for which a default is defined in [appsettings.json](./appsettings.json). If desired, an alternative can be defined via a user secret [(see also)](https://learn.microsoft.com/en-us/aspnet/core/security/app-secrets).

For example, for the above Docker image this would created via the command below **from the project root**:

```shell
dotnet user-secrets set "ConnectionStrings:SaviourContext" "Data Source=localhost; Database=Saviour; User Id=SA; Password=A&VeryComplex123Password; MultipleActiveResultSets=True; Encrypt=False;"
```

Once a database environment is ready with a proper connection string, initialise it via the command:

```shell
dotnet-ef database update
```

This will create the database if it does not exist, and apply all migrations.

## ML Model testing

To test the integration with ML models locally, several configurations need to be applied, and a means of authenticating an Azure AD account set up

### Configuration

Obtain the following information:

- The endpoints of all ML models
- The API keys for realtime ML endpoints

Then set them as user secrets:

```shell
dotnet user-secrets set "MLRealtimeConfig:Model0EndPoint" "<value>"
dotnet user-secrets set "MLRealtimeConfig:Model0Key" "<value>"
```

### Azure authentication

There are multiple mechanisms for authenticating with Azure described in Microsoft documentation:

https://learn.microsoft.com/en-us/dotnet/azure/sdk/authentication-local-development-dev-accounts?tabs=azure-portal%2Csign-in-visual-studio%2Ccommand-line#3---sign-in-to-azure-using-net-tooling

One of these must be used in order for the app to be able to request identity tokens via `DefaultAzureCredential` 
