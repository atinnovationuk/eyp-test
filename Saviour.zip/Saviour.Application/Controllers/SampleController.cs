﻿using Microsoft.AspNetCore.Mvc;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SampleController: ControllerBase
{
    private readonly ISampleService _sampleService;
    
    public SampleController(ISampleService sampleService)
    {
        _sampleService = sampleService;
    }
    
    /// <summary>
    /// Upload a Sample
    /// </summary>
    [HttpPost]
    [ProducesResponseType(typeof(UploadSampleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async ValueTask<ActionResult<UploadSampleDto>>Post(UploadSampleDto sample)
    {
        await _sampleService.AddSampleAsync(sample);
        return Ok(sample);
    }
}