﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Saviour.Application.Security;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = PolicyNames.RequireAnalyst)]
public class CompanyController : ControllerBase
{
    private readonly ICompanyService _companyService;
    public CompanyController(ICompanyService companyService)
    {
        _companyService = companyService;
    }

    /// <summary>
    /// Retrieves all Companies
    /// </summary>
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<CompanyDto>), StatusCodes.Status200OK)]
    public IAsyncEnumerable<CompanyDto> Get() => _companyService.GetCompaniesAsync();

    [HttpGet]
    [Route("company/{companyId}")]
    [ProducesResponseType(typeof(CompanyDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async ValueTask<ActionResult<CompanyDto>> Get(string companyId)
    {
        var company = await _companyService.GetCompanyAsync(companyId);

        return company is null
            ? NotFound()
            : Ok(company);
    }

    [HttpGet]
    [Route("{companyId}")]
    [ProducesResponseType(typeof(IEnumerable<SiteDto>), StatusCodes.Status200OK)]
    public IAsyncEnumerable<SiteDto> GetSites(string companyId) => _companyService.GetSitesForCompanyAsync(companyId);

    [HttpGet]
    [Route("site/{siteId}")]
    [ProducesResponseType(typeof(SiteDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async ValueTask<ActionResult<SiteDto>> GetSite(string siteId)
    {
        var site = await _companyService.GetSiteAsync(siteId);

        return site is null
            ? NotFound()
            : Ok(site);
    }

    [HttpDelete]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async ValueTask<IActionResult> DeleteCompany(string companyId) =>
        await _companyService.DeleteCompany(companyId)
            ? NoContent()
            : Conflict();

    [HttpPost]
    [ProducesResponseType(typeof(CompanyDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public ValueTask<CompanyDto> Create(EditCompanyDto companyData)
        => _companyService.Create(companyData);
    
    [HttpPut]
    [ProducesResponseType(typeof(CompanyDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public ValueTask<CompanyDto> Update(EditCompanyDto companyData)
        => _companyService.Update(companyData);
}