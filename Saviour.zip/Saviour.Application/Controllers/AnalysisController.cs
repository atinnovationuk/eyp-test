﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Saviour.Application.Security;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = PolicyNames.RequireAnalyst)]
public class AnalysisController
{
    private readonly IAnalysisService _analysisService;

    public AnalysisController(IAnalysisService analysisService)
    {
        _analysisService = analysisService;
    }

    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<AnalysisDto>), StatusCodes.Status200OK)]
    public IAsyncEnumerable<AnalysisDto> GetAll(string countryCode) => _analysisService.GetAll(countryCode);
}
