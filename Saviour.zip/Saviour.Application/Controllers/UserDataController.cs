﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Saviour.Application.Security;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Controllers;

[ApiController]
[Authorize]
[Route("api/[controller]")]
public class UserDataController : ControllerBase
{
    private readonly IUserDataService _userDataService;

    public UserDataController(IUserDataService userDataService)
    {
        _userDataService = userDataService;
    }

    [HttpGet]
    [ProducesResponseType(typeof(ReportDataDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async ValueTask<ActionResult<ReportDataDto>> GetReports()
    {
        var company = await _userDataService.TryGetCompany(HttpContext.User).ConfigureAwait(false);
        if (company is null)
        {
            return Forbid();
        }

        return Ok(new ReportDataDto(company,
            await _userDataService.GetReports(company.Id).ToListAsync())
        );
    }

    [HttpGet]
    [Route("company/{companyId}")]
    [ProducesResponseType(typeof(IEnumerable<PerSiteData<ReportSummary>>), StatusCodes.Status200OK)]
    [Authorize(Policy = PolicyNames.RequireAnalyst)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public IAsyncEnumerable<PerSiteData<ReportSummary>> GetReports(string companyId)
    {
        return _userDataService.GetReports(companyId);
    }
}
