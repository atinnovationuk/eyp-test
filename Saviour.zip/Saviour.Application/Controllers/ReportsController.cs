﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Saviour.Application.Security;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Controllers;

[ApiController]
[Authorize]
[Route("api/[controller]")]
public class ReportsController : ControllerBase
{
    private readonly IReportService _reports;
    private readonly IAccessService _access;
    private readonly IAnalysisService _analysis;
    private readonly IReportStorage _reportStorage;
    private readonly IUserService _userService;
    private readonly IUnitOfWork _unitOfWork;

    public ReportsController(IReportService reportService, IAccessService access, IAnalysisService analysis,
        IReportStorage reportStorage, IUserService userService, IUnitOfWork unitOfWork)
    {
        _reports = reportService;
        _access = access;
        _analysis = analysis;
        _reportStorage = reportStorage;
        _userService = userService;
        _unitOfWork = unitOfWork;
    }

    [HttpGet]
    [Route("reviewed/{reportId:int}")]
    [ProducesResponseType(typeof(ReviewedReport), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public ValueTask<ActionResult> GetReviewed(int reportId)
    {
        return AccessReport(reportId, async report
            => Ok(ReviewedReport.FromReport(report, await GetAnalyses(report.Batches, report.Analyses)))
        );
    }

    [HttpGet]
    [Route("reviewed/{reportId:int}/pdf")]
    [ProducesResponseType(typeof(FileResult), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public ValueTask<ActionResult> GetContent(int reportId)
    {
        return AccessReport(reportId, async report => File(await _reportStorage.Get(report), "application/pdf"));
    }

    private async ValueTask<ActionResult> AccessReport(int reportId, Func<Report, ValueTask<ActionResult>> withReport)
    {
        var report = await _reports.Get(reportId)
            .ConfigureAwait(false);

        if (report is null)
        {
            return NotFound();
        }

        if (!await _access.CanAccessCompanyData(User, report.Site.CompanyId)
                .ConfigureAwait(false))
        {
            return Forbid();
        }

        return await withReport(report);
    }

    [HttpGet]
    [Authorize(Policy = PolicyNames.RequireAnalyst)]
    [Route("drafts/{reportId:int}")]
    [ProducesResponseType(typeof(DraftReportDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public async ValueTask<ActionResult<DraftReportDto>> Get(int reportId)
    {
        var draft = await _reports.GetDraft(reportId)
            .ConfigureAwait(false);
        if (draft is null)
        {
            return NotFound();
        }

        return Ok(DraftReportDto.FromReport(draft, await GetAnalyses(draft.Batches, draft.Analyses)));
    }

    [HttpDelete]
    [Authorize(Policy = PolicyNames.RequireAnalyst)]
    [Route("drafts/{reportId:int}")]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async ValueTask<IActionResult> Delete(int reportId)
    {
        await _reports.Delete(reportId);
        await _unitOfWork.SaveChangesAsync();

        return Ok();
    }

    private ValueTask<List<AnalysisDto>> GetAnalyses(IEnumerable<Batch> batches, IEnumerable<Analysis> analyses)
    {
        var countryCode = batches
            .First()
            .Site
            .CountryCode;
        
        return _analysis.Get(
            countryCode,
            analyses.Select(a => a.Id).ToList()
        ).ToListAsync();
    }

    [HttpPost]
    [Route("drafts/{reportId:int}")]
    [Authorize(Policy = PolicyNames.RequireAnalyst)]
    [ProducesResponseType(typeof(CreatedReportDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status409Conflict)]
    public async ValueTask<ActionResult<ReviewedReport>> Approve(long reportId, int userId, IFormFile reportFile)
    {
        var userEntity = await _userService.Find(userId);

        var report = await _reports.Approve(reportId, userEntity, reportFile.OpenReadStream())
            .ConfigureAwait(false);
        await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

        return report is not null
            ? Ok(new CreatedReportDto(report.Id))
            : Conflict();
    }

    [HttpPost]
    [Authorize(Policy = PolicyNames.RequireAnalyst)]
    [ProducesResponseType(typeof(CreatedReportDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async ValueTask<IActionResult> PostNew(NewReport data)
    {
        var user = await _userService.FindOrCreate(User);
        
        var created = await _reports.Create(data, user)
            .ConfigureAwait(false);

        await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

        return CreatedAtAction(nameof(Get), new { reportId = created.Id }, new CreatedReportDto(created.Id));
    }
}
