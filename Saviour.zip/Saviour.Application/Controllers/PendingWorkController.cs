﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Saviour.Application.Security;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = PolicyNames.RequireAnalyst)]
public class PendingWorkController
{
    private readonly IPendingWorkService _pendingWork;

    public PendingWorkController(IPendingWorkService pendingWork)
    {
        _pendingWork = pendingWork;
    }

    [HttpGet]
    [ProducesResponseType(typeof(PendingWork), StatusCodes.Status200OK)]
    public ValueTask<PendingWork> Get() => _pendingWork.Get();

    [HttpGet]
    [Route("reports/{companyId}")]
    [ProducesResponseType(typeof(IEnumerable<PerSiteData<ReportSummary>>), StatusCodes.Status200OK)]
    public IAsyncEnumerable<PerSiteData<ReportSummary>> GetReports(string companyId) => _pendingWork.GetReports(companyId);
}
