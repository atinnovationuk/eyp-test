﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Utility;

namespace Saviour.Application.Controllers;

[ApiController]
[Authorize]
[Route("api/[controller]")]
public class WhoAmIController : ControllerBase
{
    private readonly IUserTypeService _userTypeService;
    private readonly IUserService _userService;
    private readonly IUnitOfWork _unitOfWork;

    public WhoAmIController(IUserTypeService userTypeService, IUserService userService, IUnitOfWork unitOfWork)
    {
        _userTypeService = userTypeService;
        _userService = userService;
        _unitOfWork = unitOfWork;
    }

    [HttpGet]
    [ProducesResponseType(typeof(UserType), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public UserType Get()
    {
        return _userTypeService.Get(User);
    }
    
    [HttpGet]
    [Route("data")]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async ValueTask<UserDto> GetData()
    {
        var user = await _userService.FindOrCreate(User)
            .Map(UserDto.FromUser);

        await _unitOfWork.SaveChangesAsync().ConfigureAwait(false);

        return user;
    }
}
