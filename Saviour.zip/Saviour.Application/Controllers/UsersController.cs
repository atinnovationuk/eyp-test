﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Saviour.Application.Security;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = PolicyNames.RequireAnalyst)]
public class UsersController
{
    private readonly IEmployeeService _employeeService;

    public UsersController(IEmployeeService employeeService)
    {
        _employeeService = employeeService;
    }

    [HttpGet]
    [Route("{companyId}")]
    [ProducesResponseType(typeof(IEnumerable<EmployeeDto>), StatusCodes.Status200OK)]
    public IAsyncEnumerable<EmployeeDto> GetEmployees(string companyId)
        => _employeeService.Get(companyId);

    [HttpPost]
    [Route("{companyId}")]
    [ProducesResponseType(typeof(EmployeeDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public ValueTask<EmployeeDto> Create(string companyId, EmployeeDto employeeData)
        => _employeeService.Create(companyId, employeeData);

    [HttpPut]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    public ValueTask UpdateEmployee(EmployeeDto employeeData) 
        => _employeeService.Update(employeeData);

    [HttpDelete]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public ValueTask Delete(int employeeId)
        => _employeeService.Delete(employeeId);
}
