﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Saviour.Application.Security;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;

namespace Saviour.Application.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Policy = PolicyNames.RequireAnalyst)]
public class FishHealthResultController
{
    private readonly IFishHealthResultsService _fishHealthResultsService;
    
    public FishHealthResultController(IFishHealthResultsService fishHealthResultsService)
    {
        _fishHealthResultsService = fishHealthResultsService;
    }
    
    [HttpGet]
    [ProducesResponseType(typeof(IEnumerable<BatchFishHealthResultDto>), StatusCodes.Status200OK)]
    public async Task<IEnumerable<BatchFishHealthResultDto>> GetFishHealthResults(string siteId)
    {
        return await _fishHealthResultsService.GetPenFishHealthResults(siteId);
    }
}