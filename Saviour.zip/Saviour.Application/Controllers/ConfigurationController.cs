﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Saviour.Domain.Configuration;

namespace Saviour.Application.Controllers;

[ApiController]
[AllowAnonymous]
[Route("api/[controller]")]
public class ConfigurationController
{
    private readonly IOptionsSnapshot<AzureAdConfiguration> _configuration;

    public ConfigurationController(IOptionsSnapshot<AzureAdConfiguration> configuration)
    {
        _configuration = configuration;
    }

    /// <summary>
    /// Retrieves current Azure AD configuration
    /// </summary>
    [HttpGet]
    public AzureAdConfiguration Get()
    {
        return _configuration.Value;
    }
}
