﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Data.SqlClient;
using Saviour.Domain.Exceptions;

namespace Saviour.Application.ExceptionHandling;

// ReSharper disable once ClassNeverInstantiated.Global
public class HttpExceptionFilter : IActionFilter
{
    public void OnActionExecuting(ActionExecutingContext context)
    {
        
    }

    public void OnActionExecuted(ActionExecutedContext context)
    {
        TryHandleException(context, context.Exception);
        TryHandleException(context, context.Exception?.InnerException);
    }

    private static void TryHandleException(ActionExecutedContext context, Exception? exception)
    {
        if (context.ExceptionHandled)
        {
            return;
        }
        
        switch (exception)
        {
            case EntityNotFoundException _:
            case EntitiesNotFoundException _:
                context.Result = new NotFoundResult();
                context.ExceptionHandled = true;
                break;

            case InvalidUserException _:
                context.Result = new BadRequestResult();
                context.ExceptionHandled = true;
                break;

            case SqlException sql when IsDbSetupError(sql):
                context.Result = new ContentResult
                {
                    StatusCode = StatusCodes.Status500InternalServerError,
                    ContentType = "text/plain",
                    Content = "Invalid database configuration - please contact system administrator"
                };
                context.ExceptionHandled = true;
                break;
        }
    }

    private static bool IsDbSetupError(SqlException sql)
        => sql.Number
            is 207 // invalid column name (usually happens if database has not been updated)
            or 208 // invalid object name (usually happens if database has not been updated)
            or 233 // A connection was successfully established with the server, but then an error occurred during the login process. (usually means that the database doesn't exist or connection string credentials are wrong)
            or 4060; // cannot open database (usually happens when db connection string points to wrong database, or has the wrong credentials)
}