﻿using System.Threading.Channels;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Identity.Web;
using Microsoft.Net.Http.Headers;
using Newtonsoft.Json.Converters;
using Saviour.Application.ExceptionHandling;
using Saviour.Application.Security;
using Saviour.Application.Utils;
using Saviour.Domain.Configuration;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;
using Saviour.Infrastructure;

namespace Saviour.Application;

// Note: We are using this mechanism as Swashbuckle is currently not compatible with the Minimal Hosting Model:
// https://github.com/domaindrivendev/Swashbuckle.AspNetCore/issues/2290

public class Startup
{
    private IConfiguration Configuration { get; }
    private bool IsDevelopment { get; }

    public Startup(IConfiguration configuration, IWebHostEnvironment webHostEnvironment)
    {
        Configuration = configuration;
        IsDevelopment = webHostEnvironment.IsDevelopment();
    }

    public void ConfigureServices(IServiceCollection services)
    {
        services.AddControllers(mvcOptions => mvcOptions.Filters.Add<HttpExceptionFilter>())
            .AddNewtonsoftJson(options =>
                options.SerializerSettings.Converters.Add(new StringEnumConverter()));

        services.AddHttpClient();

        services.Configure<FileStorageConfig>(Configuration.GetSection("FileStorage"));
        services.Configure<AzureAdConfiguration>(Configuration.GetSection(AzureAdConfiguration.SectionName));
        services.Configure<MLRealtimeConfiguration>(Configuration.GetSection("MLRealtimeConfig"));

        const string authenticationScheme = JwtBearerDefaults.AuthenticationScheme;
        services.AddAuthorization(options =>
        {
            options.AddPolicy(PolicyNames.RequireAnalyst, policy =>
            {
                policy.AddRequirements(new AnalystRequirement());
                policy.RequireAuthenticatedUser();
                policy.AddAuthenticationSchemes(authenticationScheme);
            });
        });

        services.AddHttpContextAccessor();

        services.AddScoped<IAuthorizationHandler, AnalystRequirementHandler>();

        services.AddAuthentication(authenticationScheme)
            .AddMicrosoftIdentityWebApi(Configuration, configSectionName: AzureAdConfiguration.SectionName);

        services.AddSpaStaticFiles(configuration => { configuration.RootPath = "wwwroot/dist"; });

        services.AddSwaggerGen(options =>
        {
            options.SupportNonNullableReferenceTypes();
            options.SchemaFilter<RequiredNotNullableSchemaFilter>();
        });
        services.AddSwaggerGenNewtonsoftSupport();

        services.TryAddScoped<IUnitOfWork, EntityFrameworkUnitOfWork>();
        services.TryAddScoped(typeof(IRepository<>), typeof(EntityFrameworkRepository<>));

        services.TryAddTransient<ISampleService, SampleService>();
        services.TryAddTransient<ICompanyService, CompanyService>();
        services.TryAddTransient<IBatchService, BatchService>();
        services.TryAddTransient<IBatchListener, BatchListener>();
        services.TryAddTransient<IAnalysisService, AnalysisService>();
        services.TryAddTransient<IPendingWorkService, PendingWorkService>();
        services.TryAddTransient<IEmployeeService, EmployeeService>();
        services.TryAddTransient<IUserDataService, UserDataService>();
        services.TryAddTransient<IReportService, ReportService>();
        services.TryAddTransient<IMLReportingService, MLReportingService>();
        services.TryAddTransient<IFishHealthResultsService, FishHealthResultsService>();
        services.TryAddTransient<IAccessService, AccessService>();
        services.TryAddTransient<IUserService, UserService>();
        services.TryAddTransient<IPrepareMLInputs, PrepareMLInputs>();
        services.TryAddTransient<IMLRealtimeRequest, MLRealtimeRequest>();
        services.TryAddTransient<IMLResultsHandler, MLResultsHandler>();
        services.TryAddTransient<IMLResultsReader, MLResultsReader>();
        services.TryAddTransient<IGetMLInputs, GetMLInputs>();
        services.TryAddTransient<IUserTypeService, UserTypeService>();
        services.TryAddTransient<IMLModelService, MLModelService>();
        services.TryAddTransient<IGetMLModel, GetMLModel>();
        services.TryAddTransient<IGetBatchesNeedingML, GetBatchesNeedingML>();
        services.TryAddTransient<IRunMLModels, RunMLModels>();

        services.TryAddSingleton(_ => Channel.CreateUnbounded<Batch>());

        services.AddHostedService<UpdateMLModelsBackgroundService>();

        if (IsDevelopment)
        {
            // Store local files in dev environments
            services.TryAddTransient<IReportStorage, DevReportStorage>();
        }
        else
        {
            services.TryAddTransient<IReportStorage, ReportStorageService>();
        }

        services.AddDbContext<DbContext, SaviourContext>(options =>
        {
            options
                .UseSqlServer(Configuration.GetConnectionString("SaviourContext"));
        });
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment environment)
    {
        // Configure the HTTP request pipeline.
        if (!IsDevelopment)
        {
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseStaticFiles();

        app.UseRouting();

        app.UseAuthentication();
        app.UseAuthorization();

        app.MapWhen(ctx => ctx.Request.Path.StartsWithSegments("/api"),
            api => { api.UseEndpoints(endpoints => { endpoints.MapControllers(); }); });

        app.UseSwagger();

        if (IsDevelopment)
        {
            app.UseSwaggerUI();

            app.Map(new PathString(),
                client => { client.UseSpa(spa => { spa.UseProxyToSpaDevelopmentServer("https://localhost:6363"); }); });
        }
        else
        {
            app.Map(new PathString(), client =>
            {
                client.UseSpaStaticFiles();
                client.UseSpa(spa =>
                {
                    spa.Options.SourcePath = "clientapp";

                    // adds no-store header to index page to prevent deployment issues (prevent linking to old .js files)
                    // .js and other static resources are still cached by the browser
                    spa.Options.DefaultPageStaticFileOptions = new StaticFileOptions
                    {
                        OnPrepareResponse = ctx =>
                        {
                            var headers = ctx.Context.Response.GetTypedHeaders();
                            headers.CacheControl = new CacheControlHeaderValue
                            {
                                NoCache = true,
                                NoStore = true,
                                MustRevalidate = true
                            };
                        }
                    };
                });
            });
        }
    }
}