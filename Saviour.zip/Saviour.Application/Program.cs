using Saviour.Application;

var builder = WebApplication.CreateBuilder(args);

builder.Logging.AddConsole();
var environment = builder.Environment;

if (environment.IsDevelopment())
{
    builder.Logging.AddDebug();
}

var startup = new Startup(builder.Configuration, environment);

startup.ConfigureServices(builder.Services);

var app = builder.Build();

startup.Configure(app, environment);

app.Run();

// Make the implicit Program class public so test projects can access it
namespace Saviour.Application
{
    public class Program { }
}
