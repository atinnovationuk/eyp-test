﻿using System.Diagnostics.CodeAnalysis;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using Saviour.Domain.Interfaces;

namespace Utility.CsvUploader.CsvTypes;

[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
public class WaterTypeConverter : DefaultTypeConverter
{
    public override object ConvertFromString(string? text, IReaderRow row, MemberMapData memberMapData)
    {
        return text?.Trim() switch
        {
            "1" => WaterType.FreshWater,
            "2" => WaterType.SeaWater,
            _ => throw new TypeConverterException(this, memberMapData, text, row.Context)
        };
    }
}