﻿using System.Diagnostics.CodeAnalysis;
using CsvHelper;
using CsvHelper.Configuration;
using Saviour.Domain.Dto;

namespace Utility.CsvUploader.CsvTypes;

[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
public class UploadSampleMap : ClassMap<UploadSampleDto>
{
    public UploadSampleMap()
    {
        var dateFormats = new[]
        {
            "dd/MM/yyyy",
            "d/MM/yyyy",
            "dd/M/yyyy",
            "d/M/yyyy"
        };
        
        base.Map(s => s.DateCollected).Name("Date Collected").TypeConverterOption.Format(dateFormats);
        base.Map(s => s.DateAnalysed).Name("Date Analysed").TypeConverterOption.Format(dateFormats);
        base.Map(s => s.Instrument).Name("CC Instrument");
        base.Map(s => s.Species);
        base.Map(s => s.WaterType).Name("SW FW").TypeConverter<WaterTypeConverter>();
        base.Map(s => s.BatchNumber).Name("Batch No.");
        base.Map(s => s.CompanyCode).Name("Company");
        base.Map(s => s.CompanyName).Name("Company");
        base.Map(s => s.SiteCode).Name("Site");
        base.Map(s => s.SiteName).Name("Site");
        base.Map(s => s.Pen);
        base.Map(s => s.FishNumber).Name("Fish No.");
        base.Map(s => s.AverageWeightInGrams).Name("Weight");
        base.Map(s => s.TemperatureInCelsius).Name("Temperature");
        base.Map(s => s.OxygenLevelInMg).Name("O2").TypeConverter<NullableDecimalConverter>();
        base.Map(s => s.MortalityRatePercentage).Name("Mortality Rate");
        base.Map(s => s.Strain);
        base.Map(s => s.Hatcheries).Name("Hatchery").TypeConverter<HatcheryConverter>();
        base.Map(s => s.CountryCode).Constant("GB");
        base.Map(s => s.BiomarkerResults).Convert(ReadBiomarkerResults);
        base.Map(s => s.FishHealthHistory).Constant("Test Fish Health History");
        base.Map(s => s.ConfirmedCondition).Constant("Test Confirmed Condition");
        base.Map(s => s.DateReceived).Constant(DateTime.UtcNow);
    }

    private static ICollection<BiomarkerResultDto> ReadBiomarkerResults(ConvertFromStringArgs args)
    {
        var row = args.Row;

        var biomarkerResults = new List<BiomarkerResultDto>();

        TryAddColumn("ALBUMIN", "ALBUMIN");
        TryAddColumn("ALP", "ALP");
        TryAddColumn("ALT", "ALT");
        TryAddColumn("AMY", "AMY");
        TryAddColumn("AST", "AST");
        TryAddColumn("TBIL", "TBIL");
        TryAddColumn("CALCIUM (Ca)", "CALCIUM");
        TryAddColumn("CHOLESTEROL", "CHOLESTEROL");
        TryAddColumn("CK", "CK");
        TryAddColumn("CK MB", "CK MB");
        TryAddColumn("CO2", "CO2");
        TryAddColumn("CREA E", "CREA E");
        TryAddColumn("CREA", "CREA");
        TryAddColumn("GLUCOSE", "GLUCOSE");
        TryAddColumn("HDL", "HDL");
        TryAddColumn("IRON (Fe)", "IRON");
        TryAddColumn("LACTATE", "LACTATE");
        TryAddColumn("LDH", "LDH");
        TryAddColumn("LDL", "LDL");
        TryAddColumn("LIPASE", "LIPASE");
        TryAddColumn("MAGNESIUM (Mg)", "MAGNESIUM");
        TryAddColumn("AMM", "AMM");
        TryAddColumn("PHOSPHATE (P)", "PHOSPHATE");
        TryAddColumn("TP", "TP");
        TryAddColumn("TG", "TG");
        TryAddColumn("UA", "UA");
        TryAddColumn("UIBC", "UIBC");
        TryAddColumn("UREA", "UREA");
        TryAddColumn("ZINC (Zn)", "ZINC");
        TryAddColumn("SODIUM (Na)", "SODIUM");
        TryAddColumn("POTASSIUM (K)", "POTASSIUM");
        TryAddColumn("CHLORIDE (Cl)", "CHLORIDE");
        TryAddColumn("SI2", "SI2");
        TryAddColumn("SI2-L", "SI2-L");
        TryAddColumn("SI2-H", "SI2-H");
        TryAddColumn("SI2-I", "SI2-I");

        return biomarkerResults;

        void TryAddColumn(string columnName, string biomarkerName)
        {
            if (row.TryGetField<decimal>(columnName, out var biomarkerResult))
            {
                biomarkerResults.Add(new BiomarkerResultDto(biomarkerName, biomarkerResult));
            }
        }
    }
}