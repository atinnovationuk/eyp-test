﻿using System.Diagnostics.CodeAnalysis;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;

namespace Utility.CsvUploader.CsvTypes;

[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
public class NullableDecimalConverter : DefaultTypeConverter
{
    public override object? ConvertFromString(string? text, IReaderRow row, MemberMapData memberMapData)
    {
        return decimal.TryParse(text, out var value)
            ? value
            : null;
    }
}
