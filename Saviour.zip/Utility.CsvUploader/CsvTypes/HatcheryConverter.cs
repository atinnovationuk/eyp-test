﻿using System.Diagnostics.CodeAnalysis;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;

namespace Utility.CsvUploader.CsvTypes;

[SuppressMessage("ReSharper", "ClassNeverInstantiated.Global")]
public class HatcheryConverter : DefaultTypeConverter
{
    public override object ConvertFromString(string? text, IReaderRow row, MemberMapData memberMapData)
    {
        return string.IsNullOrWhiteSpace(text)
            ? Array.Empty<string>()
            : new[] { text };
    }
}