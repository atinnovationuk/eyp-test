﻿# Csv Uploader utility

A utility program to upload samples to the Saviour API from CSV files, for the purposes of seeding dev databases

## Running

Before running, the `Saviour.Application` API project needs to have been started.

Then, this tool can be run via the command below:

```shell
dotnet run -- -u "https://localhost:7290/api/Sample" -d ".\AnonymisedCsvs"
```

CLI arguments are described in [Arguments.cs](.\Arguments.cs)
