﻿namespace Utility.CsvUploader.Logging;

internal class FileLog : ILog
{
    private readonly StreamWriter file;

    public FileLog(StreamWriter file)
    {
        this.file = file;
    }

    public void Dispose()
    {
        file.Dispose();
    }

    public void WriteLine(string message)
    {
        file.WriteLine(message);
    }
}