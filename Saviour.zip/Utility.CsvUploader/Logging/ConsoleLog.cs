﻿namespace Utility.CsvUploader.Logging;

internal class ConsoleLog : ILog
{
    public void Dispose()
    {
        
    }

    public void WriteLine(string message)
        => Console.WriteLine(message);
}