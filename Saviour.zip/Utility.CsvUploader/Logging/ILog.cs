﻿namespace Utility.CsvUploader.Logging;

internal interface ILog : IDisposable
{
    void WriteLine(string message);
}