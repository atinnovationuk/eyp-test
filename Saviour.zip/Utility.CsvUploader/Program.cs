﻿using System.Diagnostics;
using System.Globalization;
using System.Text;
using System.Threading.Tasks.Dataflow;
using CommandLine;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using Newtonsoft.Json;
using Saviour.Domain.Dto;
using Utility.CsvUploader;
using Utility.CsvUploader.CsvTypes;
using Utility.CsvUploader.Logging;

await Parser.Default.ParseArguments<Arguments>(args)
    .MapResult(Run, LogErrors);

static async ValueTask Run(Arguments arguments)
{
    var timer = Stopwatch.StartNew();
    
    using var httpClient = new HttpClient();

    var files = GetFiles(arguments);

    using ILog log = string.IsNullOrWhiteSpace(arguments.OutputFile)
        ? new ConsoleLog()
        : new FileLog(File.CreateText(arguments.OutputFile));

    var postInParallel = new ActionBlock<SampleAndNumber>(ProcessSample,
        new ExecutionDataflowBlockOptions
        {
            MaxDegreeOfParallelism = arguments.ParallelThreads,
            BoundedCapacity = 5000
        });

    foreach (var filePath in files)
    {
        await foreach (var sample in ReadFile(filePath, log))
        {
            await postInParallel.SendAsync(sample);
        }
    }

    postInParallel.Complete();
    await postInParallel.Completion;

    log.WriteLine($"Completed. Elapsed: {timer.Elapsed:g}");

    async Task ProcessSample(SampleAndNumber sampleAndNumber)
    {
        var (fileName, sampleDto, sampleNumber) = sampleAndNumber;

        sampleDto.SampleCode = $"{fileName}_{sampleNumber}";

        var sampleJson = JsonConvert.SerializeObject(sampleDto);

        var response = await httpClient.PostAsync(arguments.Uri,
            new StringContent(sampleJson, Encoding.UTF8, "application/json"));
        if (!response.IsSuccessStatusCode)
        {
            log.WriteLine($"Sample upload {sampleNumber} failed with response: {response}"
                          + Environment.NewLine
                          + await response.Content.ReadAsStringAsync()
            );
        }
    }
}

static IEnumerable<string> GetFiles(Arguments arguments)
{
    IEnumerable<string> files = arguments.Files;

    if (!string.IsNullOrWhiteSpace(arguments.Directory))
    {
        files = files.Concat(Directory.EnumerateFiles(arguments.Directory, "*.csv", SearchOption.TopDirectoryOnly));
    }

    return files;
}

static async ValueTask LogErrors(IEnumerable<Error> errors)
{
    foreach (var error in errors)
    {
        await Console.Error.WriteLineAsync(error.ToString());
    }
}

static async IAsyncEnumerable<SampleAndNumber> ReadFile(string filePath, ILog log)
{
    log.WriteLine($"Parsing {filePath}");
    
    var fileName = Path.GetFileNameWithoutExtension(filePath);

    var recordNumber = new IntWrapper(1);

    using var reader = File.OpenText(filePath);
    using var csv = new CsvReader(reader, new CsvConfiguration(CultureInfo.InvariantCulture)
    {
        ReadingExceptionOccurred = SkipRowsWithErrors
    });

    csv.Context.RegisterClassMap<UploadSampleMap>();

    await foreach (var sampleDto in csv.GetRecordsAsync<UploadSampleDto>())
    {
        yield return new SampleAndNumber(fileName, sampleDto, recordNumber.Value++);
    }

    bool SkipRowsWithErrors(ReadingExceptionOccurredArgs readingException)
    {
        log.WriteLine($"Failed to parse record {recordNumber.Value++}: {GetReason(readingException)}");
        return false;
    }

    static string GetReason(ReadingExceptionOccurredArgs readingException)
    {
        return readingException.Exception switch
        {
            TypeConverterException typeConverterException =>
                $"Could not convert member '{typeConverterException.MemberMapData.Names.First()}', text: {typeConverterException.Text}",
            
            _ => readingException.Exception.InnerException?.Message ?? readingException.Exception.Message
        };
    }
}

internal record struct SampleAndNumber(string FileName, UploadSampleDto Sample, int RecordNumber);

internal class IntWrapper
{
    public IntWrapper(int value)
    {
        Value = value;
    }

    public int Value { get; set; }
}
