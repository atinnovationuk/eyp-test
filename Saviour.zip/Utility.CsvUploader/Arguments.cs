﻿using CommandLine;

namespace Utility.CsvUploader;

public class Arguments
{
    [Option('u', "uri", Required = true, HelpText = "API uri to send the data to")]
    public string Uri { get; set; } = string.Empty;

    [Option('d', "directory", HelpText = "Directory containing CSV files to process")]
    public string Directory { get; set; } = string.Empty;

    [Option('f', "files", HelpText = "Paths of CSV files to process")]
    public IReadOnlyCollection<string> Files { get; set; } = Array.Empty<string>();

    [Option('o', "output", HelpText = "File to send logging output to")]
    public string OutputFile { get; set; } = string.Empty;

    [Option('t', "threads", Default = 4, HelpText = "Maximum parallel threads to use. -1 sets unbounded (at your own risk)")]
    public int ParallelThreads { get; set; }
}
