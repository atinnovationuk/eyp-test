﻿namespace Saviour.EndToEnd.Fixture.Settings;

public record WebAppOverrides(bool UseHttps, int Port, string RedirectUri, int DefaultTimeout);