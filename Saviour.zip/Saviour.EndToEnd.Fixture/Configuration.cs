﻿using Microsoft.Extensions.Configuration;

namespace Saviour.EndToEnd.Fixture;

public class Configuration
{
    public static IConfigurationRoot GetTestConfiguration()
    {
        return new ConfigurationBuilder()
            .SetBasePath(Environment.CurrentDirectory)
            .AddEnvironmentVariables()
            .AddJsonFile("testsettings.json")
            .AddUserSecrets<Configuration>()
            .Build();
    }
}