﻿# End to End Tests Fixture

This library contains common code for running end to end tests on the application, in as close as possible to a production environment

## Initial Setup

Before running any end to end tests, a connection string to a SQL Server instance must be defined via `dotnet user-secrets`.

> NB: Make sure that the Database does not point to your dev database, as this will be deleted by the test runner

Some example commands are shown below:

Localdb:
```shell
dotnet user-secrets set "ConnectionString" "Server=localdb\MSSQLLocalDb; Database=SaviourE2ETests; Integrated Security=true; MultipleActiveResultSets=True; Encrypt=False;"
```

Linux docker container:
```shell
dotnet user-secrets set "ConnectionString" "Server=localhost; Database=SaviourE2ETests; User Id=SA; Password=ComplexP@55w0rd!; MultipleActiveResultSets=True; Encrypt=False;"
```
