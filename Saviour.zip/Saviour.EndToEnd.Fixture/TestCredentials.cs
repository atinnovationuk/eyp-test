﻿using System.Net.Http.Headers;
using Azure.Core;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Client;

namespace Saviour.EndToEnd.Fixture;

public enum TestUserType
{
    Analyst,
    Customer
}

public class TestCredentials
{
    public PublicClientApplicationOptions AuthenticationOptions { get; } = new();
    private readonly IConfigurationRoot _configuration;

    public TestCredentials()
    {
        _configuration = Configuration.GetTestConfiguration();

        _configuration.Bind("Authentication", AuthenticationOptions);
    }

    public async ValueTask AddAuthentication(HttpClient client, TestUserType userType)
    {
        var accessToken = await GetAccessToken(userType);

        client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", accessToken);
    }

    private async ValueTask<string> GetAccessToken(TestUserType userType)
    {
        var (username, password) = await GetCredentials(userType);

        var scopes = _configuration.GetSection("WebAPI:Scopes").Get<string[]>() ?? Array.Empty<string>();
        return await GetAccessToken(scopes, username, password);
    }

    public async ValueTask<(string username, string password)> GetCredentials(TestUserType userType)
    {
        var (usernameKey, passwordKey) = GetKeys(userType);

        var options = new SecretClientOptions
        {
            Retry =
            {
                Delay= TimeSpan.FromSeconds(2),
                MaxDelay = TimeSpan.FromSeconds(16),
                MaxRetries = 5,
                Mode = RetryMode.Exponential
            }
        };
        
        var keyVaultUri = _configuration.GetValue<string>("KeyVault:KeyVaultUri")!;
        var client = new SecretClient(new Uri(keyVaultUri), new DefaultAzureCredential(), options);

        return (
            (await client.GetSecretAsync(usernameKey)).Value.Value,
            (await client.GetSecretAsync(passwordKey)).Value.Value
        );
    }

    private static (string userKey, string passwordKey) GetKeys(TestUserType userType)
        => userType switch
        {
            TestUserType.Analyst => ("AnalystUserName", "AnalystPassword"),
            TestUserType.Customer => ("CustomerUserName", "CustomerPassword"),
            _ => throw new ArgumentOutOfRangeException(nameof(userType), userType, null)
        };

    private async ValueTask<string> GetAccessToken(IEnumerable<string> scopes, string username, string password)
    {
        using var httpClient = new HttpClient();

        var app = PublicClientApplicationBuilder.CreateWithApplicationOptions(AuthenticationOptions)
            .Build();

        var result = await app.AcquireTokenByUsernamePassword(scopes, username, password)
            .ExecuteAsync();

        return result.AccessToken;
    }
}