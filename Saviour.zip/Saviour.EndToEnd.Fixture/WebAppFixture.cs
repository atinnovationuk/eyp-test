using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Hosting.Server.Features;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Saviour.Application;
using Saviour.EndToEnd.Fixture.Settings;
using Saviour.Infrastructure;

namespace Saviour.EndToEnd.Fixture;

public class WebAppFixture : WebApplicationFactory<Program>
{
    private readonly DbContextOptions<SaviourContext> _dbContextOptions;

    public SaviourContext Database { get; }

    public TestCredentials TestCredentials { get; } = new();

    public WebAppOverrides WebAppOverrides { get; } = new(false, 0, string.Empty, 30_000);
    
    public IConfigurationRoot Configuration { get; }

    public WebAppFixture()
    {
        Configuration = Fixture.Configuration.GetTestConfiguration();

        Configuration.Bind("WebAppOverrides", WebAppOverrides);
        
        var authenticationOptions = TestCredentials.AuthenticationOptions;
        
        // Force some web app settings to be overridden by environment variables
        Environment.SetEnvironmentVariable("AzureAd:RedirectUri", WebAppOverrides.RedirectUri);
        Environment.SetEnvironmentVariable("AzureAd:TenantId", authenticationOptions.TenantId);
        Environment.SetEnvironmentVariable("AzureAd:ClientId", authenticationOptions.ClientId);

        var connectionString = Configuration.GetValue<string>("ConnectionString");
        
        _dbContextOptions = new DbContextOptionsBuilder<SaviourContext>()
            .UseSqlServer(connectionString)
            .Options;
        
        Database = new SaviourContext(_dbContextOptions);

        Database.Database.EnsureDeleted();
        Database.Database.Migrate();
    }

    public override async ValueTask DisposeAsync()
    {
        await base.DisposeAsync();
        await Database.Database.EnsureDeletedAsync();
        await Database.DisposeAsync();
    }

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("E2E Tests");
    }

    protected override IHost CreateHost(IHostBuilder builder)
    {
        builder.ConfigureServices(services =>
        {
            services.AddScoped(_ => _dbContextOptions);
        });

        // Create the host for TestServer now before we modify the builder to use Kestrel instead.    
        var testHost = builder.Build();  
 
        // Modify the host builder to use Kestrel instead so we can listen on a real address. 
        builder.ConfigureWebHost(webHostBuilder => webHostBuilder.UseKestrel(options =>
        {
            options.ListenLocalhost(WebAppOverrides.Port, listenOptions =>
            {
                if (WebAppOverrides.UseHttps)
                {
                    listenOptions.UseHttps();
                }
            });
        }));
        var host = builder.Build();  
        host.Start();

        // Extract the Kestrel server URL
        var server = host.Services.GetRequiredService<IServer>();  
        var addresses = server.Features.Get<IServerAddressesFeature>();
        ClientOptions.BaseAddress = addresses!.Addresses  
            .Select(x => new Uri(x))  
            .Last();

        // Return the original TestServer instance so that internals use it
        testHost.Start();  
        return testHost; 
    }
}
