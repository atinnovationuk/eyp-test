﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Moq;
using Saviour.Application.Security;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;

namespace Saviour.Application.Tests.Security;

public class AnalystRequirementHandlerTests
{
    private readonly AnalystRequirementHandler _handler;

    private readonly List<IAuthorizationRequirement> _requirements;
    private readonly AuthorizationHandlerContext _context;
    private bool _hasAnalystRole;

    public AnalystRequirementHandlerTests()
    {
        _requirements = new List<IAuthorizationRequirement>
        {
            new AnalystRequirement()
        };

        var user = Mock.Of<ClaimsPrincipal>();

        var userTypeService = new Mock<IUserTypeService>();
        userTypeService.Setup(u => u.Get(user))
            .Returns(() => _hasAnalystRole ? UserType.WellfishAnalyst : UserType.Customer);
        
        _handler = new AnalystRequirementHandler(userTypeService.Object);

        _context = new AuthorizationHandlerContext(_requirements, user, null);
    }

    private async ValueTask<bool> Check()
    {
        await _handler.HandleAsync(_context);
        return _context.HasSucceeded;
    }

    [Fact]
    public async Task ApprovesWhenHasClaimIsTrue()
    {
        _hasAnalystRole = true;

        Assert.True(await Check());
    }

    [Fact]
    public async Task RejectsWhenRequirementNotRequested()
    {
        _hasAnalystRole = true;
        _requirements.Clear();

        Assert.False(await Check());
    }

    [Fact]
    public async Task RejectsWhenDoesNotHaveRole()
    {
        _hasAnalystRole = false;
        
        Assert.False(await Check());
    }
}