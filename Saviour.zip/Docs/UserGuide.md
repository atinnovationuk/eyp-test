
## App Navigation

### Companies and Sites

A list of all companies and sites is shown on the side of the app.
On smaller screens such as mobile phones this panel must be expanded via the hamburger button in the bottom-left of the app.

Each company can be expanded to show a list of all of its sites.

Clicking on a company will show a list of all draft and approved reports for that company.

Clicking on a site will show the report generation page for that site. See [Report Generation](#report-generation) for more details.

![](./Screenshots/CompanyTree.png)

### Pending Work

The main page of the application will display lists of work that requires action:

- New batches which require report generation
- Draft reports which are awaiting review

These will be grouped under their corresponding Company and Site, which can be expanded to show links to:

![](./Screenshots/LandingPageNavigation.png)

## Report Generation

To generate a report, follow the process below:

1. Navigate to the relevant site
   - NB: The company must have an address defined (see [Company Management](#company-management))
2. Select the batches to be analysed
3. Enter clinical observations
4. Enter deviations to the regular process (if applicable)
5. Press Save

This will generate a report in a draft state.

A draft report must be reviewed and approved by a second analyst, whereupon they will become available to the relevant customer.
A preview of the PDF report can be downloaded to assist in this review.

A draft report may be deleted if it was created in error or if edits are to be made.

## Company Management

The Company Management page is accessed via a link in the side-panel of the app.

### Enter an Address

Report generation requires an address to be defined for each client company. 
This can be entered on the Company Management page, and applied via the button shown:

![](./Screenshots/ApplyAddress.png)

### Adding a new company

Companies and their sites are automatically created when sample data is uploaded, 
however it may be necessary to define a company before sample data is available. 

To do this, use the inputs at the bottom of the Company Management page. The following information must be available:

- The unique 'Company Code'
- Company Name
- Address

Pressing the button will submit this to the system.

![](./Screenshots/NewCompany.png)

#### Deleting a company

If a mistake is made in company creation, the new company may be deleted via the button shown:

![](./Screenshots/DeleteCompany.png)

Note that this is not possible to delete companies where sample data has been received.

### Adding a new user

A company's users must be defined before they can access the system. 
This is defined on the User Management page for each company, which can be accessed by clicking the company's name in Company Management.

All defined users will be listed on this page, and may be modified if necessary.

To add a new user, enter the following information at the bottom of the page and press the submit button.

- Their name
- The email they will use to sign into the system

![](./Screenshots/UserManagement.png)
