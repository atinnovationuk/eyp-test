import MarkdownPDF from "markdown-pdf"

MarkdownPDF({
  cssPath: "./github-markdown.css",
  remarkable: {
    html: true
  }
}).from(['./UserGuide.md'])
.to('../Saviour.Application/clientapp/src/user-guides/UserGuide.pdf');
