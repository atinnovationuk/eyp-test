﻿using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Saviour.Domain.Interfaces;

namespace Saviour.Infrastructure;

public class EntityFrameworkUnitOfWork : IUnitOfWork
{
    private readonly DbContext _dbContext;

    public EntityFrameworkUnitOfWork(DbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public async ValueTask<ITransaction> BeginTransaction()
    {
        var transaction = await _dbContext.Database.BeginTransactionAsync();
        return new Transaction(transaction);
    }

    public async ValueTask SaveChangesAsync() => await _dbContext.SaveChangesAsync();

    private class Transaction : ITransaction
    {
        private readonly IDbContextTransaction _transaction;

        public Transaction(IDbContextTransaction transaction)
        {
            _transaction = transaction;
        }

        public async ValueTask Commit()
        {
            await _transaction.CommitAsync();
        }

        public async ValueTask Rollback()
        {
            await _transaction.RollbackAsync();
        }

        public void Dispose()
        {
            _transaction.Dispose();
        }
    }
}
