﻿using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Entities;

namespace Saviour.Infrastructure;

internal static class SeedingHelpers
{
    public static void SeedBiomarkerAndAnalysisData(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Biomarker>()
            .HasData(
                new
                {
                    Id = 1,
                    Name = "ALBUMIN"
                },
                new
                {
                    Id = 19,
                    Name = "ALB2-G",
                    ParentId = 1
                },
                new
                {
                    Id = 2,
                    Name = "CHLORIDE"
                },
                new
                {
                    Id = 25,
                    Name = "ISE CL",
                    ParentId = 2
                },
                new
                {
                    Id = 3,
                    Name = "ZINC"
                },
                new
                {
                    Id = 42,
                    Name = "ZINC 1:5",
                    ParentId = 3
                },
                new
                {
                    Id = 4,
                    Name = "ALT"
                },
                new
                {
                    Id = 20,
                    Name = "ALTP",
                    ParentId = 4
                },
                new
                {
                    Id = 5,
                    Name = "CK"
                },
                new
                {
                    Id = 40,
                    Name = "CK2 1:50",
                    ParentId = 5
                },
                new
                {
                    Id = 6,
                    Name = "CK MB"
                },
                new
                {
                    Id = 41,
                    Name = "CKMB2 1:50",
                    ParentId = 6
                },
                new
                {
                    Id = 7,
                    Name = "AST"
                },
                new
                {
                    Id = 39,
                    Name = "ASTP 1:10",
                    ParentId = 7
                },
                new
                {
                    Id = 8,
                    Name = "LDH"
                },
                new
                {
                    Id = 29,
                    Name = "LDHI2",
                    ParentId = 8
                },
                new
                {
                    Id = 9,
                    Name = "LIPASE"
                },
                new
                {
                    Id = 30,
                    Name = "LIP",
                    ParentId = 9
                },
                new
                {
                    Id = 10,
                    Name = "GLUCOSE"
                },
                new
                {
                    Id = 23,
                    Name = "GLUC3",
                    ParentId = 10
                },
                new
                {
                    Id = 11,
                    Name = "CHOLESTEROL"
                },
                new
                {
                    Id = 22,
                    Name = "CHOL2-I",
                    ParentId = 11
                },
                new
                {
                    Id = 12,
                    Name = "IRON"
                },
                new
                {
                    Id = 24,
                    Name = "IRON2",
                    ParentId = 12
                },
                new
                {
                    Id = 13,
                    Name = "LACTATE"
                },
                new
                {
                    Id = 28,
                    Name = "LACT2P",
                    ParentId = 13
                },
                new
                {
                    Id = 14,
                    Name = "PHOSPHATE"
                },
                new
                {
                    Id = 31,
                    Name = "PHOS2",
                    ParentId = 14
                },
                new
                {
                    Id = 15,
                    Name = "MAGNESIUM"
                },
                new
                {
                    Id = 36,
                    Name = "MG2",
                    ParentId = 15
                },
                new
                {
                    Id = 16,
                    Name = "SODIUM"
                },
                new
                {
                    Id = 27,
                    Name = "ISE NA",
                    ParentId = 16
                },
                new
                {
                    Id = 17,
                    Name = "POTASSIUM"
                },
                new
                {
                    Id = 26,
                    Name = "ISE K",
                    ParentId = 17
                },
                new
                {
                    Id = 18,
                    Name = "CALCIUM"
                },
                new
                {
                    Id = 21,
                    Name = "CA2",
                    ParentId = 18
                },
                new
                {
                    Id = 32,
                    Name = "SI2"
                },
                new
                {
                    Id = 44,
                    Name = "SI2-L"
                },
                new
                {
                    Id = 33,
                    Name = "SI2 L",
                    ParentId = 44
                },
                new
                {
                    Id = 45,
                    Name = "SI2-H"
                },
                new
                {
                    Id = 34,
                    Name = "SI2 H",
                    ParentId = 45
                },
                new
                {
                    Id = 46,
                    Name = "SI2-I"
                },
                new
                {
                    Id = 35,
                    Name = "SI2 I",
                    ParentId = 46
                },
                new
                {
                    Id = 37,
                    Name = "ALP2"
                },
                new
                {
                    Id = 47,
                    Name = "AMY"
                },
                new
                {
                    Id = 38,
                    Name = "AMYL2",
                    ParentId = 47
                },
                new
                {
                    Id = 48,
                    Name = "UIBC"
                },
                new
                {
                    Id = 43,
                    Name = "UIBC-I",
                    ParentId = 48
                });

        modelBuilder.Entity<Analysis>()
            .HasData(
                new Analysis
                {
                    Id = 1,
                    MethodName = "GENERAL HOMEOSTASIS"
                },
                new Analysis
                {
                    Id = 2,
                    MethodName = "MUSCLE/LIVER TISSUE DAMAGE"
                },
                new Analysis
                {
                    Id = 3,
                    MethodName = "LIVER/GENERAL STRESS/PANCREAS"
                },
                new Analysis
                {
                    Id = 4,
                    MethodName = "LIVER FUNCTION"
                },
                new Analysis
                {
                    Id = 5,
                    MethodName = "GILL FUNCTION"
                },
                new Analysis
                {
                    Id = 6,
                    MethodName = "GILL/LIVER FUNCTION"
                }
            );

        modelBuilder.Entity<BiomarkerRange>()
            .HasData(
                // General homeostasis
                // Albumin
                new BiomarkerRange
                {
                    Id = 1,
                    BiomarkerId = 1,
                    AnalysisId = 1,
                    Min = 0,
                    LowRed = 15.20,
                    LowAmber = 17.20,
                    Reference = 21.10,
                    HighAmber = 23.10,
                    Max = 30.00,
                    CountryCode = null
                },
                // Chloride
                new BiomarkerRange
                {
                    Id = 2,
                    BiomarkerId = 2,
                    AnalysisId = 1,
                    Min = 50,
                    LowRed = 128.80,
                    LowAmber = 131.50,
                    Reference = 136.60,
                    HighAmber = 139.60,
                    Max = 250.00,
                    CountryCode = null
                },
                // Zinc
                new BiomarkerRange
                {
                    Id = 3,
                    BiomarkerId = 3,
                    AnalysisId = 1,
                    Min = 0,
                    LowRed = 189.90,
                    LowAmber = 244.10,
                    Reference = 352.40,
                    HighAmber = 406.60,
                    Max = 500.00,
                    CountryCode = null
                },
                
                // Muscle/liver tissue damage
                // ALT
                new BiomarkerRange
                {
                    Id = 4,
                    BiomarkerId = 4,
                    AnalysisId = 2,
                    Min = 0,
                    LowRed = 2.00,
                    LowAmber = 4.00,
                    Reference = 10.00,
                    HighAmber = 12.00,
                    Max = 500.00,
                    CountryCode = null
                },
                // CK
                new BiomarkerRange
                {
                    Id = 5,
                    BiomarkerId = 5,
                    AnalysisId = 2,
                    Min = 0,
                    LowRed = 2_686,
                    LowAmber = 3_529,
                    Reference = 15_960,
                    HighAmber = 22_176,
                    Max = 900_000,
                    CountryCode = null
                },
                // CK MB
                new BiomarkerRange
                {
                    Id = 6,
                    BiomarkerId = 6,
                    AnalysisId = 2,
                    Min = 0,
                    LowRed = 4_311,
                    LowAmber = 6_073,
                    Reference = 26_842,
                    HighAmber = 37_226,
                    Max = 1_000_000,
                    CountryCode = null
                },
                
                // Liver/General Stress/Pancreas
                // AST
                new BiomarkerRange
                {
                    Id = 7,
                    BiomarkerId = 7,
                    AnalysisId = 3,
                    Min = 0,
                    LowRed = 93.60,
                    LowAmber = 354.20,
                    Reference = 875.00,
                    HighAmber = 1136.00,
                    Max = 50_000.00,
                    CountryCode = null
                },
                // LDH
                new BiomarkerRange
                {
                    Id = 8,
                    BiomarkerId = 8,
                    AnalysisId = 3,
                    Min = 0,
                    LowRed = 172.90,
                    LowAmber = 220.50,
                    Reference = 1007.00,
                    HighAmber = 1400.00,
                    Max = 50_000.00,
                    CountryCode = null
                },
                // Lipase
                new BiomarkerRange
                {
                    Id = 9,
                    BiomarkerId = 9,
                    AnalysisId = 3,
                    Min = 0,
                    LowRed = 5.20,
                    LowAmber = 5.70,
                    Reference = 6.70,
                    HighAmber = 7.20,
                    Max = 50.00,
                    CountryCode = null
                },
                
                // Liver function
                // Glucose
                new BiomarkerRange
                {
                    Id = 10,
                    BiomarkerId = 10,
                    AnalysisId = 4,
                    Min = 0,
                    LowRed = 3.68,
                    LowAmber = 4.30,
                    Reference = 5.57,
                    HighAmber = 6.19,
                    Max = 20.00,
                    CountryCode = null
                },
                // Cholesterol
                new BiomarkerRange
                {
                    Id = 11,
                    BiomarkerId = 11,
                    AnalysisId = 4,
                    Min = 0,
                    LowRed = 5.66,
                    LowAmber = 7.20,
                    Reference = 10.29,
                    HighAmber = 11.83,
                    Max = 20.00,
                    CountryCode = null
                },
                // Iron
                new BiomarkerRange
                {
                    Id = 12,
                    BiomarkerId = 12,
                    AnalysisId = 4,
                    Min = 0,
                    LowRed = 8.03,
                    LowAmber = 12.70,
                    Reference = 22.05,
                    HighAmber = 26.73,
                    Max = 50.00,
                    CountryCode = null
                },
                
                // Gill function
                // Lactate
                new BiomarkerRange
                {
                    Id = 13,
                    BiomarkerId = 13,
                    AnalysisId = 5,
                    Min = 0,
                    LowRed = 1.97,
                    LowAmber = 2.87,
                    Reference = 4.66,
                    HighAmber = 5.55,
                    Max = 50.00,
                    CountryCode = null
                },
                // Phosphate
                new BiomarkerRange
                {
                    Id = 14,
                    BiomarkerId = 14,
                    AnalysisId = 5,
                    Min = 0,
                    LowRed = 3.76,
                    LowAmber = 4.33,
                    Reference = 5.45,
                    HighAmber = 6.01,
                    Max = 20.00,
                    CountryCode = null
                },
                // Magnesium
                new BiomarkerRange
                {
                    Id = 15,
                    BiomarkerId = 15,
                    AnalysisId = 5,
                    Min = 0,
                    LowRed = 0.82,
                    LowAmber = 1.04,
                    Reference = 1.47,
                    HighAmber = 1.69,
                    Max = 10.00,
                    CountryCode = null
                },
                
                // Gill/Liver function
                // Sodium
                new BiomarkerRange
                {
                    Id = 16,
                    BiomarkerId = 16,
                    AnalysisId = 6,
                    Min = 0,
                    LowRed = 161.10,
                    LowAmber = 163.80,
                    Reference = 169.10,
                    HighAmber = 171.80,
                    Max = 300.00,
                    CountryCode = null
                },
                // Potassium
                new BiomarkerRange
                {
                    Id = 17,
                    BiomarkerId = 17,
                    AnalysisId = 6,
                    Min = 0,
                    LowRed = 0.40,
                    LowAmber = 0.60,
                    Reference = 0.90,
                    HighAmber = 1.10,
                    Max = 20.00,
                    CountryCode = null
                },
                // Calcium
                new BiomarkerRange
                {
                    Id = 18,
                    BiomarkerId = 18,
                    AnalysisId = 6,
                    Min = 0,
                    LowRed = 2.90,
                    LowAmber = 3.10,
                    Reference = 3.40,
                    HighAmber = 3.60,
                    Max = 20.00,
                    CountryCode = null
                }
            );


        modelBuilder.Entity<MLBiomarker>()
            .HasData(
                new MLBiomarker
                {
                    Id = 1,
                    Name = "ALBUMIN",
                    BiomarkerId = 1,
                    Min = 0.13M,
                    Max = 33.8M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 1
                },
                new MLBiomarker
                {
                    Id = 2,
                    Name = "CHLORIDE__Cl_",
                    BiomarkerId = 2,
                    Min = 17,
                    Max = 289.5M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 9
                },
                new MLBiomarker
                {
                    Id = 3,
                    Name = "ZINC__Zn_",
                    BiomarkerId = 3,
                    Min = 7.95M,
                    Max = 444,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 7
                },
                new MLBiomarker
                {
                    Id = 4,
                    Name = "ALT",
                    BiomarkerId = 4,
                    Min = 0.1M,
                    Max = 864,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 2
                },
                new MLBiomarker
                {
                    Id = 5,
                    Name = "CK",
                    BiomarkerId = 5,
                    Min = 0.23M,
                    Max = 1463295,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 5
                },
                new MLBiomarker
                {
                    Id = 6,
                    Name = "CK_MB",
                    BiomarkerId = 6,
                    Min = 0.514M,
                    Max = 2767386,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 6
                },
                new MLBiomarker
                {
                    Id = 7,
                    Name = "AST",
                    BiomarkerId = 7,
                    Min = 27,
                    Max = 28242,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 3
                },
                new MLBiomarker
                {
                    Id = 8,
                    Name = "LIPASE",
                    BiomarkerId = 9,
                    Min = 0,
                    Max = 34,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 15
                },
                new MLBiomarker
                {
                    Id = 9,
                    Name = "GLUCOSE",
                    BiomarkerId = 10,
                    Min = 0.00822M,
                    Max = 15M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 8
                },
                new MLBiomarker
                {
                    Id = 10,
                    Name = "CHOLESTEROL",
                    BiomarkerId = 11,
                    Min = 0.27M,
                    Max = 18.1M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 11
                },
                new MLBiomarker
                {
                    Id = 11,
                    Name = "IRON__Fe_",
                    BiomarkerId = 12,
                    Min = 0.04M,
                    Max = 56.3M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 10
                },
                new MLBiomarker
                {
                    Id = 12,
                    Name = "LACTATE",
                    BiomarkerId = 13,
                    Min = 0.49M,
                    Max = 26.3M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 14
                },
                new MLBiomarker
                {
                    Id = 13,
                    Name = "SODIUM__Na_",
                    BiomarkerId = 16,
                    Min = 14.5M,
                    Max = 314.6M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 12
                },
                new MLBiomarker
                {
                    Id = 14,
                    Name = "POTASSIUM__K_",
                    BiomarkerId = 17,
                    Min = 0.29M,
                    Max = 29.35M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 13
                },
                new MLBiomarker
                {
                    Id = 15,
                    Name = "CALCIUM__Ca_",
                    BiomarkerId = 18,
                    Min = 0,
                    Max = 8.14M,
                    ModelType = MLModelType.FishHealth,
                    SortOrder = 4
                }
            );
    }

    public static void SeedMLModels(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<MLModel>()
            .HasData(
                new MLModel
                {
                    Id = 1,
                    Type = MLModelType.FishHealth,
                    Version = 1
                }
            );
    }
}
