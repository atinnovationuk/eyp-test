﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using Saviour.Domain.Entities;
using Saviour.Domain.Validation;
using DateOnlyConverter = Saviour.Infrastructure.Converters.DateOnlyConverter;

namespace Saviour.Infrastructure;

public class SaviourContext : DbContext
{
    public DbSet<Company> Companies { get; set; }
    public DbSet<Site> Sites { get; set; }
    public DbSet<Country> Countries { get; set; }

    public DbSet<Batch> Batches { get; set; }
    public DbSet<Sample> Samples { get; set; }
    public DbSet<Biomarker> Biomarkers { get; set; }
    public DbSet<BiomarkerResult> BiomarkerResults { get; set; }
    public DbSet<Hatchery> Hatcheries { get; set; }
    
    public DbSet<Analysis> Analyses { get; set; }
    public DbSet<BiomarkerRange> BiomarkerRanges { get; set; }

    public DbSet<DraftReport> DraftReports { get; set; }
    public DbSet<DraftReportBatch> DraftReportedBatches { get; set; }
    public DbSet<DraftReportAnalysis> DraftReportAnalyses { get; set; }

    public DbSet<Report> Reports { get; set; }
    public DbSet<ReportedBatch> ReportedBatches { get; set; }
    public DbSet<ReportAnalysis> ReportAnalyses { get; set; }

    public DbSet<Employee> Employees { get; set; }
    public DbSet<User> Users { get; set; }

    public DbSet<MLModel> MLModels { get; set; }
    public DbSet<MLBiomarker> MLBiomarkers { get; set; }
    
    public DbSet<FishHealthResult> FishHealthResults { get; set; }
    public DbSet<ReportedFishHealthResult> ReportedFishHealthResults { get; set; }

    public SaviourContext(DbContextOptions<SaviourContext> options)
        : base(options)
    {
    }

    protected override void ConfigureConventions(ModelConfigurationBuilder builder)
    {
        builder.Properties<DateOnly>()
            .HaveConversion<DateOnlyConverter>()
            .HaveColumnType("date");
    }
    
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        ConfigureDateTime(modelBuilder);
        
        ConfigureCompaniesAndSites(modelBuilder);

        ConfigureCountries(modelBuilder);

        ConfigureSamples(modelBuilder);

        ConfigureHatcheries(modelBuilder);

        ConfigureBiomarkers(modelBuilder);

        ConfigureDraftReports(modelBuilder);
        ConfigureReports(modelBuilder);

        ConfigureEmployees(modelBuilder);
        
        ConfigureUsers(modelBuilder);

        ConfigureMLTables(modelBuilder);

        SeedingHelpers.SeedBiomarkerAndAnalysisData(modelBuilder);
        SeedingHelpers.SeedMLModels(modelBuilder);
    }

    private static void ConfigureDateTime(ModelBuilder modelBuilder)
    {
        var dateTimeConverter = new ValueConverter<DateTime, DateTime>(
            v => v.ToUniversalTime(),
            v => DateTime.SpecifyKind(v, DateTimeKind.Utc));

        var nullableDateTimeConverter = new ValueConverter<DateTime?, DateTime?>(
            v => v.HasValue ? v.Value.ToUniversalTime() : v,
            v => v.HasValue ? DateTime.SpecifyKind(v.Value, DateTimeKind.Utc) : v);

        foreach (var entityType in modelBuilder.Model.GetEntityTypes())
        {
            foreach (var property in entityType.GetProperties())
            {
                if (property.ClrType == typeof(DateTime))
                {
                    property.SetValueConverter(dateTimeConverter);
                }
                else if (property.ClrType == typeof(DateTime?))
                {
                    property.SetValueConverter(nullableDateTimeConverter);
                }
            }
        }
    }

    private static void ConfigureUsers(ModelBuilder modelBuilder)
    {
        var userBuilder = modelBuilder.Entity<User>();

        userBuilder.HasKey(u => u.Id);

        userBuilder.Property(u => u.AzureId)
            .IsRequired()
            .HasMaxLength(Limits.Users.AzureId);

        userBuilder.Property(u => u.Name)
            .IsRequired()
            .HasMaxLength(Limits.Users.Name);

        userBuilder.HasIndex(u => u.AzureId)
            .IsUnique()
            .IsClustered(false);
    }

    private static void ConfigureEmployees(ModelBuilder modelBuilder)
    {
        var employeeBuilder = modelBuilder.Entity<Employee>();

        employeeBuilder.HasKey(e => e.Id);

        employeeBuilder.Property(e => e.Name)
            .IsRequired()
            .HasMaxLength(Limits.Employees.Name);

        employeeBuilder.Property(e => e.LoginIdentity)
            .IsRequired()
            .HasMaxLength(Limits.Employees.LoginIdentity);

        employeeBuilder.HasOne(e => e.Company)
            .WithMany()
            .IsRequired()
            .HasForeignKey(e => e.CompanyId)
            .OnDelete(DeleteBehavior.Cascade);

        employeeBuilder.HasIndex(e => e.LoginIdentity)
            .IsClustered(false)
            .IsUnique(false);
    }

    private static void ConfigureCountries(ModelBuilder modelBuilder)
    {
        var countryBuilder = modelBuilder.Entity<Country>();
        
        countryBuilder
            .HasKey(c => c.Code);
        countryBuilder
            .Property(c => c.Code)
            .HasMaxLength(Limits.Countries.Code);
    }

    private static void ConfigureCompaniesAndSites(ModelBuilder modelBuilder)
    {
        var companyBuilder = modelBuilder.Entity<Company>();
        companyBuilder.HasKey(c => c.Id);
        companyBuilder.Property(c => c.Id)
            .HasMaxLength(Limits.Companies.Id);

        companyBuilder.Property(c => c.CompanyName)
            .IsRequired()
            .HasMaxLength(Limits.Companies.Name);

        companyBuilder.Property(c => c.Address)
            .IsRequired()
            .HasMaxLength(Limits.Companies.Address);

        companyBuilder
            .HasMany(e => e.Sites)
            .WithOne(e => e.Company)
            .HasForeignKey(e => e.CompanyId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

        var siteBuilder = modelBuilder.Entity<Site>();

        siteBuilder.HasKey(s => s.Id);

        siteBuilder.Property(s => s.Id)
            .HasMaxLength(Limits.Sites.Id);

        siteBuilder.Property(s => s.SiteName)
            .HasMaxLength(Limits.Sites.Name)
            .IsRequired();

        siteBuilder.HasOne(s => s.Country)
            .WithMany()
            .IsRequired()
            .HasForeignKey(s => s.CountryCode)
            .OnDelete(DeleteBehavior.Restrict);
    }

    private static void ConfigureDraftReports(ModelBuilder modelBuilder)
    {
        var draftBuilder = modelBuilder.Entity<DraftReport>();

        var reportBatchBuilder = draftBuilder.HasMany(r => r.Batches)
            .WithMany()
            .UsingEntity<DraftReportBatch>();

        var reportAnalysisBuilder = draftBuilder.HasMany(r => r.Analyses)
            .WithMany()
            .UsingEntity<DraftReportAnalysis>();

        draftBuilder.HasOne(r => r.Site)
            .WithMany()
            .IsRequired()
            .HasForeignKey(r => r.SiteId)
            .OnDelete(DeleteBehavior.Cascade);

        draftBuilder.HasOne(r => r.CreatedBy)
            .WithMany()
            .IsRequired()
            .HasForeignKey(r => r.CreatedById)
            .OnDelete(DeleteBehavior.Restrict);

        draftBuilder.Property(r => r.Observations)
            .IsRequired();

        reportBatchBuilder.HasOne<Batch>()
            .WithMany()
            .HasForeignKey(r => r.BatchId)
            .IsRequired()
            .OnDelete(DeleteBehavior.ClientCascade);
        
        reportBatchBuilder.HasOne<DraftReport>()
            .WithMany()
            .HasForeignKey(r => r.DraftReportId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

        reportAnalysisBuilder.HasOne<Analysis>()
            .WithMany()
            .HasForeignKey(r => r.AnalysisId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);

        reportAnalysisBuilder.HasOne<DraftReport>()
            .WithMany()
            .HasForeignKey(r => r.DraftReportId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);
    }
    
    private static void ConfigureReports(ModelBuilder modelBuilder)
    {
        var reportBuilder = modelBuilder.Entity<Report>();

        reportBuilder.HasMany(r => r.Batches)
            .WithMany(b => b.Reports)
            .UsingEntity<ReportedBatch>();

        reportBuilder.HasMany(r => r.Analyses)
            .WithMany()
            .UsingEntity<ReportAnalysis>();

        reportBuilder.HasOne(r => r.Site)
            .WithMany()
            .IsRequired()
            .HasForeignKey(r => r.SiteId)
            .OnDelete(DeleteBehavior.Cascade);

        reportBuilder.HasOne(r => r.CreatedBy)
            .WithMany()
            .IsRequired()
            .HasForeignKey(r => r.CreatedById)
            .OnDelete(DeleteBehavior.Restrict);

        reportBuilder.HasOne(r => r.ReviewedBy)
            .WithMany()
            .HasForeignKey(r => r.ReviewedById)
            .OnDelete(DeleteBehavior.Restrict);

        reportBuilder.Property(r => r.Observations)
            .IsRequired();

        var reportedBatchBuilder = modelBuilder.Entity<ReportedBatch>();
        
        reportedBatchBuilder.HasOne<Batch>()
            .WithMany()
            .HasForeignKey(r => r.BatchId)
            .IsRequired()
            .OnDelete(DeleteBehavior.ClientCascade);
        
        reportedBatchBuilder.HasOne<Report>()
            .WithMany()
            .HasForeignKey(r => r.ReportId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

        var reportAnalysisBuilder = modelBuilder.Entity<ReportAnalysis>();
        reportAnalysisBuilder.HasOne<Analysis>()
            .WithMany()
            .HasForeignKey(r => r.AnalysisId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);

        reportAnalysisBuilder.HasOne<Report>()
            .WithMany()
            .HasForeignKey(r => r.ReportId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);
    }

    private static void ConfigureHatcheries(ModelBuilder modelBuilder)
    {
        var hatcheryBuilder = modelBuilder.Entity<Hatchery>();
        hatcheryBuilder.Property(e => e.Id).ValueGeneratedOnAdd();
        hatcheryBuilder.Property(h => h.HatcheryCode)
            .IsRequired()
            .HasMaxLength(Limits.Hatcheries.Code);

        hatcheryBuilder.HasIndex(h => h.HatcheryCode)
            .IsUnique()
            .IsClustered(false);

        hatcheryBuilder
            .HasMany(e => e.Samples)
            .WithMany(e => e.Hatcheries);
    }

    private static void ConfigureBiomarkers(ModelBuilder modelBuilder)
    {
        var biomarkerBuilder = modelBuilder.Entity<Biomarker>();
        biomarkerBuilder.HasKey(b => b.Id);
        biomarkerBuilder.Property(b => b.Name)
            .IsRequired()
            .HasMaxLength(Limits.Biomarkers.Name);
        biomarkerBuilder.HasIndex(b => b.Name)
            .IsUnique()
            .IsClustered(false);

        biomarkerBuilder.HasOne(b => b.Parent)
            .WithMany(b => b.Children)
            .HasForeignKey(b => b.ParentId)
            .IsRequired(false)
            .OnDelete(DeleteBehavior.NoAction);

        var analysisBuilder = modelBuilder.Entity<Analysis>();
        analysisBuilder.HasKey(a => a.Id);

        analysisBuilder.Property(a => a.MethodName)
            .IsRequired()
            .HasMaxLength(Limits.Analyses.MethodName);

        analysisBuilder.HasMany(a => a.BiomarkerRanges)
            .WithOne(b => b.Analysis)
            .HasForeignKey(b => b.AnalysisId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

        var biomarkerRangeBuilder = modelBuilder.Entity<BiomarkerRange>();
        biomarkerRangeBuilder.HasKey(b => b.Id);
        biomarkerRangeBuilder.HasOne(b => b.Biomarker)
            .WithMany()
            .HasForeignKey(b => b.BiomarkerId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);

        var biomarkerResultBuilder = modelBuilder.Entity<BiomarkerResult>();
        biomarkerResultBuilder.HasKey(b => b.Id);
        
        biomarkerResultBuilder.HasOne(b => b.Biomarker)
            .WithMany()
            .HasForeignKey(b => b.BioMarkerId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Restrict);

        biomarkerResultBuilder.Property(b => b.Result)
            .HasPrecision(18, 6);
    }
    
    private static void ConfigureSamples(ModelBuilder modelBuilder)
    {
        var batchBuilder = modelBuilder.Entity<Batch>();
        batchBuilder.HasKey(b => b.Id);

        batchBuilder
            .HasOne(b => b.Site)
            .WithMany(s => s.Batches)
            .HasForeignKey(b => b.SiteId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

        batchBuilder.HasMany(b => b.Samples)
            .WithOne(s => s.Batch)
            .HasForeignKey(s => s.BatchId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

        batchBuilder.Property(b => b.BatchNumber)
            .HasMaxLength(Limits.Batches.BatchNumber)
            .IsRequired();

        batchBuilder.Property(b => b.FishHealthHistory)
            .HasMaxLength(Limits.Batches.FishHealthHistory);

        batchBuilder.Property(b => b.ConfirmedCondition)
            .HasMaxLength(Limits.Batches.ConfirmedCondition);

        batchBuilder.HasIndex(b => b.BatchNumber)
            .IsUnique()
            .IsClustered(false);
        
        var sampleBuilder = modelBuilder.Entity<Sample>();

        sampleBuilder
            .HasMany(e => e.BiomarkerResults)
            .WithOne(e => e.Sample)
            .HasForeignKey(e => e.SampleId)
            .IsRequired()
            .OnDelete(DeleteBehavior.Cascade);

        sampleBuilder.Property(e => e.Id)
            .ValueGeneratedOnAdd();

        sampleBuilder.HasIndex(e => e.SampleCode)
            .IsUnique()
            .IsClustered(false);

        sampleBuilder.Property(e => e.TemperatureInCelsius)
            .HasColumnType("NUMERIC(10,4)");
        sampleBuilder.Property(e => e.OxygenLevelInMg)
            .HasColumnType("NUMERIC(10,4)");
        sampleBuilder.Property(e => e.MortalityRatePercentage)
            .HasColumnType("NUMERIC(10,4)");
        sampleBuilder.Property(e => e.AverageWeightInGrams)
            .HasColumnType("NUMERIC(10,4)");
    }

    private static void ConfigureMLTables(ModelBuilder modelBuilder)
    {
        var fishHealthResults = modelBuilder.Entity<FishHealthResult>();
        fishHealthResults.HasKey(r => r.Id);
        fishHealthResults.HasOne(r => r.Sample)
            .WithMany(s => s.FishHealthResults)
            .IsRequired()
            .HasForeignKey(r => r.SampleId)
            .OnDelete(DeleteBehavior.Cascade);
        fishHealthResults.HasOne(r => r.Model)
            .WithMany()
            .IsRequired()
            .HasForeignKey(r => r.ModelId)
            .OnDelete(DeleteBehavior.Restrict);
        fishHealthResults.Property(r => r.Result)
            .HasConversion(type => (int)type, value => (FishHealthResultType)value);

        fishHealthResults.HasMany(r => r.DraftReports)
            .WithMany()
            .UsingEntity<ReportedFishHealthResult>();
        fishHealthResults.HasMany(r => r.Reports)
            .WithMany()
            .UsingEntity<ReportedFishHealthResult>();

        var reportedFishHealthResults = modelBuilder.Entity<ReportedFishHealthResult>();
        reportedFishHealthResults.HasKey(r => r.Id);
        reportedFishHealthResults.HasOne(r => r.Result)
            .WithMany()
            .IsRequired()
            .HasForeignKey(r => r.MLResultId)
            .OnDelete(DeleteBehavior.Restrict);
        reportedFishHealthResults.HasOne(r => r.DraftReport)
            .WithMany()
            .HasForeignKey(r => r.DraftReportId)
            .OnDelete(DeleteBehavior.Cascade);
        reportedFishHealthResults.HasOne(r => r.Report)
            .WithMany()
            .HasForeignKey(r => r.ReportId)
            .OnDelete(DeleteBehavior.ClientSetNull);

        var mlModels = modelBuilder.Entity<MLModel>();
        mlModels.HasKey(m => m.Id);
        mlModels.Property(r => r.Type)
            .HasConversion(type => (int)type, value => (MLModelType)value);

        var mlBiomarkers = modelBuilder.Entity<MLBiomarker>();
        mlBiomarkers.HasKey(b => b.Id);
        mlBiomarkers.HasOne(b => b.Biomarker)
            .WithMany()
            .IsRequired()
            .HasForeignKey(b => b.BiomarkerId);
        mlBiomarkers.Property(b => b.Name)
            .IsRequired()
            .HasMaxLength(Limits.MLBiomarkers.Name);
        mlBiomarkers.Property(b => b.Min)
            .HasPrecision(18, 6);
        mlBiomarkers.Property(b => b.Max)
            .HasPrecision(18, 6);
        mlBiomarkers.Property(b => b.SortOrder)
            .IsRequired();
    }
}