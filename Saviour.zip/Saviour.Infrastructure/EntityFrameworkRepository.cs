﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Saviour.Domain.Interfaces;

namespace Saviour.Infrastructure;

public class EntityFrameworkRepository<T> : IRepository<T> where T : class
{
    private readonly DbContext _dbContext;

    public EntityFrameworkRepository(DbContext dbContext)
    {
        _dbContext = dbContext;
    }
    
    private DbSet<T> Set() => _dbContext.Set<T>();
    
    public IQueryable<T> GetAll() => Set().AsQueryable();

    public ValueTask<T> GetByIdAsync(object id) => Set().FindAsync(id);
    
    public ValueTask<T> FindByIdOrCreateAsync(object id, Func<Task<T>> create) => FindOrCreateAsync(async () => await GetByIdAsync(id).ConfigureAwait(false), create);
    public async ValueTask<T> FindOrCreateAsync(Func<Task<T>> find, Func<Task<T>> create)
    {
        // Perform a lookup without locks, as worst-case means 2 'find' calls but this is usually quicker overall
        var firstPass = await find().ConfigureAwait(false);
        if (firstPass is not null)
        {
            return firstPass;
        }
        
        var tableName = _dbContext.Model.FindEntityType(typeof(T))!.GetSchemaQualifiedTableName();

        // Exclusively lock the table to ensure that duplicate entities will not be created.
        await _dbContext.Database.ExecuteSqlRawAsync($"SELECT TOP 0 NULL FROM {tableName} WITH (TABLOCKX)").ConfigureAwait(false);

        return await find().ConfigureAwait(false)
                   ?? await InsertAsync(await create()).ConfigureAwait(false);
    }
    
    public IQueryable<T> FindAsync(Expression<Func<T, bool>> predicate) => Set().Where(predicate);

    public async ValueTask<T> InsertAsync(T item)
    {
        var added = await Set().AddAsync(item).ConfigureAwait(false);
        return added.Entity;
    }

    public void Update(T item)
    {
        Set().Update(item);
    }

    public void Delete(T item)
    {
        Set().Remove(item);
    }
}