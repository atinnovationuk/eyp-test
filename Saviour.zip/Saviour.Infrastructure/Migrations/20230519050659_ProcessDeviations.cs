﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ProcessDeviations : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ProcessDeviations",
                table: "Reports",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ProcessDeviations",
                table: "DraftReports",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ProcessDeviations",
                table: "Reports");

            migrationBuilder.DropColumn(
                name: "ProcessDeviations",
                table: "DraftReports");
        }
    }
}
