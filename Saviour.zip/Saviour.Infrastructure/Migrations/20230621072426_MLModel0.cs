﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class MLModel0 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "MLBiomarkers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ModelType = table.Column<int>(type: "int", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    BiomarkerId = table.Column<int>(type: "int", nullable: false),
                    Min = table.Column<decimal>(type: "decimal(18,6)", precision: 18, scale: 6, nullable: false),
                    Max = table.Column<decimal>(type: "decimal(18,6)", precision: 18, scale: 6, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MLBiomarkers", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MLBiomarkers_Biomarkers_BiomarkerId",
                        column: x => x.BiomarkerId,
                        principalTable: "Biomarkers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MLModels",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<int>(type: "int", nullable: false),
                    Version = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MLModels", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "FishHealthResults",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Result = table.Column<int>(type: "int", nullable: false),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SampleId = table.Column<long>(type: "bigint", nullable: false),
                    ModelId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FishHealthResults", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FishHealthResults_MLModels_ModelId",
                        column: x => x.ModelId,
                        principalTable: "MLModels",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_FishHealthResults_Samples_SampleId",
                        column: x => x.SampleId,
                        principalTable: "Samples",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ReportedFishHealthResults",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MLResultId = table.Column<long>(type: "bigint", nullable: false),
                    DraftReportId = table.Column<long>(type: "bigint", nullable: true),
                    ReportId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReportedFishHealthResults", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ReportedFishHealthResults_DraftReports_DraftReportId",
                        column: x => x.DraftReportId,
                        principalTable: "DraftReports",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ReportedFishHealthResults_FishHealthResults_MLResultId",
                        column: x => x.MLResultId,
                        principalTable: "FishHealthResults",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ReportedFishHealthResults_Reports_ReportId",
                        column: x => x.ReportId,
                        principalTable: "Reports",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "MLBiomarkers",
                columns: new[] { "Id", "BiomarkerId", "Max", "Min", "ModelType", "Name" },
                values: new object[,]
                {
                    { 1, 1, 37.5m, 0m, 0, "ALBUMIN" },
                    { 2, 2, 841.7m, 0m, 0, "CHLORIDE__Cl_" },
                    { 3, 3, 444m, 6.39m, 0, "ZINC__Zn_" },
                    { 4, 4, 864m, 0m, 0, "ALT" },
                    { 5, 5, 1463295m, 0.23m, 0, "CK" },
                    { 6, 6, 2767386m, 0.514m, 0, "CK_MB" },
                    { 7, 7, 28242m, 0.91m, 0, "AST" },
                    { 9, 9, 34m, 0m, 0, "LIPASE" },
                    { 10, 10, 45.5m, 0m, 0, "GLUCOSE" },
                    { 11, 11, 24.5m, 0.27m, 0, "CHOLESTEROL" },
                    { 12, 12, 149m, 0m, 0, "IRON__Fe_" },
                    { 13, 13, 26.3m, 0.45m, 0, "LACTATE" },
                    { 16, 16, 314.6m, 0m, 0, "SODIUM__Na_" },
                    { 17, 17, 32.85m, 0m, 0, "POTASSIUM__K_" },
                    { 18, 18, 8.14m, 0m, 0, "CALCIUM__Ca_" }
                });

            migrationBuilder.InsertData(
                table: "MLModels",
                columns: new[] { "Id", "Type", "Version" },
                values: new object[] { 1, 0, 1 });

            migrationBuilder.CreateIndex(
                name: "IX_FishHealthResults_ModelId",
                table: "FishHealthResults",
                column: "ModelId");

            migrationBuilder.CreateIndex(
                name: "IX_FishHealthResults_SampleId",
                table: "FishHealthResults",
                column: "SampleId");

            migrationBuilder.CreateIndex(
                name: "IX_MLBiomarkers_BiomarkerId",
                table: "MLBiomarkers",
                column: "BiomarkerId");

            migrationBuilder.CreateIndex(
                name: "IX_ReportedFishHealthResults_DraftReportId",
                table: "ReportedFishHealthResults",
                column: "DraftReportId");

            migrationBuilder.CreateIndex(
                name: "IX_ReportedFishHealthResults_MLResultId",
                table: "ReportedFishHealthResults",
                column: "MLResultId");

            migrationBuilder.CreateIndex(
                name: "IX_ReportedFishHealthResults_ReportId",
                table: "ReportedFishHealthResults",
                column: "ReportId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "MLBiomarkers");

            migrationBuilder.DropTable(
                name: "ReportedFishHealthResults");

            migrationBuilder.DropTable(
                name: "FishHealthResults");

            migrationBuilder.DropTable(
                name: "MLModels");
        }
    }
}
