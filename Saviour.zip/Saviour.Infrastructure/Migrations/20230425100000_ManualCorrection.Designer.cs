﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Saviour.Infrastructure.Migrations;

[DbContext(typeof(SaviourContext))]
[Migration("20230425100000_ManualCorrection")]
public partial class ManualCorrection 
{
    protected override void BuildTargetModel(ModelBuilder modelBuilder)
    {
        
#pragma warning disable 612, 618
            modelBuilder
                .HasAnnotation("ProductVersion", "7.0.5")
                .HasAnnotation("Relational:MaxIdentifierLength", 128);

            SqlServerModelBuilderExtensions.UseIdentityColumns(modelBuilder);

            modelBuilder.Entity("HatcherySample", b =>
                {
                    b.Property<int>("HatcheriesId")
                        .HasColumnType("int");

                    b.Property<long>("SamplesId")
                        .HasColumnType("bigint");

                    b.HasKey("HatcheriesId", "SamplesId");

                    b.HasIndex("SamplesId");

                    b.ToTable("HatcherySample");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Analysis", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<string>("MethodName")
                        .IsRequired()
                        .HasMaxLength(1000)
                        .HasColumnType("nvarchar(1000)");

                    b.HasKey("Id");

                    b.ToTable("Analyses");

                    b.HasData(
                        new
                        {
                            Id = 1,
                            MethodName = "GENERAL HOMEOSTASIS"
                        },
                        new
                        {
                            Id = 2,
                            MethodName = "MUSCLE/LIVER TISSUE DAMAGE"
                        },
                        new
                        {
                            Id = 3,
                            MethodName = "LIVER/GENERAL STRESS/PANCREAS"
                        },
                        new
                        {
                            Id = 4,
                            MethodName = "LIVER FUNCTION"
                        },
                        new
                        {
                            Id = 5,
                            MethodName = "GILL FUNCTION"
                        },
                        new
                        {
                            Id = 6,
                            MethodName = "GILL/LIVER FUNCTION"
                        });
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Batch", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<long>("Id"));

                    b.Property<string>("BatchNumber")
                        .IsRequired()
                        .HasMaxLength(40)
                        .HasColumnType("nvarchar(40)");

                    b.Property<DateTime>("DateAnalysed")
                        .HasColumnType("datetime2");

                    b.Property<DateTime>("DateCollected")
                        .HasColumnType("datetime2");

                    b.Property<string>("SiteId")
                        .IsRequired()
                        .HasColumnType("nvarchar(20)");

                    b.HasKey("Id");

                    b.HasIndex("BatchNumber")
                        .IsUnique();

                    SqlServerIndexBuilderExtensions.IsClustered(b.HasIndex("BatchNumber"), false);

                    b.HasIndex("SiteId");

                    b.ToTable("Batches");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Biomarker", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasMaxLength(1000)
                        .HasColumnType("nvarchar(1000)");

                    b.HasKey("Id");

                    b.HasIndex("Name")
                        .IsUnique();

                    SqlServerIndexBuilderExtensions.IsClustered(b.HasIndex("Name"), false);

                    b.ToTable("Biomarkers");

                    b.HasData(
                        new
                        {
                            Id = 1,
                            Name = "ALBUMIN"
                        },
                        new
                        {
                            Id = 19,
                            Name = "ALB2-G"
                        },
                        new
                        {
                            Id = 2,
                            Name = "CHLORIDE"
                        },
                        new
                        {
                            Id = 25,
                            Name = "ISE CL"
                        },
                        new
                        {
                            Id = 3,
                            Name = "ZINC"
                        },
                        new
                        {
                            Id = 42,
                            Name = "ZINC 1:5"
                        },
                        new
                        {
                            Id = 4,
                            Name = "ALT"
                        },
                        new
                        {
                            Id = 20,
                            Name = "ALTP"
                        },
                        new
                        {
                            Id = 5,
                            Name = "CK"
                        },
                        new
                        {
                            Id = 40,
                            Name = "CK2 1:50"
                        },
                        new
                        {
                            Id = 6,
                            Name = "CM MB"
                        },
                        new
                        {
                            Id = 41,
                            Name = "CKMB2 1:50"
                        },
                        new
                        {
                            Id = 7,
                            Name = "AST"
                        },
                        new
                        {
                            Id = 39,
                            Name = "ASTP 1:10"
                        },
                        new
                        {
                            Id = 8,
                            Name = "LDH"
                        },
                        new
                        {
                            Id = 29,
                            Name = "LDHI2"
                        },
                        new
                        {
                            Id = 9,
                            Name = "LIPASE"
                        },
                        new
                        {
                            Id = 30,
                            Name = "LIP"
                        },
                        new
                        {
                            Id = 10,
                            Name = "GLUCOSE"
                        },
                        new
                        {
                            Id = 23,
                            Name = "GLUC3"
                        },
                        new
                        {
                            Id = 11,
                            Name = "CHOLESTEROL"
                        },
                        new
                        {
                            Id = 22,
                            Name = "CHOL2-I"
                        },
                        new
                        {
                            Id = 12,
                            Name = "IRON"
                        },
                        new
                        {
                            Id = 24,
                            Name = "IRON2"
                        },
                        new
                        {
                            Id = 13,
                            Name = "LACTATE"
                        },
                        new
                        {
                            Id = 28,
                            Name = "LACT2P"
                        },
                        new
                        {
                            Id = 14,
                            Name = "PHOSPHATE"
                        },
                        new
                        {
                            Id = 31,
                            Name = "PHOS2"
                        },
                        new
                        {
                            Id = 15,
                            Name = "MAGNESIUM"
                        },
                        new
                        {
                            Id = 36,
                            Name = "MG2"
                        },
                        new
                        {
                            Id = 16,
                            Name = "SODIUM"
                        },
                        new
                        {
                            Id = 27,
                            Name = "ISE NA"
                        },
                        new
                        {
                            Id = 17,
                            Name = "POTASSIUM"
                        },
                        new
                        {
                            Id = 26,
                            Name = "ISE K"
                        },
                        new
                        {
                            Id = 18,
                            Name = "CALCIUM"
                        },
                        new
                        {
                            Id = 21,
                            Name = "CA2"
                        },
                        new
                        {
                            Id = 32,
                            Name = "SI2"
                        },
                        new
                        {
                            Id = 33,
                            Name = "SI2 L"
                        },
                        new
                        {
                            Id = 34,
                            Name = "SI2 H"
                        },
                        new
                        {
                            Id = 35,
                            Name = "SI2 I"
                        },
                        new
                        {
                            Id = 37,
                            Name = "ALP2"
                        },
                        new
                        {
                            Id = 38,
                            Name = "AMYL2"
                        },
                        new
                        {
                            Id = 43,
                            Name = "UIBC-I"
                        });
                });

            modelBuilder.Entity("Saviour.Domain.Entities.BiomarkerRange", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<int>("AnalysisId")
                        .HasColumnType("int");

                    b.Property<int>("BiomarkerId")
                        .HasColumnType("int");

                    b.Property<string>("CountryCode")
                        .HasColumnType("nvarchar(20)");

                    b.Property<double>("HighAmber")
                        .HasColumnType("float");

                    b.Property<double>("LowAmber")
                        .HasColumnType("float");

                    b.Property<double>("LowRed")
                        .HasColumnType("float");

                    b.Property<double>("Max")
                        .HasColumnType("float");

                    b.Property<double>("Min")
                        .HasColumnType("float");

                    b.Property<double>("Reference")
                        .HasColumnType("float");

                    b.HasKey("Id");

                    b.HasIndex("AnalysisId");

                    b.HasIndex("BiomarkerId");

                    b.HasIndex("CountryCode");

                    b.ToTable("BiomarkerRanges");

                    b.HasData(
                        new
                        {
                            Id = 1,
                            AnalysisId = 1,
                            BiomarkerId = 1,
                            HighAmber = 23.100000000000001,
                            LowAmber = 17.199999999999999,
                            LowRed = 15.199999999999999,
                            Max = 30.0,
                            Min = 0.0,
                            Reference = 21.100000000000001
                        },
                        new
                        {
                            Id = 2,
                            AnalysisId = 1,
                            BiomarkerId = 2,
                            HighAmber = 139.59999999999999,
                            LowAmber = 131.5,
                            LowRed = 128.80000000000001,
                            Max = 250.0,
                            Min = 50.0,
                            Reference = 136.59999999999999
                        },
                        new
                        {
                            Id = 3,
                            AnalysisId = 1,
                            BiomarkerId = 3,
                            HighAmber = 406.60000000000002,
                            LowAmber = 244.09999999999999,
                            LowRed = 189.90000000000001,
                            Max = 500.0,
                            Min = 0.0,
                            Reference = 352.39999999999998
                        },
                        new
                        {
                            Id = 4,
                            AnalysisId = 2,
                            BiomarkerId = 4,
                            HighAmber = 12.0,
                            LowAmber = 4.0,
                            LowRed = 2.0,
                            Max = 500.0,
                            Min = 0.0,
                            Reference = 10.0
                        },
                        new
                        {
                            Id = 5,
                            AnalysisId = 2,
                            BiomarkerId = 5,
                            HighAmber = 22176.0,
                            LowAmber = 3529.0,
                            LowRed = 2686.0,
                            Max = 900000.0,
                            Min = 0.0,
                            Reference = 15960.0
                        },
                        new
                        {
                            Id = 6,
                            AnalysisId = 2,
                            BiomarkerId = 6,
                            HighAmber = 37226.0,
                            LowAmber = 6073.0,
                            LowRed = 4311.0,
                            Max = 1000000.0,
                            Min = 0.0,
                            Reference = 26842.0
                        },
                        new
                        {
                            Id = 7,
                            AnalysisId = 3,
                            BiomarkerId = 7,
                            HighAmber = 1136.0,
                            LowAmber = 354.19999999999999,
                            LowRed = 93.599999999999994,
                            Max = 50000.0,
                            Min = 0.0,
                            Reference = 875.0
                        },
                        new
                        {
                            Id = 8,
                            AnalysisId = 3,
                            BiomarkerId = 8,
                            HighAmber = 1400.0,
                            LowAmber = 220.5,
                            LowRed = 172.90000000000001,
                            Max = 50000.0,
                            Min = 0.0,
                            Reference = 1007.0
                        },
                        new
                        {
                            Id = 9,
                            AnalysisId = 3,
                            BiomarkerId = 9,
                            HighAmber = 7.2000000000000002,
                            LowAmber = 5.7000000000000002,
                            LowRed = 5.2000000000000002,
                            Max = 50.0,
                            Min = 0.0,
                            Reference = 6.7000000000000002
                        },
                        new
                        {
                            Id = 10,
                            AnalysisId = 4,
                            BiomarkerId = 10,
                            HighAmber = 6.1900000000000004,
                            LowAmber = 4.2999999999999998,
                            LowRed = 3.6800000000000002,
                            Max = 20.0,
                            Min = 0.0,
                            Reference = 5.5700000000000003
                        },
                        new
                        {
                            Id = 11,
                            AnalysisId = 4,
                            BiomarkerId = 11,
                            HighAmber = 11.83,
                            LowAmber = 7.2000000000000002,
                            LowRed = 5.6600000000000001,
                            Max = 20.0,
                            Min = 0.0,
                            Reference = 10.289999999999999
                        },
                        new
                        {
                            Id = 12,
                            AnalysisId = 4,
                            BiomarkerId = 12,
                            HighAmber = 26.73,
                            LowAmber = 12.699999999999999,
                            LowRed = 8.0299999999999994,
                            Max = 50.0,
                            Min = 0.0,
                            Reference = 22.050000000000001
                        },
                        new
                        {
                            Id = 13,
                            AnalysisId = 5,
                            BiomarkerId = 13,
                            HighAmber = 5.5499999999999998,
                            LowAmber = 2.8700000000000001,
                            LowRed = 1.97,
                            Max = 50.0,
                            Min = 0.0,
                            Reference = 4.6600000000000001
                        },
                        new
                        {
                            Id = 14,
                            AnalysisId = 5,
                            BiomarkerId = 14,
                            HighAmber = 6.0099999999999998,
                            LowAmber = 4.3300000000000001,
                            LowRed = 3.7599999999999998,
                            Max = 20.0,
                            Min = 0.0,
                            Reference = 5.4500000000000002
                        },
                        new
                        {
                            Id = 15,
                            AnalysisId = 5,
                            BiomarkerId = 15,
                            HighAmber = 1.6899999999999999,
                            LowAmber = 1.04,
                            LowRed = 0.81999999999999995,
                            Max = 10.0,
                            Min = 0.0,
                            Reference = 1.47
                        },
                        new
                        {
                            Id = 16,
                            AnalysisId = 6,
                            BiomarkerId = 16,
                            HighAmber = 171.80000000000001,
                            LowAmber = 163.80000000000001,
                            LowRed = 161.09999999999999,
                            Max = 300.0,
                            Min = 0.0,
                            Reference = 169.09999999999999
                        },
                        new
                        {
                            Id = 17,
                            AnalysisId = 6,
                            BiomarkerId = 17,
                            HighAmber = 1.1000000000000001,
                            LowAmber = 0.59999999999999998,
                            LowRed = 0.40000000000000002,
                            Max = 20.0,
                            Min = 0.0,
                            Reference = 0.90000000000000002
                        },
                        new
                        {
                            Id = 18,
                            AnalysisId = 6,
                            BiomarkerId = 18,
                            HighAmber = 3.6000000000000001,
                            LowAmber = 3.1000000000000001,
                            LowRed = 2.8999999999999999,
                            Max = 20.0,
                            Min = 0.0,
                            Reference = 3.3999999999999999
                        });
                });

            modelBuilder.Entity("Saviour.Domain.Entities.BiomarkerResult", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<long>("Id"));

                    b.Property<int>("BioMarkerId")
                        .HasColumnType("int");

                    b.Property<decimal>("Result")
                        .HasPrecision(18, 6)
                        .HasColumnType("decimal(18,6)");

                    b.Property<long>("SampleId")
                        .HasColumnType("bigint");

                    b.HasKey("Id");

                    b.HasIndex("BioMarkerId");

                    b.HasIndex("SampleId");

                    b.ToTable("BiomarkerResults");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Company", b =>
                {
                    b.Property<string>("Id")
                        .HasMaxLength(158)
                        .HasColumnType("nvarchar(158)");

                    b.Property<string>("CompanyName")
                        .IsRequired()
                        .HasMaxLength(126)
                        .HasColumnType("nvarchar(126)");

                    b.HasKey("Id");

                    b.ToTable("Companies");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Country", b =>
                {
                    b.Property<string>("Code")
                        .HasMaxLength(20)
                        .HasColumnType("nvarchar(20)");

                    b.HasKey("Code");

                    b.ToTable("Countries");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Employee", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<string>("CompanyId")
                        .IsRequired()
                        .HasColumnType("nvarchar(158)");

                    b.Property<string>("LoginIdentity")
                        .IsRequired()
                        .HasMaxLength(256)
                        .HasColumnType("nvarchar(256)");

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasMaxLength(128)
                        .HasColumnType("nvarchar(128)");

                    b.HasKey("Id");

                    b.HasIndex("CompanyId");

                    b.HasIndex("LoginIdentity");

                    SqlServerIndexBuilderExtensions.IsClustered(b.HasIndex("LoginIdentity"), false);

                    b.ToTable("Employees");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Hatchery", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<string>("HatcheryCode")
                        .IsRequired()
                        .HasMaxLength(160)
                        .HasColumnType("nvarchar(160)");

                    b.HasKey("Id");

                    b.HasIndex("HatcheryCode")
                        .IsUnique();

                    SqlServerIndexBuilderExtensions.IsClustered(b.HasIndex("HatcheryCode"), false);

                    b.ToTable("Hatcheries");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Report", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<long>("Id"));

                    b.Property<int>("CreatedById")
                        .HasColumnType("int");

                    b.Property<DateTime>("CreatedOn")
                        .HasColumnType("datetime2");

                    b.Property<string>("Observations")
                        .IsRequired()
                        .HasColumnType("nvarchar(max)");

                    b.Property<int?>("ReviewedById")
                        .HasColumnType("int");

                    b.Property<string>("SiteId")
                        .IsRequired()
                        .HasColumnType("nvarchar(20)");

                    b.HasKey("Id");

                    b.HasIndex("CreatedById");

                    b.HasIndex("ReviewedById");

                    b.HasIndex("SiteId");

                    b.ToTable("Reports");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.ReportedBatch", b =>
                {
                    b.Property<long>("BatchId")
                        .HasColumnType("bigint");

                    b.Property<long>("ReportId")
                        .HasColumnType("bigint");

                    b.HasKey("BatchId", "ReportId");

                    b.HasIndex("ReportId");

                    b.ToTable("ReportedBatches");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Sample", b =>
                {
                    b.Property<long>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("bigint");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<long>("Id"));

                    b.Property<decimal>("AverageWeightInGrams")
                        .HasColumnType("NUMERIC(10,4)");

                    b.Property<long>("BatchId")
                        .HasColumnType("bigint");

                    b.Property<string>("FishNumber")
                        .IsRequired()
                        .HasMaxLength(158)
                        .HasColumnType("nvarchar(158)");

                    b.Property<string>("Instrument")
                        .IsRequired()
                        .HasMaxLength(400)
                        .HasColumnType("nvarchar(400)");

                    b.Property<decimal>("MortalityRatePercentage")
                        .HasColumnType("NUMERIC(10,4)");

                    b.Property<decimal?>("OxygenLevelInMg")
                        .HasColumnType("NUMERIC(10,4)");

                    b.Property<string>("Pen")
                        .IsRequired()
                        .HasMaxLength(10)
                        .HasColumnType("nvarchar(10)");

                    b.Property<string>("SampleCode")
                        .IsRequired()
                        .HasMaxLength(160)
                        .HasColumnType("nvarchar(160)");

                    b.Property<string>("Species")
                        .IsRequired()
                        .HasMaxLength(158)
                        .HasColumnType("nvarchar(158)");

                    b.Property<string>("Strain")
                        .HasMaxLength(158)
                        .HasColumnType("nvarchar(158)");

                    b.Property<decimal>("TemperatureInCelsius")
                        .HasColumnType("NUMERIC(10,4)");

                    b.Property<int>("WaterType")
                        .HasColumnType("int");

                    b.HasKey("Id");

                    b.HasIndex("BatchId");

                    b.HasIndex("SampleCode")
                        .IsUnique();

                    SqlServerIndexBuilderExtensions.IsClustered(b.HasIndex("SampleCode"), false);

                    b.ToTable("Samples");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Site", b =>
                {
                    b.Property<string>("Id")
                        .HasMaxLength(20)
                        .HasColumnType("nvarchar(20)");

                    b.Property<string>("CompanyId")
                        .IsRequired()
                        .HasColumnType("nvarchar(158)");

                    b.Property<string>("CountryCode")
                        .IsRequired()
                        .HasColumnType("nvarchar(20)");

                    b.Property<string>("SiteName")
                        .IsRequired()
                        .HasMaxLength(158)
                        .HasColumnType("nvarchar(158)");

                    b.HasKey("Id");

                    b.HasIndex("CompanyId");

                    b.HasIndex("CountryCode");

                    b.ToTable("Sites");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.User", b =>
                {
                    b.Property<int>("Id")
                        .ValueGeneratedOnAdd()
                        .HasColumnType("int");

                    SqlServerPropertyBuilderExtensions.UseIdentityColumn(b.Property<int>("Id"));

                    b.Property<string>("AzureId")
                        .IsRequired()
                        .HasMaxLength(64)
                        .HasColumnType("nvarchar(64)");

                    b.Property<string>("Name")
                        .IsRequired()
                        .HasMaxLength(128)
                        .HasColumnType("nvarchar(128)");

                    b.HasKey("Id");

                    b.HasIndex("AzureId")
                        .IsUnique();

                    SqlServerIndexBuilderExtensions.IsClustered(b.HasIndex("AzureId"), false);

                    b.ToTable("Users");
                });

            modelBuilder.Entity("HatcherySample", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.Hatchery", null)
                        .WithMany()
                        .HasForeignKey("HatcheriesId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.HasOne("Saviour.Domain.Entities.Sample", null)
                        .WithMany()
                        .HasForeignKey("SamplesId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Batch", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.Site", "Site")
                        .WithMany("Batches")
                        .HasForeignKey("SiteId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("Site");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.BiomarkerRange", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.Analysis", "Analysis")
                        .WithMany("BiomarkerRanges")
                        .HasForeignKey("AnalysisId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.HasOne("Saviour.Domain.Entities.Biomarker", "Biomarker")
                        .WithMany()
                        .HasForeignKey("BiomarkerId")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.HasOne("Saviour.Domain.Entities.Country", "Country")
                        .WithMany()
                        .HasForeignKey("CountryCode");

                    b.Navigation("Analysis");

                    b.Navigation("Biomarker");

                    b.Navigation("Country");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.BiomarkerResult", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.Biomarker", "Biomarker")
                        .WithMany()
                        .HasForeignKey("BioMarkerId")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.HasOne("Saviour.Domain.Entities.Sample", "Sample")
                        .WithMany("BiomarkerResults")
                        .HasForeignKey("SampleId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("Biomarker");

                    b.Navigation("Sample");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Employee", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.Company", "Company")
                        .WithMany()
                        .HasForeignKey("CompanyId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("Company");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Report", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.User", "CreatedBy")
                        .WithMany()
                        .HasForeignKey("CreatedById")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.HasOne("Saviour.Domain.Entities.User", "ReviewedBy")
                        .WithMany()
                        .HasForeignKey("ReviewedById")
                        .OnDelete(DeleteBehavior.Restrict);

                    b.HasOne("Saviour.Domain.Entities.Site", "Site")
                        .WithMany()
                        .HasForeignKey("SiteId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("CreatedBy");

                    b.Navigation("ReviewedBy");

                    b.Navigation("Site");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.ReportedBatch", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.Batch", null)
                        .WithMany()
                        .HasForeignKey("BatchId")
                        .OnDelete(DeleteBehavior.ClientCascade)
                        .IsRequired();

                    b.HasOne("Saviour.Domain.Entities.Report", null)
                        .WithMany()
                        .HasForeignKey("ReportId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Sample", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.Batch", "Batch")
                        .WithMany("Samples")
                        .HasForeignKey("BatchId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.Navigation("Batch");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Site", b =>
                {
                    b.HasOne("Saviour.Domain.Entities.Company", "Company")
                        .WithMany("Sites")
                        .HasForeignKey("CompanyId")
                        .OnDelete(DeleteBehavior.Cascade)
                        .IsRequired();

                    b.HasOne("Saviour.Domain.Entities.Country", "Country")
                        .WithMany()
                        .HasForeignKey("CountryCode")
                        .OnDelete(DeleteBehavior.Restrict)
                        .IsRequired();

                    b.Navigation("Company");

                    b.Navigation("Country");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Analysis", b =>
                {
                    b.Navigation("BiomarkerRanges");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Batch", b =>
                {
                    b.Navigation("Samples");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Company", b =>
                {
                    b.Navigation("Sites");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Sample", b =>
                {
                    b.Navigation("BiomarkerResults");
                });

            modelBuilder.Entity("Saviour.Domain.Entities.Site", b =>
                {
                    b.Navigation("Batches");
                });
#pragma warning restore 612, 618
    }
}