﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ReportDeletion : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReportedBatches_Batches_BatchId",
                table: "ReportedBatches");

            migrationBuilder.DropForeignKey(
                name: "FK_ReportedBatches_Reports_ReportId",
                table: "ReportedBatches");

            migrationBuilder.AddForeignKey(
                name: "FK_ReportedBatches_Batches_BatchId",
                table: "ReportedBatches",
                column: "BatchId",
                principalTable: "Batches",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_ReportedBatches_Reports_ReportId",
                table: "ReportedBatches",
                column: "ReportId",
                principalTable: "Reports",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ReportedBatches_Batches_BatchId",
                table: "ReportedBatches");

            migrationBuilder.DropForeignKey(
                name: "FK_ReportedBatches_Reports_ReportId",
                table: "ReportedBatches");

            migrationBuilder.AddForeignKey(
                name: "FK_ReportedBatches_Batches_BatchId",
                table: "ReportedBatches",
                column: "BatchId",
                principalTable: "Batches",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ReportedBatches_Reports_ReportId",
                table: "ReportedBatches",
                column: "ReportId",
                principalTable: "Reports",
                principalColumn: "Id");
        }
    }
}
