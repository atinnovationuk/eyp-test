﻿using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Saviour.Infrastructure.Migrations;

public partial class ManualCorrection : Migration 
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.InsertData(
            table: "Biomarkers",
            columns: new[] { "Id", "Name" },
            values: new object[,]
            {
                { 19, "ALB2-G" },
                { 20, "ALTP" },
                { 21, "CA2" },
                { 22, "CHOL2-I" },
                { 23, "GLUC3" },
                { 24, "IRON2" },
                { 25, "ISE CL" },
                { 26, "ISE K" },
                { 27, "ISE NA" },
                { 28, "LACT2P" },
                { 29, "LDHI2" },
                { 30, "LIP" },
                { 31, "PHOS2" },
                { 32, "SI2" },
                { 33, "SI2 L" },
                { 34, "SI2 H" },
                { 35, "SI2 I" },
                { 36, "MG2" },
                { 37, "ALP2" },
                { 38, "AMYL2" },
                { 39, "ASTP 1:10" },
                { 40, "CK2 1:50" },
                { 41, "CKMB2 1:50" },
                { 42, "ZINC 1:5" },
                { 43, "UIBC-I" }
            });
    }
}