﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class BiomarkerLink : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ParentId",
                table: "Biomarkers",
                type: "int",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 1,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 2,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 3,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 4,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 5,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 6,
                columns: new[] { "Name", "ParentId" },
                values: new object[] { "CK MB", null });

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 7,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 8,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 9,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 10,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 11,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 12,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 13,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 14,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 15,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 16,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 17,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 18,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 19,
                column: "ParentId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 20,
                column: "ParentId",
                value: 4);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 21,
                column: "ParentId",
                value: 18);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 22,
                column: "ParentId",
                value: 11);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 23,
                column: "ParentId",
                value: 10);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 24,
                column: "ParentId",
                value: 12);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 25,
                column: "ParentId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 26,
                column: "ParentId",
                value: 17);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 27,
                column: "ParentId",
                value: 16);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 28,
                column: "ParentId",
                value: 13);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 29,
                column: "ParentId",
                value: 8);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 30,
                column: "ParentId",
                value: 9);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 31,
                column: "ParentId",
                value: 14);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 32,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 33,
                column: "ParentId",
                value: 44);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 34,
                column: "ParentId",
                value: 45);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 35,
                column: "ParentId",
                value: 46);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 36,
                column: "ParentId",
                value: 15);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 37,
                column: "ParentId",
                value: null);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 38,
                column: "ParentId",
                value: 47);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 39,
                column: "ParentId",
                value: 7);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 40,
                column: "ParentId",
                value: 5);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 41,
                column: "ParentId",
                value: 6);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 42,
                column: "ParentId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 43,
                column: "ParentId",
                value: 48);

            migrationBuilder.InsertData(
                table: "Biomarkers",
                columns: new[] { "Id", "Name", "ParentId" },
                values: new object[,]
                {
                    { 44, "SI2-L", null },
                    { 45, "SI2-H", null },
                    { 46, "SI2-I", null },
                    { 47, "AMY", null },
                    { 48, "UIBC", null }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Biomarkers_ParentId",
                table: "Biomarkers",
                column: "ParentId");

            migrationBuilder.AddForeignKey(
                name: "FK_Biomarkers_Biomarkers_ParentId",
                table: "Biomarkers",
                column: "ParentId",
                principalTable: "Biomarkers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Biomarkers_Biomarkers_ParentId",
                table: "Biomarkers");

            migrationBuilder.DropIndex(
                name: "IX_Biomarkers_ParentId",
                table: "Biomarkers");

            migrationBuilder.DeleteData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 44);

            migrationBuilder.DeleteData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 45);

            migrationBuilder.DeleteData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 46);

            migrationBuilder.DeleteData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 47);

            migrationBuilder.DeleteData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 48);

            migrationBuilder.DropColumn(
                name: "ParentId",
                table: "Biomarkers");

            migrationBuilder.UpdateData(
                table: "Biomarkers",
                keyColumn: "Id",
                keyValue: 6,
                column: "Name",
                value: "CM MB");
        }
    }
}
