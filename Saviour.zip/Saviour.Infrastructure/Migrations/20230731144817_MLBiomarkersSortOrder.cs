﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class MLBiomarkersSortOrder : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 16);

            migrationBuilder.DeleteData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 17);

            migrationBuilder.DeleteData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 18);

            migrationBuilder.AddColumn<short>(
                name: "SortOrder",
                table: "MLBiomarkers",
                type: "smallint",
                nullable: false,
                defaultValue: (short)0);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 1,
                column: "SortOrder",
                value: (short)1);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 2,
                column: "SortOrder",
                value: (short)9);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 3,
                column: "SortOrder",
                value: (short)7);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 4,
                column: "SortOrder",
                value: (short)2);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 5,
                column: "SortOrder",
                value: (short)5);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 6,
                column: "SortOrder",
                value: (short)6);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 7,
                column: "SortOrder",
                value: (short)3);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "BiomarkerId", "Max", "Name", "SortOrder" },
                values: new object[] { 10, 45.5m, "GLUCOSE", (short)8 });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 10,
                columns: new[] { "BiomarkerId", "Max", "Min", "Name", "SortOrder" },
                values: new object[] { 11, 24.5m, 0.27m, "CHOLESTEROL", (short)11 });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "BiomarkerId", "Max", "Min", "Name", "SortOrder" },
                values: new object[] { 12, 149m, 0m, "IRON__Fe_", (short)10 });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 12,
                columns: new[] { "BiomarkerId", "Max", "Min", "Name", "SortOrder" },
                values: new object[] { 13, 26.3m, 0.45m, "LACTATE", (short)14 });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 13,
                columns: new[] { "BiomarkerId", "Max", "Min", "Name", "SortOrder" },
                values: new object[] { 16, 314.6m, 0m, "SODIUM__Na_", (short)12 });

            migrationBuilder.InsertData(
                table: "MLBiomarkers",
                columns: new[] { "Id", "BiomarkerId", "Max", "Min", "ModelType", "Name", "SortOrder" },
                values: new object[,]
                {
                    { 8, 9, 34m, 0m, 0, "LIPASE", (short)15 },
                    { 14, 17, 32.85m, 0m, 0, "POTASSIUM__K_", (short)13 },
                    { 15, 18, 8.14m, 0m, 0, "CALCIUM__Ca_", (short)4 }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 8);

            migrationBuilder.DeleteData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 14);

            migrationBuilder.DeleteData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 15);

            migrationBuilder.DropColumn(
                name: "SortOrder",
                table: "MLBiomarkers");

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "BiomarkerId", "Max", "Name" },
                values: new object[] { 9, 34m, "LIPASE" });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 10,
                columns: new[] { "BiomarkerId", "Max", "Min", "Name" },
                values: new object[] { 10, 45.5m, 0m, "GLUCOSE" });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "BiomarkerId", "Max", "Min", "Name" },
                values: new object[] { 11, 24.5m, 0.27m, "CHOLESTEROL" });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 12,
                columns: new[] { "BiomarkerId", "Max", "Min", "Name" },
                values: new object[] { 12, 149m, 0m, "IRON__Fe_" });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 13,
                columns: new[] { "BiomarkerId", "Max", "Min", "Name" },
                values: new object[] { 13, 26.3m, 0.45m, "LACTATE" });

            migrationBuilder.InsertData(
                table: "MLBiomarkers",
                columns: new[] { "Id", "BiomarkerId", "Max", "Min", "ModelType", "Name" },
                values: new object[,]
                {
                    { 16, 16, 314.6m, 0m, 0, "SODIUM__Na_" },
                    { 17, 17, 32.85m, 0m, 0, "POTASSIUM__K_" },
                    { 18, 18, 8.14m, 0m, 0, "CALCIUM__Ca_" }
                });
        }
    }
}
