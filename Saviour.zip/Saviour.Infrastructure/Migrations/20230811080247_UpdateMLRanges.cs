﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class UpdateMLRanges : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Max", "Min" },
                values: new object[] { 33.8m, 0.13m });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Max", "Min" },
                values: new object[] { 289.5m, 17m });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 3,
                column: "Min",
                value: 7.95m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 4,
                column: "Min",
                value: 0.1m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 7,
                column: "Min",
                value: 27m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "Max", "Min" },
                values: new object[] { 15m, 0.00822m });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 10,
                column: "Max",
                value: 18.1m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "Max", "Min" },
                values: new object[] { 56.3m, 0.04m });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 12,
                column: "Min",
                value: 0.49m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 13,
                column: "Min",
                value: 14.5m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 14,
                columns: new[] { "Max", "Min" },
                values: new object[] { 29.35m, 0.29m });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 1,
                columns: new[] { "Max", "Min" },
                values: new object[] { 37.5m, 0m });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 2,
                columns: new[] { "Max", "Min" },
                values: new object[] { 841.7m, 0m });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 3,
                column: "Min",
                value: 6.39m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 4,
                column: "Min",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 7,
                column: "Min",
                value: 0.91m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 9,
                columns: new[] { "Max", "Min" },
                values: new object[] { 45.5m, 0m });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 10,
                column: "Max",
                value: 24.5m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 11,
                columns: new[] { "Max", "Min" },
                values: new object[] { 149m, 0m });

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 12,
                column: "Min",
                value: 0.45m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 13,
                column: "Min",
                value: 0m);

            migrationBuilder.UpdateData(
                table: "MLBiomarkers",
                keyColumn: "Id",
                keyValue: 14,
                columns: new[] { "Max", "Min" },
                values: new object[] { 32.85m, 0m });
        }
    }
}
