﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ReportDraftSplit : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<int>(
                name: "ReviewedById",
                table: "Reports",
                type: "int",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "ApprovedOn",
                table: "Reports",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.CreateTable(
                name: "DraftReports",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    CreatedById = table.Column<int>(type: "int", nullable: false),
                    Observations = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SiteId = table.Column<string>(type: "nvarchar(20)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DraftReports", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DraftReports_Sites_SiteId",
                        column: x => x.SiteId,
                        principalTable: "Sites",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DraftReports_Users_CreatedById",
                        column: x => x.CreatedById,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "DraftReportAnalyses",
                columns: table => new
                {
                    DraftReportId = table.Column<long>(type: "bigint", nullable: false),
                    AnalysisId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DraftReportAnalyses", x => new { x.AnalysisId, x.DraftReportId });
                    table.ForeignKey(
                        name: "FK_DraftReportAnalyses_Analyses_AnalysisId",
                        column: x => x.AnalysisId,
                        principalTable: "Analyses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_DraftReportAnalyses_DraftReports_DraftReportId",
                        column: x => x.DraftReportId,
                        principalTable: "DraftReports",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "DraftReportedBatches",
                columns: table => new
                {
                    DraftReportId = table.Column<long>(type: "bigint", nullable: false),
                    BatchId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DraftReportedBatches", x => new { x.BatchId, x.DraftReportId });
                    table.ForeignKey(
                        name: "FK_DraftReportedBatches_Batches_BatchId",
                        column: x => x.BatchId,
                        principalTable: "Batches",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_DraftReportedBatches_DraftReports_DraftReportId",
                        column: x => x.DraftReportId,
                        principalTable: "DraftReports",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DraftReportAnalyses_DraftReportId",
                table: "DraftReportAnalyses",
                column: "DraftReportId");

            migrationBuilder.CreateIndex(
                name: "IX_DraftReportedBatches_DraftReportId",
                table: "DraftReportedBatches",
                column: "DraftReportId");

            migrationBuilder.CreateIndex(
                name: "IX_DraftReports_CreatedById",
                table: "DraftReports",
                column: "CreatedById");

            migrationBuilder.CreateIndex(
                name: "IX_DraftReports_SiteId",
                table: "DraftReports",
                column: "SiteId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DraftReportAnalyses");

            migrationBuilder.DropTable(
                name: "DraftReportedBatches");

            migrationBuilder.DropTable(
                name: "DraftReports");

            migrationBuilder.DropColumn(
                name: "ApprovedOn",
                table: "Reports");

            migrationBuilder.AlterColumn<int>(
                name: "ReviewedById",
                table: "Reports",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");
        }
    }
}
