﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class Initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Analyses",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MethodName = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Analyses", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Biomarkers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(1000)", maxLength: 1000, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Biomarkers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Companies",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(158)", maxLength: 158, nullable: false),
                    CompanyName = table.Column<string>(type: "nvarchar(126)", maxLength: 126, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Companies", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Countries",
                columns: table => new
                {
                    Code = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Countries", x => x.Code);
                });

            migrationBuilder.CreateTable(
                name: "Hatcheries",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HatcheryCode = table.Column<string>(type: "nvarchar(160)", maxLength: 160, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Hatcheries", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Employees",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(128)", maxLength: 128, nullable: false),
                    LoginIdentity = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: false),
                    CompanyId = table.Column<string>(type: "nvarchar(158)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Employees_Companies_CompanyId",
                        column: x => x.CompanyId,
                        principalTable: "Companies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "BiomarkerRanges",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnalysisId = table.Column<int>(type: "int", nullable: false),
                    BiomarkerId = table.Column<int>(type: "int", nullable: false),
                    CountryCode = table.Column<string>(type: "nvarchar(20)", nullable: true),
                    Min = table.Column<double>(type: "float", nullable: false),
                    LowRed = table.Column<double>(type: "float", nullable: false),
                    LowAmber = table.Column<double>(type: "float", nullable: false),
                    Reference = table.Column<double>(type: "float", nullable: false),
                    HighAmber = table.Column<double>(type: "float", nullable: false),
                    Max = table.Column<double>(type: "float", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BiomarkerRanges", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BiomarkerRanges_Analyses_AnalysisId",
                        column: x => x.AnalysisId,
                        principalTable: "Analyses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BiomarkerRanges_Biomarkers_BiomarkerId",
                        column: x => x.BiomarkerId,
                        principalTable: "Biomarkers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BiomarkerRanges_Countries_CountryCode",
                        column: x => x.CountryCode,
                        principalTable: "Countries",
                        principalColumn: "Code");
                });

            migrationBuilder.CreateTable(
                name: "Sites",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    SiteName = table.Column<string>(type: "nvarchar(158)", maxLength: 158, nullable: false),
                    CompanyId = table.Column<string>(type: "nvarchar(158)", nullable: false),
                    CountryCode = table.Column<string>(type: "nvarchar(20)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Sites", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Sites_Companies_CompanyId",
                        column: x => x.CompanyId,
                        principalTable: "Companies",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Sites_Countries_CountryCode",
                        column: x => x.CountryCode,
                        principalTable: "Countries",
                        principalColumn: "Code",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "Batches",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BatchNumber = table.Column<string>(type: "nvarchar(40)", maxLength: 40, nullable: false),
                    DateCollected = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DateAnalysed = table.Column<DateTime>(type: "datetime2", nullable: false),
                    SiteId = table.Column<string>(type: "nvarchar(20)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Batches", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Batches_Sites_SiteId",
                        column: x => x.SiteId,
                        principalTable: "Sites",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Reports",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CreatedOn = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsReviewed = table.Column<bool>(type: "bit", nullable: false),
                    SiteId = table.Column<string>(type: "nvarchar(20)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reports", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Reports_Sites_SiteId",
                        column: x => x.SiteId,
                        principalTable: "Sites",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Samples",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BatchId = table.Column<long>(type: "bigint", nullable: false),
                    SampleCode = table.Column<string>(type: "nvarchar(160)", maxLength: 160, nullable: false),
                    Instrument = table.Column<string>(type: "nvarchar(400)", maxLength: 400, nullable: false),
                    Species = table.Column<string>(type: "nvarchar(158)", maxLength: 158, nullable: false),
                    WaterType = table.Column<int>(type: "int", nullable: false),
                    Pen = table.Column<string>(type: "nvarchar(10)", maxLength: 10, nullable: false),
                    FishNumber = table.Column<string>(type: "nvarchar(158)", maxLength: 158, nullable: false),
                    AverageWeightInGrams = table.Column<decimal>(type: "NUMERIC(10,4)", nullable: false),
                    TemperatureInCelsius = table.Column<decimal>(type: "NUMERIC(10,4)", nullable: false),
                    OxygenLevelInMg = table.Column<decimal>(type: "NUMERIC(10,4)", nullable: true),
                    MortalityRatePercentage = table.Column<decimal>(type: "NUMERIC(10,4)", nullable: false),
                    Strain = table.Column<string>(type: "nvarchar(158)", maxLength: 158, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Samples", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Samples_Batches_BatchId",
                        column: x => x.BatchId,
                        principalTable: "Batches",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ReportedBatches",
                columns: table => new
                {
                    ReportId = table.Column<long>(type: "bigint", nullable: false),
                    BatchId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReportedBatches", x => new { x.BatchId, x.ReportId });
                    table.ForeignKey(
                        name: "FK_ReportedBatches_Batches_BatchId",
                        column: x => x.BatchId,
                        principalTable: "Batches",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ReportedBatches_Reports_ReportId",
                        column: x => x.ReportId,
                        principalTable: "Reports",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "BiomarkerResults",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BioMarkerId = table.Column<int>(type: "int", nullable: false),
                    Result = table.Column<decimal>(type: "decimal(18,6)", precision: 18, scale: 6, nullable: false),
                    SampleId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BiomarkerResults", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BiomarkerResults_Biomarkers_BioMarkerId",
                        column: x => x.BioMarkerId,
                        principalTable: "Biomarkers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_BiomarkerResults_Samples_SampleId",
                        column: x => x.SampleId,
                        principalTable: "Samples",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "HatcherySample",
                columns: table => new
                {
                    HatcheriesId = table.Column<int>(type: "int", nullable: false),
                    SamplesId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HatcherySample", x => new { x.HatcheriesId, x.SamplesId });
                    table.ForeignKey(
                        name: "FK_HatcherySample_Hatcheries_HatcheriesId",
                        column: x => x.HatcheriesId,
                        principalTable: "Hatcheries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_HatcherySample_Samples_SamplesId",
                        column: x => x.SamplesId,
                        principalTable: "Samples",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Analyses",
                columns: new[] { "Id", "MethodName" },
                values: new object[,]
                {
                    { 1, "GENERAL HOMEOSTASIS" },
                    { 2, "MUSCLE/LIVER TISSUE DAMAGE" },
                    { 3, "LIVER/GENERAL STRESS/PANCREAS" },
                    { 4, "LIVER FUNCTION" },
                    { 5, "GILL FUNCTION" },
                    { 6, "GILL/LIVER FUNCTION" }
                });

            migrationBuilder.InsertData(
                table: "Biomarkers",
                columns: new[] { "Id", "Name" },
                values: new object[,]
                {
                    { 1, "ALBUMIN" },
                    { 2, "CHLORIDE" },
                    { 3, "ZINC" },
                    { 4, "ALT" },
                    { 5, "CK" },
                    { 6, "CM MB" },
                    { 7, "AST" },
                    { 8, "LDH" },
                    { 9, "LIPASE" },
                    { 10, "GLUCOSE" },
                    { 11, "CHOLESTEROL" },
                    { 12, "IRON" },
                    { 13, "LACTATE" },
                    { 14, "PHOSPHATE" },
                    { 15, "MAGNESIUM" },
                    { 16, "SODIUM" },
                    { 17, "POTASSIUM" },
                    { 18, "CALCIUM" }
                });

            migrationBuilder.InsertData(
                table: "BiomarkerRanges",
                columns: new[] { "Id", "AnalysisId", "BiomarkerId", "CountryCode", "HighAmber", "LowAmber", "LowRed", "Max", "Min", "Reference" },
                values: new object[,]
                {
                    { 1, 1, 1, null, 23.100000000000001, 17.199999999999999, 15.199999999999999, 30.0, 0.0, 21.100000000000001 },
                    { 2, 1, 2, null, 139.59999999999999, 131.5, 128.80000000000001, 200.0, 0.0, 136.59999999999999 },
                    { 3, 1, 3, null, 406.60000000000002, 244.09999999999999, 189.90000000000001, 500.0, 0.0, 352.39999999999998 },
                    { 4, 2, 4, null, 12.0, 4.0, 2.0, 500.0, 0.0, 10.0 },
                    { 5, 2, 5, null, 22176.0, 3529.0, 2686.0, 900000.0, 0.0, 15960.0 },
                    { 6, 2, 6, null, 37226.0, 6073.0, 4311.0, 1000000.0, 0.0, 26842.0 },
                    { 7, 3, 7, null, 1136.0, 354.19999999999999, 93.599999999999994, 50000.0, 0.0, 875.0 },
                    { 8, 3, 8, null, 1400.0, 220.5, 172.90000000000001, 50000.0, 0.0, 1007.0 },
                    { 9, 3, 9, null, 7.2000000000000002, 5.7000000000000002, 5.2000000000000002, 50.0, 0.0, 6.7000000000000002 },
                    { 10, 4, 10, null, 6.1900000000000004, 4.2999999999999998, 3.6800000000000002, 20.0, 0.0, 5.5700000000000003 },
                    { 11, 4, 11, null, 11.83, 7.2000000000000002, 5.6600000000000001, 20.0, 0.0, 10.289999999999999 },
                    { 12, 4, 12, null, 26.73, 12.699999999999999, 8.0299999999999994, 50.0, 0.0, 22.050000000000001 },
                    { 13, 5, 13, null, 5.5499999999999998, 2.8700000000000001, 1.97, 50.0, 0.0, 4.6600000000000001 },
                    { 14, 5, 14, null, 6.0099999999999998, 4.3300000000000001, 3.7599999999999998, 20.0, 0.0, 5.4500000000000002 },
                    { 15, 5, 15, null, 1.6899999999999999, 1.04, 0.81999999999999995, 10.0, 0.0, 1.47 },
                    { 16, 6, 16, null, 171.80000000000001, 163.80000000000001, 161.09999999999999, 300.0, 0.0, 169.09999999999999 },
                    { 17, 6, 17, null, 1.1000000000000001, 0.59999999999999998, 0.40000000000000002, 20.0, 0.0, 0.90000000000000002 },
                    { 18, 6, 18, null, 3.6000000000000001, 3.1000000000000001, 2.8999999999999999, 20.0, 0.0, 3.3999999999999999 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_Batches_BatchNumber",
                table: "Batches",
                column: "BatchNumber",
                unique: true)
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_Batches_SiteId",
                table: "Batches",
                column: "SiteId");

            migrationBuilder.CreateIndex(
                name: "IX_BiomarkerRanges_AnalysisId",
                table: "BiomarkerRanges",
                column: "AnalysisId");

            migrationBuilder.CreateIndex(
                name: "IX_BiomarkerRanges_BiomarkerId",
                table: "BiomarkerRanges",
                column: "BiomarkerId");

            migrationBuilder.CreateIndex(
                name: "IX_BiomarkerRanges_CountryCode",
                table: "BiomarkerRanges",
                column: "CountryCode");

            migrationBuilder.CreateIndex(
                name: "IX_BiomarkerResults_BioMarkerId",
                table: "BiomarkerResults",
                column: "BioMarkerId");

            migrationBuilder.CreateIndex(
                name: "IX_BiomarkerResults_SampleId",
                table: "BiomarkerResults",
                column: "SampleId");

            migrationBuilder.CreateIndex(
                name: "IX_Biomarkers_Name",
                table: "Biomarkers",
                column: "Name",
                unique: true)
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_Employees_CompanyId",
                table: "Employees",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Employees_LoginIdentity",
                table: "Employees",
                column: "LoginIdentity")
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_Hatcheries_HatcheryCode",
                table: "Hatcheries",
                column: "HatcheryCode",
                unique: true)
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_HatcherySample_SamplesId",
                table: "HatcherySample",
                column: "SamplesId");

            migrationBuilder.CreateIndex(
                name: "IX_ReportedBatches_ReportId",
                table: "ReportedBatches",
                column: "ReportId");

            migrationBuilder.CreateIndex(
                name: "IX_Reports_SiteId",
                table: "Reports",
                column: "SiteId");

            migrationBuilder.CreateIndex(
                name: "IX_Samples_BatchId",
                table: "Samples",
                column: "BatchId");

            migrationBuilder.CreateIndex(
                name: "IX_Samples_SampleCode",
                table: "Samples",
                column: "SampleCode",
                unique: true)
                .Annotation("SqlServer:Clustered", false);

            migrationBuilder.CreateIndex(
                name: "IX_Sites_CompanyId",
                table: "Sites",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_Sites_CountryCode",
                table: "Sites",
                column: "CountryCode");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BiomarkerRanges");

            migrationBuilder.DropTable(
                name: "BiomarkerResults");

            migrationBuilder.DropTable(
                name: "Employees");

            migrationBuilder.DropTable(
                name: "HatcherySample");

            migrationBuilder.DropTable(
                name: "ReportedBatches");

            migrationBuilder.DropTable(
                name: "Analyses");

            migrationBuilder.DropTable(
                name: "Biomarkers");

            migrationBuilder.DropTable(
                name: "Hatcheries");

            migrationBuilder.DropTable(
                name: "Samples");

            migrationBuilder.DropTable(
                name: "Reports");

            migrationBuilder.DropTable(
                name: "Batches");

            migrationBuilder.DropTable(
                name: "Sites");

            migrationBuilder.DropTable(
                name: "Companies");

            migrationBuilder.DropTable(
                name: "Countries");
        }
    }
}
