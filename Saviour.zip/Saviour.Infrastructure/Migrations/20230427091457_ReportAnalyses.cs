﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class ReportAnalyses : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ReportAnalyses",
                columns: table => new
                {
                    ReportId = table.Column<long>(type: "bigint", nullable: false),
                    AnalysisId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ReportAnalyses", x => new { x.AnalysisId, x.ReportId });
                    table.ForeignKey(
                        name: "FK_ReportAnalyses_Analyses_AnalysisId",
                        column: x => x.AnalysisId,
                        principalTable: "Analyses",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_ReportAnalyses_Reports_ReportId",
                        column: x => x.ReportId,
                        principalTable: "Reports",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ReportAnalyses_ReportId",
                table: "ReportAnalyses",
                column: "ReportId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ReportAnalyses");
        }
    }
}
