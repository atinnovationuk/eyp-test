﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Saviour.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class NewBatchFields : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "ConfirmedCondition",
                table: "Batches",
                type: "nvarchar(2000)",
                maxLength: 2000,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "DateReceived",
                table: "Batches",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Utc));

            migrationBuilder.AddColumn<string>(
                name: "FishHealthHistory",
                table: "Batches",
                type: "nvarchar(2000)",
                maxLength: 2000,
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ConfirmedCondition",
                table: "Batches");

            migrationBuilder.DropColumn(
                name: "DateReceived",
                table: "Batches");

            migrationBuilder.DropColumn(
                name: "FishHealthHistory",
                table: "Batches");
        }
    }
}
