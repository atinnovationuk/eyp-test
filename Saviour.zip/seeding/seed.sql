
BEGIN TRANSACTION T1;

SET IDENTITY_INSERT [dbo].[Users] ON;

INSERT INTO [dbo].[Users]
(
    [Id],
	[Name],
	[AzureId]
)
VALUES 
(1, 'Fred', 'fred@flintstone.roc'),
(2, 'Wilma', 'wilma@flintstone.roc');

SET IDENTITY_INSERT [dbo].[Users] OFF;
	
SET IDENTITY_INSERT [dbo].[DraftReports] ON;

INSERT INTO [dbo].[DraftReports]
(
    [Id],
    [CreatedOn],
    [CreatedById],
    [Observations],
    [SiteId]
)
VALUES
    (1, '220326', 1, 'Observed to be a fish', 'Chesterfield'),
    (2, '220325', 1, 'Observed to be a fish', 'Carningsby'),
    (3, '220326', 1, 'Observed to be a fish', 'Chesterfield'),
    (4, '220407', 1, 'Observed to be a fish', 'Carningsby');
	
SET IDENTITY_INSERT [dbo].[DraftReports] OFF;

	
INSERT INTO [dbo].[DraftReportedBatches]
(
    [DraftReportId],
    [BatchId]
)
VALUES
    (1, 1),
    (2, 19),
    (3, 19),
    (4, 2);

INSERT INTO [dbo].[DraftReportAnalyses]
(
    [DraftReportId],
    [AnalysisId]
)
VALUES
    (1, 1),
    (1, 2),
    (1, 3),
    (1, 4),
    (1, 5),
    (1, 6),
    (2, 1),
    (2, 2),
    (2, 3),
    (2, 4),
    (2, 5),
    (2, 6),
    (3, 1),
    (3, 2),
    (3, 3),
    (3, 4),
    (3, 5),
    (3, 6),
    (4, 1),
    (4, 2),
    (4, 3),
    (4, 4),
    (4, 5),
    (4, 6);


COMMIT TRANSACTION T1;
