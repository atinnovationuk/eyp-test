﻿# End to End API Tests

These tests should test the full application API running in a setup as close to the production environment as possible.

## Initial Setup

See [Fixture Readme](./../Saviour.EndToEnd.Fixture/README.md)
