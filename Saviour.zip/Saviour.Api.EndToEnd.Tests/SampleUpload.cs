﻿using System.Text;
using Newtonsoft.Json;
using Saviour.Api.EndToEnd.Tests.Fixture;
using Saviour.Domain.Dto;
using Saviour.Domain.Interfaces;
using Saviour.EndToEnd.Fixture;
using Saviour.Infrastructure;

namespace Saviour.Api.EndToEnd.Tests;

[Collection(WebAppCollection.Name)]
public class SampleUpload : IDisposable
{
    private readonly HttpClient _client;
    private readonly SaviourContext _database;

    public SampleUpload(WebAppFixture webApp)
    {
        _database = webApp.Database;
        _client = webApp.CreateClient();
    }

    [Fact]
    public async Task PostSampleInsertsAllData()
    {
        var dateCollected = new DateOnly(2023, 03, 02);
        var dateAnalysed = new DateTime(2023, 03, 02, 11, 11, 11);
        var dateReceived = new DateTime(2023, 04, 03, 10, 10, 10);
        const string companyCode = "BobCompany1";
        const string companyName = "Bob's Company";
        const string siteCode = "BobCompany1SiteA";
        const string siteName = "Pub Car Park";
        const string batchNumber = "1";
        const string countryCode = "IO";
        var uploadedSample = new UploadSampleDto
        {
            SampleCode = "Sample Code",
            CountryCode = countryCode,
            CompanyCode = companyCode,
            CompanyName = companyName,
            SiteCode = siteCode,
            SiteName = siteName,
            DateCollected = dateCollected,
            DateAnalysed = dateAnalysed,
            Species = "Sea Monkey",
            WaterType = WaterType.FreshWater,
            BatchNumber = batchNumber,
            Instrument = "Sea Tuba",
            Pen = "Bic",
            FishNumber = "1001",
            AverageWeightInGrams = 2,
            TemperatureInCelsius = 10,
            OxygenLevelInMg = 5,
            MortalityRatePercentage = 99,
            DateReceived = dateReceived,
            ConfirmedCondition = "Test\r\nConfirmed Condition",
            FishHealthHistory = "Test\r\nFish Health History",
            Strain = "Stress",
            Hatcheries = new []
            {
                "Bath tub"
            },
            BiomarkerResults = new []
            {
                new BiomarkerResultDto("Sodium", 1000.3M),
                new BiomarkerResultDto("Calcium", 0.3M),
                new BiomarkerResultDto("Cyanide", 0.000001M)
            }
        };
        var postSampleResponse = await PostSample(uploadedSample);
        AssertResponseSuccessful(postSampleResponse);

        await new TestCredentials().AddAuthentication(_client, TestUserType.Analyst);

        var companies = await GetCompanies();
        Assert.Equal(new[]
            {
                new CompanyDto(companyCode, companyName, "", 1)
            },
            companies
        );
        
        var sites = await GetSites(companyCode);
        Assert.Equal(new[]
            {
                new SiteDto(siteCode, siteName, companyCode, countryCode)
            },
            sites
        );

        var batches = await GetBatches(siteCode);
        Assert.NotNull(batches);

        var batch = batches[0];
        var batchId = batch.Id;
        Assert.Equal(new[]
            {
                new BatchDto
                (
                    batchId,
                    batchNumber,
                    dateCollected,
                    dateAnalysed,
                    dateReceived,
                    companyCode,
                    siteCode,
                    "Test Confirmed Condition",
                    "Test Fish Health History",
                    new List<SampleDto>
                    {
                        new(
                            uploadedSample.SampleCode, uploadedSample.Species, uploadedSample.WaterType,
                            uploadedSample.Pen, uploadedSample.FishNumber, uploadedSample.AverageWeightInGrams, uploadedSample.TemperatureInCelsius,
                            uploadedSample.OxygenLevelInMg, uploadedSample.MortalityRatePercentage, uploadedSample.Strain, 
                            uploadedSample.Hatcheries, 
                            uploadedSample.BiomarkerResults.GroupBy(r => r.Biomarker, StringComparer)
                                .ToDictionary(
                                    group => group.Key.ToUpper(),
                                    group => group.Select(g => g.Result).First()
                                ),
                            null
                            )
                    }
                )
            },
            batches
        );
    }

    private Task<HttpResponseMessage> PostSample(UploadSampleDto sample)
    {
        var sampleString = JsonConvert.SerializeObject(sample);
        return _client.PostAsync("/api/Sample", new StringContent(sampleString, Encoding.UTF8, "application/json"));
    }

    private Task<BatchDto[]?> GetBatches(string siteId) 
        => Get<BatchDto[]>($"api/Batch?siteId={siteId}");

    private Task<CompanyDto[]?> GetCompanies() => Get<CompanyDto[]>("api/Company");

    private Task<SiteDto[]?> GetSites(string companyId) => Get<SiteDto[]>($"api/Company/{companyId}");
    
    private async Task<T?> Get<T>(string endPoint)
    {
        var getResponse = await _client.GetAsync(endPoint);
        AssertResponseSuccessful(getResponse);

        var responseString = await getResponse.Content.ReadAsStringAsync();
        return JsonConvert.DeserializeObject<T>(responseString);
    }
    
    private static void AssertResponseSuccessful(HttpResponseMessage response)
    {
        Assert.True(response.IsSuccessStatusCode, response.ToString());
    }
    
    private static StringComparer StringComparer => DtoHelpers.StringComparer;

    public void Dispose()
    {
        _database.Samples.RemoveRange(_database.Samples);
        _client.Dispose();
    }
}
