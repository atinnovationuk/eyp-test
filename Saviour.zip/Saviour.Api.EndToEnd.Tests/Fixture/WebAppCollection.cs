﻿using Saviour.EndToEnd.Fixture;

namespace Saviour.Api.EndToEnd.Tests.Fixture;

[CollectionDefinition(Name)]
public class WebAppCollection : ICollectionFixture<WebAppFixture>
{
    public const string Name = "Web App Collection";

    // This class exists solely to define the collection for this fixture
}
