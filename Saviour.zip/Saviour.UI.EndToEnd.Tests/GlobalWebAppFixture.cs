﻿using System.Diagnostics;
using System.Text.RegularExpressions;
using Microsoft.Playwright;
using Microsoft.Playwright.TestAdapter;
using Saviour.EndToEnd.Fixture;

namespace Saviour.UI.EndToEnd.Tests;

[SetUpFixture]
public static class GlobalWebAppFixture
{
    public static readonly WebAppFixture WebApp = new();
    public static string BaseUrl => WebApp.ClientOptions.BaseAddress.ToString();
    private static IBrowser Browser { get; set; } = null!;

    internal static Task<IBrowserContext> CreateContext(Action<BrowserNewContextOptions>? configureOptions = null)
    {
        var options = new BrowserNewContextOptions
        {
            IgnoreHTTPSErrors = true
        };

        configureOptions?.Invoke(options);

        return Browser.NewContextAsync(options);
    }

    public const string AnalystState = "AnalystState.json";
    public const string CustomerState = "CustomerState.json";
    public const string ScreenshotsDirectory = "Screenshots";

    public static string AnalystUserName { get; private set; } = string.Empty;
    public static string CustomerUserName { get; private set; } = string.Empty;

    private static IPlaywright? playwright;

    [OneTimeSetUp]
    public static async Task SetupFixture()
    {
        ClearScreenshotsFolder();
        
        using var _ = WebApp.CreateDefaultClient();

        playwright = await Playwright.CreateAsync();

        Browser = await playwright[PlaywrightSettingsProvider.BrowserName].LaunchAsync(
            new BrowserTypeLaunchOptions
            {
                Headless = !Debugger.IsAttached
            });

        // Sign in as both our test users and store the state of the browser when authenticated - this massively speeds up tests themselves
        var (analystUsername, analystPassword) = await WebApp.TestCredentials.GetCredentials(TestUserType.Analyst);
        AnalystUserName = analystUsername;
        await SignInAndStoreState(
            AnalystState,
            AnalystUserName,
            analystPassword
        );

        var (customerUsername, customerPassword) = await WebApp.TestCredentials.GetCredentials(TestUserType.Customer);
        CustomerUserName = customerUsername;
        await SignInAndStoreState(
            CustomerState,
            CustomerUserName,
            customerPassword
        );
    }

    private static void ClearScreenshotsFolder()
    {
        if (Directory.Exists(ScreenshotsDirectory))
        {
            Directory.Delete(ScreenshotsDirectory, true);
        }

        Directory.CreateDirectory(ScreenshotsDirectory);
    }

    private static async ValueTask SignInAndStoreState(
        string contextPath, string userName, string password
    ) {
        await using var context = await CreateContext();

        var page = await context.NewPageAsync();
        page.SetDefaultTimeout(WebApp.WebAppOverrides.DefaultTimeout);

        try
        {
            await page.GotoAsync(BaseUrl, new PageGotoOptions
            {
                WaitUntil = WaitUntilState.NetworkIdle
            });

            await page.GetByRole(AriaRole.Button, new PageGetByRoleOptions
            {
                Name = "Sign In"
            }).ClickAsync();

            await page.WaitForURLAsync(new Regex($"({Regex.Escape("https://login.microsoftonline.com")}).*"),
                new PageWaitForURLOptions
                {
                    WaitUntil = WaitUntilState.NetworkIdle,
                    Timeout = 10_000
                });

            var useAnotherAccount =
                page.GetByRole(AriaRole.Button, new PageGetByRoleOptions { Name = "Use another account" });
            if (await useAnotherAccount.IsVisibleAsync())
            {
                await useAnotherAccount.ClickAsync();
            }

            await page.GetByLabel("Enter your email")
                .FillAsync(userName);

            await page.GetByRole(AriaRole.Button, new PageGetByRoleOptions { Name = "Next" })
                .ClickAsync();

            await page.GetByLabel($"Enter the password")
                .FillAsync(password);

            await page.GetByRole(AriaRole.Button, new PageGetByRoleOptions { Name = "Sign in" })
                .ClickAsync();

            // 'Stay signed in' button
            await page.GetByRole(AriaRole.Button, new PageGetByRoleOptions { Name = "Yes" })
                .ClickAsync();

            await page.WaitForURLAsync(BaseUrl, new PageWaitForURLOptions
            {
                WaitUntil = WaitUntilState.NetworkIdle,
                Timeout = 10_000
            });

            await context.StorageStateAsync(new BrowserContextStorageStateOptions
            {
                Path = contextPath
            });

        }
        catch
        {
            var filePath = Path.Combine(ScreenshotsDirectory, $"Setup-{userName}.png");

            await page.ScreenshotAsync(new PageScreenshotOptions
            {
                Path = filePath
            });

            throw;
        }

        await page.CloseAsync();
        await context.CloseAsync();
    }

    [OneTimeTearDown]
    public static async Task TearDownFixture()
    {
        await WebApp.DisposeAsync();
        playwright?.Dispose();
    }
}
