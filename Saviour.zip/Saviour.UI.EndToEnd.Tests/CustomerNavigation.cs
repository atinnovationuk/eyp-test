﻿using Microsoft.Playwright;
using Saviour.Domain.Entities;

namespace Saviour.UI.EndToEnd.Tests;

public class CustomerNavigation : UiTest
{
    [Test]
    public async Task ErrorDisplayedWhenUserIsUnauthorised()
    {
        var page = await NewPage(ContextType.Customer);

        await Assertions.Expect(page.GetByRole(AriaRole.Alert, new PageGetByRoleOptions
        {
            Name = "Unauthorised user account"
        })).ToBeVisibleAsync(new LocatorAssertionsToBeVisibleOptions
        {
            Timeout = 30_000
        });
    }

    [Test]
    public async Task ErrorNotDisplayedWhenUserIsAuthorised()
    {
        await AuthoriseCustomerUser("Company1");

        var page = await NewPage(ContextType.Customer);

        await Assertions.Expect(page.GetByRole(AriaRole.Alert, new PageGetByRoleOptions
        {
            Name = "Unauthorised user account"
        })).ToBeHiddenAsync();
    }

    private static async ValueTask AuthoriseCustomerUser(string companyId)
    {
        await Database.Employees.AddAsync(new Employee
        {
            Name = "Customer Test User",
            LoginIdentity = GlobalWebAppFixture.CustomerUserName,
            CompanyId = companyId
        });

        await Database.SaveChangesAsync();
    }

    [SetUp]
    public override async Task InitializeAsync()
    {
        await base.InitializeAsync();

        await Database.Companies.AddRangeAsync(new[]
        {
            new Company
            {
                Id = "Company1",
                CompanyName = "Emron"
            },
            new Company
            {
                Id = "Company2",
                CompanyName = "Peron"
            }
        });
        await Database.SaveChangesAsync();
    }
    
    [TearDown]
    public override async Task TeardownAsync()
    {
        Database.Companies.RemoveRange(Database.Companies);
        await Database.SaveChangesAsync();

        await base.TeardownAsync();
    }
}