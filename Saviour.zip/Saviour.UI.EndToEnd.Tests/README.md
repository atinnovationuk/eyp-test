﻿# End to End UI Tests

These tests should test the full application UI running in a setup as close to the production environment as possible.

## Initial Setup

The following setup must be performed before running these tests locally

## Screenshots

Browser screenshots are saved on test failure to the output directory, under a folder aptly named 'Screenshots'

### Environment variables

See [Fixture Readme](./../Saviour.EndToEnd.Fixture/README.md)

### Playwright Browsers

To install the web browsers required by Playwright, build this project then run the command:

```shell
pwsh bin/Debug/net7.0/playwright.ps1 install
```
