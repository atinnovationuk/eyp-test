using System.Text.RegularExpressions;
using Microsoft.Playwright;
using Saviour.Domain.Entities;

namespace Saviour.UI.EndToEnd.Tests;

[TestFixture("Test Company A", "Company1", "Site A1", "SiteA1")]
[TestFixture("Test Company A", "Company1", "Site A1", "SiteA1")]
[TestFixture("Test Company A", "Company1", "Site A2", "SiteA2")]
[TestFixture("Test Company B", "Company2", "Site B1", "SiteB1")]
public class AnalystNavigation : UiTest
{
    private readonly string _companyName;
    private readonly string _companyId;
    private readonly string _siteName;
    private readonly string _siteId;

    public AnalystNavigation(string companyName, string companyId, string siteName, string siteId)
    {
        _companyName = companyName;
        _companyId = companyId;
        _siteName = siteName;
        _siteId = siteId;
    }

    [Test]
    public async Task CanNavigateCompanies()
    {
        var page = await NewPage(ContextType.Analyst);

        await page.GetByRole(AriaRole.Link, new PageGetByRoleOptions
        {
            Name = _companyName
        }).ClickAsync();

        await Assertions.Expect(page).ToHaveURLAsync(new Regex($".*{Regex.Escape($"company/{_companyId}").ToLower()}"));
    }

    [Test]
    public async Task CanNavigateSites()
    {
        var page = await NewPage(ContextType.Analyst);

        await LoadCompanyData(page);

        await page.GetByRole(AriaRole.Link, new PageGetByRoleOptions
        {
            Name = _siteName
        }).ClickAsync();

        await Assertions.Expect(page).ToHaveURLAsync(new Regex($".*{Regex.Escape($"company/{_companyId}/site/{_siteId}").ToLower()}"));
    }

    private async Task LoadCompanyData(IPage page)
    {
        await page.GetByRole(AriaRole.Button, new PageGetByRoleOptions
        {
            Name = $"Load {_companyName}"
        }).ClickAsync();
    }

    [SetUp]
    public override async Task InitializeAsync()
    {
        await base.InitializeAsync();

        var country = await Database.Countries.AddAsync(new Country
        {
            Code = "GB"
        });

        await Database.Companies.AddRangeAsync(
            new Company
            {
                Id = "Company1",
                CompanyName = "Test Company A",
                Sites = new List<Site>
                {
                    new ()
                    {
                        Id = "SiteA1",
                        SiteName = "Site A1",
                        Country = country.Entity
                    },
                    new ()
                    {
                        Id = "SiteA2",
                        SiteName = "Site A2",
                        Country = country.Entity
                    }
                }
            },
            new Company
            {
                Id = "Company2",
                CompanyName = "Test Company B",
                Sites = new List<Site>
                {
                    new ()
                    {
                        Id = "SiteB1",
                        SiteName = "Site B1",
                        Country = country.Entity
                    }
                }
            }
        );

        await Database.SaveChangesAsync();
    }

    [TearDown]
    public override async Task TeardownAsync()
    {
        Database.Companies.RemoveRange(Database.Companies);
        Database.Countries.RemoveRange(Database.Countries);
        await Database.SaveChangesAsync();

        await base.TeardownAsync();
    }
}
