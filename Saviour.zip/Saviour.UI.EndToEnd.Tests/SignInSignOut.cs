using Microsoft.Playwright;

namespace Saviour.UI.EndToEnd.Tests;

[Parallelizable(ParallelScope.Self)]
public class SignInSignOut : UiTest
{
    [Test]
    public async Task CanSignInWhenSignedOut()
    {
        var page = await NewPage(ContextType.SignedOut);

        var signIn = page.GetByRole(AriaRole.Button, new PageGetByRoleOptions
        {
            Name = "Sign In"
        });

        await Assertions.Expect(signIn).ToBeEnabledAsync();
    }

    [Test]
    public async Task CanSignOutWhenSignedIn()
    {
        var page = await NewPage(ContextType.Analyst);

        var signOut = page.GetByRole(AriaRole.Button, new PageGetByRoleOptions
        {
            Name = "Sign Out"
        });

        await Assertions.Expect(signOut).ToBeEnabledAsync();
    }
}
