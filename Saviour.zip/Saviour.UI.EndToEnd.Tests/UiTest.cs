﻿using Microsoft.Playwright;
using Saviour.Infrastructure;

namespace Saviour.UI.EndToEnd.Tests;

public enum ContextType
{
    SignedOut,
    Analyst,
    Customer
}

[NonParallelizable]
public class UiTest : WorkerAwareTest
{
    private HttpClient? _client;

    protected static SaviourContext Database => GlobalWebAppFixture.WebApp.Database;
    private static string BaseUrl => GlobalWebAppFixture.BaseUrl;

    private readonly List<IPage> _pages = new();
    private readonly List<IBrowserContext> _contexts = new();

    protected async ValueTask<IPage> NewPage(ContextType contextType)
    {
        var context = await GetContext(contextType);
        _contexts.Add(context);
        
        var page = await context.NewPageAsync();
        _pages.Add(page);
        
        page.SetDefaultTimeout(GlobalWebAppFixture.WebApp.WebAppOverrides.DefaultTimeout);

        await page.GotoAsync(BaseUrl, new PageGotoOptions
        {
            WaitUntil = WaitUntilState.NetworkIdle
        });

        return page;
    }

    private static async ValueTask<IBrowserContext> GetContext(ContextType contextType)
        => contextType switch
        {
            ContextType.Analyst => await CreateContext(GlobalWebAppFixture.AnalystState),
            ContextType.Customer => await CreateContext(GlobalWebAppFixture.CustomerState),
            _ => await GlobalWebAppFixture.CreateContext()
        };

    private static Task<IBrowserContext> CreateContext(string path)
        => GlobalWebAppFixture.CreateContext(options =>
        {
            options.StorageStatePath = path;
        });

    [SetUp]
    public virtual Task InitializeAsync()
    {
        _client = GlobalWebAppFixture.WebApp.CreateClient();
        return Task.CompletedTask;
    }

    [TearDown]
    public virtual async Task TeardownAsync()
    {
        if (!TestOk())
        {
            await ScreenshotLastPage();
        }

        foreach (var page in _pages)
        {
            await page.CloseAsync();
        }
        _pages.Clear();

        foreach (var context in _contexts)
        {
            await context.CloseAsync();
        }
        _contexts.Clear();

        _client?.Dispose();
    }

    private async Task ScreenshotLastPage()
    {
        var page = _pages.LastOrDefault();
        if (page is not null)
        {
            var fileName = EscapeFileName(TestContext.CurrentContext.Test.FullName);
            var filePath = Path.Combine(GlobalWebAppFixture.ScreenshotsDirectory, $"{fileName}.png");
            
            await page.ScreenshotAsync(new PageScreenshotOptions
            {
                Path = filePath
            });
        }

        static string EscapeFileName(string path) =>
            Path.GetInvalidFileNameChars()
                .Aggregate(path, (current, invalidCharacter)
                    => current.Replace(invalidCharacter, '_')
                );
    }
}