﻿using Saviour.Domain.Entities;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class GetMLModelTests
{
    private readonly FakeRepository<MLModel> _mlModels = new(new Dictionary<object, MLModel>
    {
        [1] = new()
        {
            Id = 1,
            Type = MLModelType.FishHealth,
            Version = 1
        },
        [2] = new()
        {
            Id = 2,
            Type = MLModelType.FishHealth,
            Version = 2
        },
        [3] = new()
        {
            Id = 3,
            Type = (MLModelType)(-1),
            Version = 1
        }
    });

    private readonly GetMLModel _getMLModel;

    public GetMLModelTests()
    {
        _getMLModel = new GetMLModel(_mlModels.Mock.Object);
    }

    [Theory]
    [MemberData(nameof(GetLatestData))]
    public void GetLatest_ReturnsExpected(MLModelType modelType, MLModel expected)
    {
        var result = _getMLModel.GetLatest(modelType);
        
        Assert.Equivalent(expected, result);
    }

    public static TheoryData<MLModelType, MLModel> GetLatestData => new()
    {
        {
            MLModelType.FishHealth, new MLModel
            {
                Id = 2,
                Type = MLModelType.FishHealth,
                Version = 2
            }
        },
        {
            (MLModelType)(-1), new MLModel
            {
                Id = 3,
                Type = (MLModelType)(-1),
                Version = 1
            }
        }
    };
}