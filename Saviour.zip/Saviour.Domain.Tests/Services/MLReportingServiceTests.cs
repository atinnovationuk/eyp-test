﻿using Saviour.Domain.Entities;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class MLReportingServiceTests
{
    private readonly FakeRepository<Sample> _samples = new(
        new Dictionary<object, Sample>
        {
            [1L] = new()
            {
                Id = 1,
                BatchId = 2
            },
            [2L] = new()
            {
                Id = 2,
                BatchId = 1
            },
            [3L] = new()
            {
                Id = 3,
                BatchId = 2
            }
        });
    
    private readonly FakeRepository<FishHealthResult> _fishHealth = new(
        new Dictionary<object, FishHealthResult>
        {
            [1L] = new()
            {
                Id = 1,
                SampleId = 3
            },
            [2L] = new()
            {
                Id = 2,
                SampleId = 2
            },
            [3L] = new()
            {
                Id = 3,
                SampleId = 1
            },
            [4L] = new()
            {
                Id = 4,
                SampleId = 3
            }
        });
    
    private readonly FakeRepository<ReportedFishHealthResult> _reportedFishHealth = new(
        new Dictionary<object, ReportedFishHealthResult>
        {
            [1L] = new()
            {
                Id = 1,
                DraftReportId = 2
            },
            [2L] = new()
            {
                Id = 2,
                DraftReportId = 1
            },
            [3L] = new()
            {
                Id = 3,
                DraftReportId = 2
            }
        });

    private readonly MLReportingService _reportingService;
    
    public MLReportingServiceTests()
    {
        _reportingService = new MLReportingService(_samples.Mock.Object, _fishHealth.Mock.Object,
            _reportedFishHealth.Mock.Object);
    }

    [Theory]
    [MemberData(nameof(OnCreatedData))]
    public async Task OnCreated_InsertsData(DraftReport report, IEnumerable<long> expectedInsertResultIds)
    {
        await _reportingService.OnCreated(report);
        
        Assert.Equal(expectedInsertResultIds, _reportedFishHealth.Inserted.Select(r => r.MLResultId));
    }

    private static List<Batch> MakeBatches(params int[] ids) => ids.Select(id => new Batch { Id = id }).ToList();

    public static TheoryData<DraftReport, IEnumerable<long>> OnCreatedData =>
        new()
        {
            {
                new DraftReport
                {
                    Batches = MakeBatches(1)
                },
                new []
                {
                    2L
                }
            },
            {
                new DraftReport
                {
                    Batches = MakeBatches(2)
                },
                new []
                {
                    1L, 3L, 4L
                }
            }
        };

    [Theory]
    [MemberData(nameof(OnApprovedData))]
    public async Task OnApproved_UpdatesData(DraftReport draftReport, IEnumerable<long> expectedUpdatedIds)
    {
        var report = new Report();

        await _reportingService.OnApproved(draftReport, report);

        Assert.All(expectedUpdatedIds, id => _reportedFishHealth.Mock.Verify(repo => repo.Update(
            It.Is<ReportedFishHealthResult>(result =>
                result.Id == id && result.DraftReportId == null && result.Report == report)
        ), Times.Once));
    }

    public static TheoryData<DraftReport, IEnumerable<long>> OnApprovedData =>
        new()
        {
            {
                new DraftReport
                {
                    Id = 1
                },
                new []
                {
                    2L
                }
            },
            {
                new DraftReport
                {
                    Id = 2
                },
                new []
                {
                    1L, 3L
                }
            }
        };
}