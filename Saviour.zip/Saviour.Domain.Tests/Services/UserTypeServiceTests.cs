﻿using System.Security.Claims;
using Microsoft.Extensions.Options;
using Saviour.Domain.Auth;
using Saviour.Domain.Configuration;
using Saviour.Domain.Dto;
using Saviour.Domain.Services;

namespace Saviour.Domain.Tests.Services;

public class UserTypeServiceTests
{
    private readonly UserTypeService _service;

    private readonly AzureAdConfiguration _config = new()
    {
        TenantId = "David"
    };
    private readonly Mock<ClaimsPrincipal> _user = new();
    private string _userTenant = "David";
    
    private bool _hasAnalystRole;

    public UserTypeServiceTests()
    {
        _user.Setup(u => u.IsInRole(Roles.Analyst))
            .Returns(() => _hasAnalystRole);

        _user.Setup(u => u.FindFirst("tid"))
            .Returns(() => new Claim("tid", _userTenant));

        var configMock = new Mock<IOptionsSnapshot<AzureAdConfiguration>>();
        configMock.Setup(c => c.Value)
            .Returns(() => _config);

        _service = new UserTypeService(
            configMock.Object
        );
    }

    private UserType Get()
    {
        return _service.Get(_user.Object);
    }

    [Fact]
    public void IsAnalystWhenHasClaimIsTrue()
    {
        _hasAnalystRole = true;

        Assert.Equal(UserType.WellfishAnalyst, Get());
    }

    [Fact]
    public void IsCustomerWhenDoesNotHaveRole()
    {
        _hasAnalystRole = false;
        
        Assert.Equal(UserType.Customer, Get());
    }

    [Fact]
    public void IsCustomerWhenTenantDoesNotMatch()
    {
        _hasAnalystRole = true;
        _userTenant = "Flatmate";
        
        Assert.Equal(UserType.Customer, Get());
    }
}