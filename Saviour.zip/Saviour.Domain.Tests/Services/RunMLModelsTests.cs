﻿using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class RunMLModelsTests
{
    private readonly MLModel _model = new()
    {
        Id = 1
    };
    
    private MLInputData _mlInputData;
    private readonly Mock<IGetMLInputs> _getMlInputs = new();
    
    private readonly Mock<IMLModelService> _modelService = new();
    private readonly FakeRepository<Sample> _samplesRepository = new(new Dictionary<object, Sample>
    {
        [1L] = new()
        {
            Id = 1,
            BatchId = 2
        },
        [2L] = new()
        {
            Id = 2,
            BatchId = 2
        },
        [3L] = new()
        {
            Id = 3,
            BatchId = 1
        },
        // Will be ignored as it has an existing result
        [4L] = new()
        {
            Id = 4,
            BatchId = 1
        },
    });
    
    private readonly FakeRepository<FishHealthResult> _fishHealthResults = new(new Dictionary<object, FishHealthResult>
    {
        [1L] = new ()
        {
            ModelId = 1,
            SampleId = 4
        }
    });

    private readonly RunMLModels _runMLModels;

    public RunMLModelsTests()
    {
        _mlInputData = new MLInputData(_model, new List<MLSampleData>
            {
                new(1, new List<BiomarkerResultOnly>())
            },
            new List<MLBiomarker>()
        );
        
        var getMlModel = new Mock<IGetMLModel>();
        getMlModel.Setup(g => g.GetLatest(It.IsAny<MLModelType>()))
            .Returns(_model);

        _getMlInputs.Setup(g => g.Get(_model, It.IsAny<IQueryable<Sample>>()))
            .Returns(() => ValueTask.FromResult(_mlInputData));
        
        _runMLModels = new RunMLModels(
            _modelService.Object,
            _getMlInputs.Object,
            _samplesRepository.Mock.Object,
            _fishHealthResults.Mock.Object,
            getMlModel.Object
        );
    }

    [Theory]
    [MemberData(nameof(RunData))]
    public async Task Run_RunsService(Batch batch, IEnumerable<Sample> expectedSamples)
    {
        IEnumerable<Sample>? calledSamples = null;
        _getMlInputs.Setup(g => g.Get(_model, It.IsAny<IQueryable<Sample>>()))
            .Callback<MLModel, IQueryable<Sample>>((_, samples) => calledSamples = samples.ToList())
            .Returns(() => ValueTask.FromResult(_mlInputData));
        
        await _runMLModels.Run(MLModelType.FishHealth, batch);

        Assert.NotNull(calledSamples);
        Assert.Equivalent(expectedSamples, calledSamples);
        
        _modelService.Verify(m => m.Run(_mlInputData), Times.Once);
    }

    public static TheoryData<Batch, IEnumerable<Sample>> RunData => new()
    {
        {
            new Batch{ Id = 1 },
            new Sample[]
            {
                new()
                {
                    Id = 3,
                    BatchId = 1
                }
            }
        },
        {
            new Batch{ Id = 2 },
            new Sample[]
            {
                new()
                {
                    Id = 1,
                    BatchId = 2
                },
                new()
                {
                    Id = 2,
                    BatchId = 2
                }
            }
        },
        {
            new Batch{ Id = 3 },
            Array.Empty<Sample>()
        }
    };

    [Fact]
    public async Task Run_NoOpOnEmptyInputs()
    {
        _mlInputData = new MLInputData(_model, new List<MLSampleData>(), new List<MLBiomarker>());

        await _runMLModels.Run(MLModelType.FishHealth, new Batch{ Id = 1 });
        
        _modelService.VerifyNoOtherCalls();
    }
}
