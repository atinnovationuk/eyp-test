﻿using Microsoft.Extensions.Options;
using Saviour.Domain.Configuration;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;

namespace Saviour.Domain.Tests.Services;

public class MLModelServiceTests
{
    private readonly Mock<IMLRealtimeRequest> _mlRealtimeRequest = new();
    private readonly Mock<IMLResultsHandler> _mlResultsHandler = new();
    
    private readonly MLRealtimeConfiguration _configuration = new()
    {
        Model0ApiKey = "API",
        Model0EndPoint = "http://EndPoint"
    };
    private readonly HttpClient _httpClient = new();
    private readonly Stream _postResult = new MemoryStream();
    
    private readonly MLModelService _service;

    public MLModelServiceTests()
    {
        var mockSnapshot = new Mock<IOptionsSnapshot<MLRealtimeConfiguration>>();
        mockSnapshot.Setup(s => s.Value)
            .Returns(_configuration);

        var mockHttpFactory = new Mock<IHttpClientFactory>();
        mockHttpFactory.Setup(f => f.CreateClient(It.IsAny<string>()))
            .Returns(_httpClient);

        _mlRealtimeRequest.Setup(r => r.Post(_httpClient, It.IsAny<Uri>(), It.IsAny<MLInputData>()))
            .Returns(() => ValueTask.FromResult(_postResult));

        _service = new MLModelService(
            _mlRealtimeRequest.Object,
            _mlResultsHandler.Object,
            mockSnapshot.Object,
            mockHttpFactory.Object
        );
    }

    [Fact]
    public async Task Run_HandlesDataCorrectly()
    {
        var inputData = new MLInputData(new MLModel(), new List<MLSampleData>(), new List<MLBiomarker>());
        await _service.Run(inputData);

        var isAuthenticated = _httpClient.DefaultRequestHeaders.Authorization is { Scheme: "Bearer" } v
                   && v.Parameter == _configuration.Model0ApiKey;
        Assert.True(isAuthenticated, "Client not authenticated");
        
        _mlRealtimeRequest.Verify(r => r.Post(_httpClient, new Uri(_configuration.Model0EndPoint), inputData), Times.Once);
        
        _mlResultsHandler.Verify(handler => handler.InsertResults(inputData.Model, inputData.Samples, _postResult), Times.Once);
    }
}