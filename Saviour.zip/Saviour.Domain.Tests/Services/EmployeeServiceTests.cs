﻿using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class EmployeeServiceTests
{
    private readonly FakeRepository<Employee> _employees = new(new Dictionary<object, Employee>
    {
        [1] = new ()
        {
            Id = 1,
            Name = "Jim",
            CompanyId = "Jim's Company",
            LoginIdentity = "jim@jimco.com"
        },
        [2] = new ()
        {
            Id = 2,
            Name = "Karen",
            CompanyId = "Karen's Company",
            LoginIdentity = "karen@karenmail.co.uk"
        },
        [3] = new ()
        {
            Id = 3,
            Name = "Tim",
            CompanyId = "Jim's Company",
            LoginIdentity = "tim@jimco.com"
        }
    });
    private readonly MockUnitOfWork _unitOfWork = new ();

    private readonly EmployeeService _service;

    public EmployeeServiceTests()
    {
        _service = new EmployeeService(_employees.Mock.Object, _unitOfWork.UnitOfWork.Object);
    }

    [Theory]
    [MemberData(nameof(GetData))]
    public async Task Get_GetsForCompany(string companyId, IEnumerable<EmployeeDto> expectedResult)
    {
        var employees = await _service.Get(companyId).ToListAsync();

        Assert.Equal(expectedResult, employees);
    }

    public static TheoryData<string, IEnumerable<EmployeeDto>> GetData =>
        new()
        {
            {
                "Jim's Company", 
                new[]
                {
                    new EmployeeDto(1, "Jim", "jim@jimco.com"),
                    new EmployeeDto(3, "Tim", "tim@jimco.com"),
                }
            },
            {
                "Karen's Company", 
                new[]
                {
                    new EmployeeDto(2, "Karen", "karen@karenmail.co.uk")
                }
            },
            {
                "Enron",
                Array.Empty<EmployeeDto>()
            }
        };

    [Fact]
    public async Task Create_Inserts()
    {
        const string companyId = "company id";
        const string name = "Bob";
        const string identity = "bob@email.io";

        await _service.Create(companyId, new EmployeeDto(0, name, identity));

        _employees.Mock.Verify(r => r.InsertAsync(It.Is<Employee>(
            e => e.CompanyId == companyId && e.Name == name && e.LoginIdentity == identity
        )), Times.Once);
        
        _unitOfWork.VerifyChangesSaved();
    }

    [Fact]
    public async Task Update_UpdatesData()
    {
        const string name = "James";
        const string identity = "jim@jimco.org";

        await _service.Update(new EmployeeDto(1, name, identity));

        _employees.Mock.Verify(r => r.Update(It.Is<Employee>(
            e => e.Id == 1 && e.Name == name && e.LoginIdentity == identity
        )));
        
        _unitOfWork.VerifyChangesSaved();
    }

    [Fact]
    public async Task Update_ThrowsWhenNotFound()
    {
        await Assert.ThrowsAsync<EntityNotFoundException>(async () =>
            await _service.Update(new EmployeeDto(9001, "Vegeta", "vegeta@vegeta.com"))
        );
        
        _unitOfWork.VerifyChangesNotSaved();
    }

    [Theory]
    [InlineData(1)]
    [InlineData(2)]
    [InlineData(100)]
    public async Task Delete_Deletes(int id)
    {
        await _service.Delete(id);
        
        _employees.Mock.Verify(r => r.Delete(It.Is<Employee>(
            e => e.Id == id
        )));
        
        _unitOfWork.VerifyChangesSaved();
    }
}