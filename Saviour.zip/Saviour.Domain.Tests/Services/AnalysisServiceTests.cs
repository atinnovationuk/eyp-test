﻿using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class AnalysisServiceTests
{
    private readonly FakeRepository<Analysis> _analyses = new(new Dictionary<object, Analysis>
    {
        [1] = new()
        {
            Id = 1,
            MethodName = "Foo",
            BiomarkerRanges = new List<BiomarkerRange>
            {
                new()
                {
                    CountryCode = null,
                    Biomarker = new Biomarker
                    {
                        Name = "Sodium"
                    },
                    Min = 10,
                    Max = 20
                },
                new()
                {
                    CountryCode = "US",
                    Biomarker = new Biomarker
                    {
                        Name = "SODIUM"
                    },
                    Min = 5,
                    Max = 50
                },
                new()
                {
                    CountryCode = "GB",
                    Biomarker = new Biomarker
                    {
                        Name = "sodium"
                    },
                    Min = 9,
                    Max = 19
                },
                new()
                {
                    CountryCode = null,
                    Biomarker = new Biomarker
                    {
                        Name = "Potassium"
                    },
                    Min = 1,
                    Max = 2
                },
            }
        },
        [2] = new()
        {
            Id = 2,
            MethodName = "Bar",
            BiomarkerRanges = new List<BiomarkerRange>
            {
                new()
                {
                    CountryCode = null,
                    Biomarker = new Biomarker
                    {
                        Name = "Carbon"
                    },
                    Min = 5,
                    Max = 500
                },
                new()
                {
                    CountryCode = "GB",
                    Biomarker = new Biomarker
                    {
                        Name = "Carbon"
                    },
                    Min = 4,
                    Max = 501
                },
            }
        }
    });

    private readonly AnalysisService _service;

    public AnalysisServiceTests()
    {
        _service = new AnalysisService(_analyses.Mock.Object);
    }

    [Theory]
    [MemberData(nameof(GetAllCases))]
    public async Task GetAll_ReturnsCorrectResults(string countryCode, IEnumerable<AnalysisDto> expectedResult)
    {
        var allValues = await GetAll(countryCode);
        
        Assert.Equal(expectedResult, allValues);
    }

    public static TheoryData<string, IEnumerable<AnalysisDto>> GetAllCases =>
        new()
        {
            {
                "GB", new List<AnalysisDto>
                {
                    new(1, "Foo", new List<AnalysisBiomarkerDto>
                    {
                        new("sodium", 9, 0, 0, 0, 0, 19),
                        new("Potassium", 1, 0, 0, 0, 0, 2)
                    }),
                    new(2, "Bar", new List<AnalysisBiomarkerDto>
                    {
                        new("Carbon", 4, 0, 0, 0, 0, 501)
                    })
                }
            },
            {
                "US", new List<AnalysisDto>
                {
                    new(1, "Foo", new List<AnalysisBiomarkerDto>
                    {
                        new("SODIUM", 5, 0, 0, 0, 0, 50),
                        new("Potassium", 1, 0, 0, 0, 0, 2)
                    }),
                    new(2, "Bar", new List<AnalysisBiomarkerDto>
                    {
                        new("Carbon", 5, 0, 0, 0, 0, 500)
                    })
                }
            },
            {
                "ST", new List<AnalysisDto>
                {
                    new(1, "Foo", new List<AnalysisBiomarkerDto>
                    {
                        new("Sodium", 10, 0, 0, 0, 0, 20),
                        new("Potassium", 1, 0, 0, 0, 0, 2)
                    }),
                    new(2, "Bar", new List<AnalysisBiomarkerDto>
                    {
                        new("Carbon", 5, 0, 0, 0, 0, 500)
                    })
                }
            },
        };

    [Fact]
    public async Task GetAll_ThrowsExceptionWhenNoValidRangeAvailable()
    {
        _analyses.Items.Add(9001, new Analysis
        {
            Id = 9001,
            MethodName = "ThrowyTest",
            BiomarkerRanges = new List<BiomarkerRange>
            {
                new()
                {
                    Biomarker = new Biomarker
                    {
                        Name = "Radium"
                    },
                    CountryCode = "MU"
                }
            }
        });

        await Assert.ThrowsAsync<ArgumentException>(async () => await GetAll("SK"));
    }
    

    [Theory]
    [MemberData(nameof(GetCases))]
    public async Task Get_ReturnsCorrectResults(string countryCode, IEnumerable<int> ids, IEnumerable<AnalysisDto> expectedResult)
    {
        var values = await _service.Get(countryCode, ids).ToListAsync();
        
        Assert.Equal(expectedResult, values);
    }

    public static TheoryData<string, IEnumerable<int>, IEnumerable<AnalysisDto>> GetCases =>
        new()
        {
            {
                "GB",
                new []{ 1 },
                new List<AnalysisDto>
                {
                    new(1, "Foo", new List<AnalysisBiomarkerDto>
                    {
                        new("sodium", 9, 0, 0, 0, 0, 19),
                        new("Potassium", 1, 0, 0, 0, 0, 2)
                    })
                }
            },
            {
                "GB",
                new []{ 1, 2 },
                new List<AnalysisDto>
                {
                    new(1, "Foo", new List<AnalysisBiomarkerDto>
                    {
                        new("sodium", 9, 0, 0, 0, 0, 19),
                        new("Potassium", 1, 0, 0, 0, 0, 2)
                    }),
                    new(2, "Bar", new List<AnalysisBiomarkerDto>
                    {
                        new("Carbon", 4, 0, 0, 0, 0, 501)
                    })
                }
            },
            {
                "US",
                new []
                {
                    1, 2
                },
                new List<AnalysisDto>
                {
                    new(1, "Foo", new List<AnalysisBiomarkerDto>
                    {
                        new("SODIUM", 5, 0, 0, 0, 0, 50),
                        new("Potassium", 1, 0, 0, 0, 0, 2)
                    }),
                    new(2, "Bar", new List<AnalysisBiomarkerDto>
                    {
                        new("Carbon", 5, 0, 0, 0, 0, 500)
                    })
                }
            },
            {
                "ST",
                new []{ 1 },
                new List<AnalysisDto>
                {
                    new(1, "Foo", new List<AnalysisBiomarkerDto>
                    {
                        new("Sodium", 10, 0, 0, 0, 0, 20),
                        new("Potassium", 1, 0, 0, 0, 0, 2)
                    })
                }
            },
            {
                "ST",
                new []{ 2 },
                new List<AnalysisDto>
                {
                    new(2, "Bar", new List<AnalysisBiomarkerDto>
                    {
                        new("Carbon", 5, 0, 0, 0, 0, 500)
                    })
                }
            },
        };

    private ValueTask<List<AnalysisDto>> GetAll(string countryCode)
    {
        return _service.GetAll(countryCode).ToListAsync();
    }
}
