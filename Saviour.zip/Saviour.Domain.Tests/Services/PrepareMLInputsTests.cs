﻿using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;

namespace Saviour.Domain.Tests.Services;

public class PrepareMLInputsTests
{
    private readonly PrepareMLInputs _prepareMLInputs = new();

    [Fact]
    public void GetInputs_ReturnsExpected()
    {
        var inputData = new MLInputData(
            new MLModel(),
            new []
            {
                new MLSampleData
                ( 1,
                    new List<BiomarkerResultOnly>
                    {
                        new(1, 5),
                        new(2, 5),
                        new(3, 5),
                    }
                ),
                new MLSampleData
                ( 
                    2,
                    new List<BiomarkerResultOnly>
                    {
                        new(1, 9),
                        new(2, 49),
                        new(3, 99)
                    }
                )
            },
            new []
            {
                new MLBiomarker
                {
                    BiomarkerId = 1,
                    Min = 0,
                    Max = 10
                },
                new MLBiomarker
                {
                    BiomarkerId = 2,
                    Min = 5,
                    Max = 50
                },
                new MLBiomarker
                {
                    BiomarkerId = 3,
                    Min = 0,
                    Max = 100
                }
            }
        );

        var results = _prepareMLInputs.GetInputs(inputData).ToList();

        Assert.Equivalent(
            new[]
            {
                new SampleResults(
                    new []
                    {
                        0.5m,
                        0,
                        0.05m
                    }
                ),
                new SampleResults(
                    new []
                    {
                        0.9m,
                        44m / 45m,
                        0.99m
                    }
                )
            },
            results
        );
    }
}