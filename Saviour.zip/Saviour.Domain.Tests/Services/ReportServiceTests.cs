﻿using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class ReportServiceTests
{
    private readonly FakeRepository<Report> _reports = new(new Dictionary<object, Report>
    {
        [1L] = new()
        {
            Id = 1,
            CreatedById = 1,
            CreatedBy = new User
            {
                Id = 1
            },
            ReviewedBy = new User()
        }
    });
    
    private readonly FakeRepository<DraftReport> _draftReports = new(new Dictionary<object, DraftReport>
    {
        [2L] = new()
        {
            Id = 2,
            CreatedById = 42,
            CreatedBy = new User
            {
                Id = 42
            }
        },
        [3L] = new()
        {
            Id = 3,
            CreatedById = 1,
            CreatedBy = new User
            {
                Id = 1
            },
        },
        [44L] = new()
        {
            Id = 44,
            CreatedById = 1,
            CreatedBy = new User
            {
                Id = 1
            },
        },
    });

    private readonly FakeRepository<Site> _sites = new(new Dictionary<object, Site>
    {
        ["Site1"] = new()
        {
            Id = "Site1",
            GeneratedReportCount = 1
        }
    });

    private readonly FakeRepository<Batch> _batches = new(new Dictionary<object, Batch>
    {
        [1] = new()
        {
            Id = 1,
        },
        [2] = new()
        {
            Id = 2,
        },
        [3] = new()
        {
            Id = 3,
        }
    });

    private readonly FakeRepository<Analysis> _analyses = new(new Dictionary<object, Analysis>
    {
        [1] = new ()
        {
            Id = 1
        },
        [2] = new ()
        {
            Id = 2
        }
    });

    private readonly Mock<IReportStorage> _reportStorage = new();
    private readonly Mock<IMLReportingService> _mlReportingService = new();

    private readonly ReportService _service;

    private readonly User _user = new()
    {
        Id = 1,
        Name = "Kay",
        AzureId = "Oh, ID?"
    };
    private readonly Mock<Stream> _file = new();

    public ReportServiceTests()
    {
        _service = new ReportService(_reports.Mock.Object, _draftReports.Mock.Object, _sites.Mock.Object,
            _batches.Mock.Object, _analyses.Mock.Object, _reportStorage.Object, _mlReportingService.Object);
    }

    [Fact]
    public async Task Create_ThrowsWhenAnyBatchNotFound()
    {
        await Assert.ThrowsAsync<EntitiesNotFoundException>(async () => await Create(new NewReport("Observations",
            "Site1",
            new List<long>
            {
                1, 2, 3, 4
            },
            new List<int>
            {
                1, 2
            },
            "Process Deviations"
            )));
    }

    [Fact]
    public async Task Create_ThrowsWhenAnyAnalysisNotFound()
    {
        await Assert.ThrowsAsync<EntitiesNotFoundException>(async () => await Create(new NewReport("Observations",
            "Site1",
            new List<long>
            {
                1
            },
            new List<int>
            {
                1, 2, 404
            },
            "Process Deviations"
        )));
    }

    [Fact]
    public async Task Create_ThrowsWhenSiteNotFound()
    {
        await Assert.ThrowsAsync<EntityNotFoundException>(async () => await Create(new NewReport("Observations",
            "Site2",
            new List<long>
            {
                1
            }, 
            new List<int>
            {
                1
            },
            "Process Deviations")));
    }

    [Fact]
    public async Task Create_InsertsWhenValid()
    {
        var data = MakeValidReport();
        await Create(data);

        var site = _sites.Items["Site1"];

        _draftReports.Mock.Verify(repo => repo.InsertAsync(It.Is<DraftReport>(
            report => report.Site == site
            && report.CreatedBy.AzureId == _user.AzureId
            && report.Observations == data.Observations
            && report.Batches.SequenceEqual(new []
                {
                    _batches.Items[1],
                    _batches.Items[2],
                    _batches.Items[3]
                }
            )
            && report.Analyses.SequenceEqual(new []
                {
                    _analyses.Items[1],
                    _analyses.Items[2]
                }
            )
        )));
        _mlReportingService.Verify(service => service.OnCreated(It.IsAny<DraftReport>()), Times.Once);

        _sites.Mock.Verify(r => r.Update(site));
        Assert.Equal(2, site.GeneratedReportCount);
    }

    private static NewReport MakeValidReport()
        => new("Observations", "Site1", new List<long>
            {
                1, 2, 3
            },
            new List<int>
            {
                1, 2
            },
            "Process Deviations");

    private ValueTask<DraftReport> Create(NewReport data) => _service.Create(data, _user);

    [Theory]
    [InlineData(1)]
    public async Task Get_FindsExistingItems(long id)
    {
        var report = await _service.Get(id);

        Assert.Same(_reports.Items[id], report);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(44)]
    [InlineData(200_000)]
    public async Task Get_ReturnsNullOnNotFound(long id)
    {
        var report = await _service.Get(id);

        Assert.Null(report);
    }

    [Theory]
    [InlineData(2)]
    [InlineData(3)]
    [InlineData(44)]
    public async Task GetDraft_FindsExistingItems(long id)
    {
        var report = await _service.GetDraft(id);

        Assert.Same(_draftReports.Items[id], report);
    }

    [Theory]
    [InlineData(0)]
    [InlineData(1)]
    [InlineData(20)]
    [InlineData(200_000)]
    public async Task GetDraft_ReturnsNullOnNotFound(long id)
    {
        var report = await _service.GetDraft(id);

        Assert.Null(report);
    }

    private ValueTask<Report?> Approve(long reportId) => _service.Approve(reportId, _user, _file.Object);

    [Fact]
    public async Task Approve_ThrowsWhenNotFound()
    {
        await Assert.ThrowsAsync<EntityNotFoundException>(async () => await Approve(0));
        VerifyReportNotSaved();
    }

    [Theory]
    [InlineData(1, 3)]
    [InlineData(1, 44)]
    [InlineData(42, 2)]
    public async Task Approve_ReturnsNullWhenCreatedByReviewer(int userId, long reportId)
    {
        _user.Id = userId;

        Assert.Null(await Approve(reportId));
        VerifyReportNotSaved();
    }

    private void VerifyReportNotSaved()
    {
        _reportStorage.Verify(r => r.Save(It.IsAny<Stream>(), It.IsAny<Report>()), Times.Never);
        _mlReportingService.Verify(service => service.OnApproved(It.IsAny<DraftReport>(), It.IsAny<Report>()), Times.Never);
    }

    [Fact]
    public async Task Approve_TransfersWhenValid()
    {
        const int reportId = 2;
        var report = await Approve(reportId);
        Assert.NotNull(report);
        
        _draftReports.Mock.Verify(repo => repo.Delete(It.Is<DraftReport>(draft => draft.Id == reportId)));
        _reports.Mock.Verify(r => r.InsertAsync(report));

        _mlReportingService.Verify(service => service.OnApproved(It.IsAny<DraftReport>(), It.IsAny<Report>()), Times.Once);
        _reportStorage.Verify(r => r.Save(_file.Object, report), Times.Once);
    }

    [Fact]
    public async ValueTask Delete_DeletesWhenFound()
    {
        await _service.Delete(2);

        _draftReports.Mock.Verify(r => r.Delete(_draftReports.Items[2L]), Times.Once);
    }

    [Fact]
    public async ValueTask Delete_NoOpWhenNotFound()
    {
        await _service.Delete(666);

        _draftReports.Mock.Verify(r => r.Delete(It.IsAny<DraftReport>()), Times.Never);
    }
}
