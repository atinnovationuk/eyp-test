﻿using System.Security.Claims;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class AccessServiceTests
{
    private readonly AccessService _accessService;

    private UserType _userType = UserType.WellfishAnalyst;

    private readonly FakeRepository<Employee> _employees = new(new Dictionary<object, Employee>
    {
        [1] = new ()
        {
            CompanyId = "Come Pan A",
            LoginIdentity = "james@teflon.com"
        },
        [2] = new ()
        {
            CompanyId = "Come Pan A",
            LoginIdentity = "bobby@teflon.com"
        },
        [3] = new ()
        {
            CompanyId = "Come Pan Eh",
            LoginIdentity = "janet@teflon.ca"
        }
    });

    private readonly Mock<ClaimsPrincipal> _user = new();
    private Claim? _userPrincipal;

    public AccessServiceTests()
    {
        _user.Setup(u => u.FindFirst(ClaimTypes.Upn))
            .Returns(() => _userPrincipal);

        var userTypeMock = new Mock<IUserTypeService>();
        userTypeMock.Setup(u => u.Get(_user.Object))
            .Returns(() => _userType);

        _accessService = new AccessService(userTypeMock.Object, _employees.Mock.Object);
    }

    private void SetUserId(string id)
    {
        _userPrincipal = new Claim(ClaimTypes.Upn, id);
    }

    private ValueTask<bool> CanAccess(string companyId) => _accessService.CanAccessCompanyData(_user.Object, companyId);

    [Theory]
    [InlineData(UserType.Customer, "", "", false)]
    [InlineData(UserType.Customer, "", "Come Pan A", false)]
    [InlineData(UserType.Customer, "janet@teflon.ca", "Come Pan A", false)]
    [InlineData(UserType.Customer, "james@teflon.com", "Come Pan A", true)]
    [InlineData(UserType.Customer, "bobby@teflon.com", "Come Pan A", true)]
    [InlineData(UserType.Customer, "janet@teflon.ca", "Come Pan Eh", true)]
    [InlineData(UserType.Customer, "james@teflon.com", "Come Pan Eh", false)]
    [InlineData(UserType.Customer, "bobby@teflon.com", "Come Pan Eh", false)]
    [InlineData(UserType.WellfishAnalyst, "", "", true)]
    [InlineData(UserType.WellfishAnalyst, "", "Come Pan A", true)]
    [InlineData(UserType.WellfishAnalyst, "janet@teflon.ca", "Come Pan A", true)]
    [InlineData(UserType.WellfishAnalyst, "james@teflon.com", "Come Pan A", true)]
    [InlineData(UserType.WellfishAnalyst, "bobby@teflon.com", "Come Pan A", true)]
    [InlineData(UserType.WellfishAnalyst, "janet@teflon.ca", "Come Pan Eh", true)]
    [InlineData(UserType.WellfishAnalyst, "james@teflon.com", "Come Pan Eh", true)]
    [InlineData(UserType.WellfishAnalyst, "bobby@teflon.com", "Come Pan Eh", true)]
    public async Task ReturnsExpectedAccess(UserType userType, string userId, string companyId, bool expectedResult)
    {
        _userType = userType;

        SetUserId(userId);

        var canAccess = await CanAccess(companyId);
        Assert.Equal(expectedResult, canAccess);
    }
}