﻿using Saviour.Domain.Entities;
using Saviour.Domain.Services;

namespace Saviour.Domain.Tests.Services;

public class MLResultsReaderTests
{
    private readonly MLResultsReader _resultsReader = new();

    [Fact]
    public void ReadFishHealthResults_ReturnsExpected()
    {
        using var stream = GetStream("[0.0,2.0,0,2,2,0.0]");

        var results = _resultsReader.ReadFishHealthResults(stream);

        Assert.Equal(new[]
            {
                FishHealthResultType.Healthy,
                FishHealthResultType.Unhealthy,
                FishHealthResultType.Healthy,
                FishHealthResultType.Unhealthy,
                FishHealthResultType.Unhealthy,
                FishHealthResultType.Healthy
            },
            results);
    }
    
    [Fact]
    public void ReadFishHealthResults_ThrowsOnUnexpectedJson()
    {
        using var stream = GetStream(@"[""oops"",0.0]");

        Assert.ThrowsAny<Exception>(() => _resultsReader.ReadFishHealthResults(stream));
    }

    private static MemoryStream GetStream(string json)
    {
        var stream = new MemoryStream();
        using var writer = new StreamWriter(stream, leaveOpen: true);
        writer.AutoFlush = true;
        writer.WriteLine(json);

        stream.Position = 0;
        return stream;
    }
}
