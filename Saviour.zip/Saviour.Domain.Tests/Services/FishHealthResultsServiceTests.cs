﻿using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class FishHealthResultsServiceTests
{
    private const string SiteId = "test";

    private readonly FakeRepository<FishHealthResult> _fishHealthResults = new(new Dictionary<object, FishHealthResult>
    {
        [1] = new ()
        {
            Id = 1,
            Model = new MLModel(),
            Sample = new Sample
            {
                Id = 1,
                Pen = "1",
                Batch =
                    new Batch{
                        SiteId = SiteId,
                        Id = 1
                    }
            },
            Result = FishHealthResultType.Healthy
        },
        [2] = new ()
        {
            Id = 1,
            Model = new MLModel(),
            Sample = new Sample
            {
                Id = 1,
                Pen = "1",
                Batch =
                    new Batch{
                        SiteId = SiteId,
                        Id = 1
                    }
            },
            Result = FishHealthResultType.Healthy
        },
        [3] = new ()
        {
            Id = 1,
            Model = new MLModel(),
            Sample = new Sample
            {
                Id = 1,
                Pen = "1",
                Batch =
                    new Batch {
                        SiteId = SiteId,
                        Id = 1
                    }
            },
            Result = FishHealthResultType.Unhealthy
        },
        [4] = new ()
        {
            Id = 1,
            Model = new MLModel(),
            Sample = new Sample
            {
                Id = 1,
                Pen = "1",
                Batch =
                    new Batch{
                        SiteId = SiteId,
                        Id = 1
                    }
            },
            Result = FishHealthResultType.Unhealthy
        },
        [5] = new ()
        {
            Id = 1,
            Model = new MLModel(),
            Sample = new Sample
            {
                Id = 1,
                Pen = "2",
                Batch =
                    new Batch{
                        SiteId = SiteId,
                        Id = 1
                    }
            },
            Result = FishHealthResultType.Healthy
        },
        [6] = new ()
        {
            Id = 1,
            Model = new MLModel(),
            Sample = new Sample
            {
                Id = 1,
                Pen = "2",
                Batch =
                    new Batch{
                        SiteId = SiteId,
                        Id = 1
                    }
            },
            Result = FishHealthResultType.Healthy
        },
        [7] = new ()
        {
            Id = 1,
            Model = new MLModel(),
            Sample = new Sample
            {
                Id = 1,
                Pen = "2",
                Batch =
                    new Batch{
                        SiteId = SiteId,
                        Id = 1
                    }
            },
            Result = FishHealthResultType.Healthy
        },
        [8] = new ()
        {
            Id = 1,
            Model = new MLModel(),
            Sample = new Sample
            {
                Id = 1,
                Pen = "2",
                Batch =
                    new Batch{
                        SiteId = SiteId,
                        Id = 1
                    }
            },
            Result = FishHealthResultType.Unhealthy
        },
    });
    
    private readonly IFishHealthResultsService _service;
    
    public FishHealthResultsServiceTests()
    {
        _service = new FishHealthResultsService(_fishHealthResults.Mock.Object);   
    }

    [Fact]
    public async Task GetPenFishHealthResults_Returns_CorrectData()
    {
        var expectedResult = new List<BatchFishHealthResultDto>()
        {
            new BatchFishHealthResultDto(1, new Dictionary<string, decimal>
            {
                ["1"] = 50,
                ["2"] = 75
            }),
        };

        var result = (await _service.GetPenFishHealthResults("test")).ToList();
        
        Assert.Equal(1, result[0].batchId);
        Assert.Equivalent(expectedResult[0].penFishHealthResults, result[0].penFishHealthResults);
    }
}