﻿using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class BatchServiceTests
{
    private static readonly MLModel MLModel1 = new()
    {
        Version = 1
    };
    private static readonly MLModel MLModel2 = new()
    {
        Version = 2
    };
    
    private static List<Sample> Batch1Samples => new()
    {
        FakeSample(1, 1, "Sample 1", new List<FishHealthResult>
        {
            new()
            {
                Result = FishHealthResultType.Healthy,
                Model = MLModel1
            },
            new()
            {
                Result = FishHealthResultType.Unhealthy,
                Model = MLModel2
            }
        }),
        FakeSample(2, 1, "Sample 2", new List<FishHealthResult>
        {
            new ()
            {
                Result = FishHealthResultType.Healthy,
                Model = MLModel1
            }
        }),
        FakeSample(6, 1, "Sample 6"),
        FakeSample(8, 1, "Sample Ate", new List<FishHealthResult>
        {
            new()
            {
                Result = FishHealthResultType.Unhealthy,
                Model = MLModel2
            }
        }),
    };
    
    private static List<Sample> Batch2Samples => new()
    {
        FakeSample(3, 2, "Sample 3"),
        FakeSample(5, 2, "Sample 5")
    };

    private static List<Sample> Batch3Samples => new()
    {
        FakeSample(4, 3, "Sample 4"),
        FakeSample(7, 3, "Sample 7")
    };

    private static List<Sample> Batch4Samples => new()
    {
        FakeSample(9, 4, "Sample 9", 
            new List<FishHealthResult>(),
            new List<BiomarkerResult>
            {
                new()
                {
                    Result = 10,
                    Biomarker = new Biomarker
                    {
                        Name = "Biomarker 1"
                    }
                },
                new()
                {
                    Result = 11,
                    Biomarker = new Biomarker
                    {
                        Name = "Biomarker 2",
                        Parent = new Biomarker
                        {
                            Name = "Biomarker 3"
                        }
                    }
                },
                new()
                {
                    Result = 12,
                    Biomarker = new Biomarker
                    {
                        Name = "Biomarker 4",
                        Parent = new Biomarker
                        {
                            Name = "Biomarker 5",
                            Parent = new Biomarker
                            {
                                Name = "Biomarker 6",
                            }
                        }
                    }
                }
            })
    };

    private readonly FakeRepository<Batch> _batches = new(
        new Dictionary<object, Batch>
        {
            [1L] = new()
            {
                Id = 1,
                BatchNumber = "Batch 1",
                Site = new Site
                {
                    Id = "Site A",
                    CompanyId = "Company A"
                },
                SiteId = "Site A",
                FishHealthHistory = "Batch1 fish health history",
                ConfirmedCondition = "Batch1 condition",
                Samples = Batch1Samples
            },
            [2L] = new()
            {
                Id = 2,
                BatchNumber = "Batch 2",
                Site = new Site
                {
                    Id = "Site B",
                    CompanyId = "Company A"
                },
                SiteId = "Site B",
                FishHealthHistory = "Batch2 fish health history",
                ConfirmedCondition = "Batch2 condition",
                Samples = Batch2Samples
            },
            [3L] = new()
            {
                Id = 3,
                BatchNumber = "Batch 3",
                Site = new Site
                {
                    Id = "Site A",
                    CompanyId = "Company A"
                },
                SiteId = "Site A",
                FishHealthHistory = "Batch3 fish health history",
                ConfirmedCondition = "Batch3 condition",
                Samples = Batch3Samples
            },
            [4L] = new()
            {
                Id = 4,
                BatchNumber = "Batch 4",
                Site = new Site
                {
                    Id = "Site D",
                    CompanyId = "Company E"
                },
                SiteId = "Site D",
                FishHealthHistory = "Batch4 fish health history",
                ConfirmedCondition = "Batch4 condition",
                Samples = Batch4Samples
            }
        }
    );

    private readonly BatchService _batchService;

    public BatchServiceTests()
    {
        _batchService = new BatchService(_batches.Mock.Object);
    }

    [Theory]
    [MemberData(nameof(GetBatchesData))]
    public async Task GetBatches_FindsCorrectValues(string siteId, List<BatchDto> expectedResult)
    {
        var batches = await _batchService.GetBatches(siteId).ToListAsync();

        Assert.Equal(expectedResult, batches);
    }

    private static IReadOnlyList<SampleDto> ConvertSamples(IEnumerable<Sample> samples, IReadOnlyList<FishHealthResultType?> fishHealthResults)
    {
        return samples.Select((sample, i) => FakeSampleDto(sample, fishHealthResults[i])).ToList();
    }

    private static IReadOnlyList<SampleDto> ConvertSamples(IEnumerable<Sample> samples)
    {
        return samples.Select(sample => FakeSampleDto(sample, null)).ToList();
    }

    public static TheoryData<string, List<BatchDto>> GetBatchesData => new()
    {
        {
            "Site A",
            new List<BatchDto>
            {
                new(1, "Batch 1", new DateOnly(), new DateTime(),new DateTime(), "Company A", "Site A",
                    "Batch1 condition","Batch1 fish health history",
                    ConvertSamples(Batch1Samples, new FishHealthResultType?[]
                    {
                        FishHealthResultType.Unhealthy,
                        FishHealthResultType.Healthy,
                        null,
                        FishHealthResultType.Unhealthy
                    })
                ),
                new(3, "Batch 3", new DateOnly(), new DateTime(),new DateTime(), "Company A", "Site A",
                    "Batch3 condition","Batch3 fish health history",
                    ConvertSamples(Batch3Samples)
                )
            }
        },
        {
            "Site B",
            new List<BatchDto>
            {
                new(2, "Batch 2", new DateOnly(), new DateTime(),new DateTime(), "Company A", "Site B",
                    "Batch2 condition","Batch2 fish health history",
                    ConvertSamples(Batch2Samples))
            }
        },
        {
            // Test that biomarkers are grouped by their top-most parent
            "Site D",
            new List<BatchDto>
            {
                new(4, "Batch 4", new DateOnly(), new DateTime(),new DateTime(), "Company E", "Site D",
                    "Batch4 condition","Batch4 fish health history", 
                    new []
                    {
                        FakeSampleDto(FakeSample(4, 3, "Sample 9",
                            new List<FishHealthResult>(),
                            new List<BiomarkerResult>
                        {
            
                            new ()
                            {
                                Result = 10,
                                Biomarker = new Biomarker
                                {
                                    Name = "Biomarker 1"
                                }
                            },
                            new ()
                            {
                                Result = 11,
                                Biomarker = new Biomarker
                                {
                                    Name = "Biomarker 3"
                                }
                            },
                            new ()
                            {
                                Result = 12,
                                Biomarker = new Biomarker
                                {
                                    Name = "Biomarker 6"
                                }
                            }
                        }), 
                            null)
                    })
            }
        },
        {
            "Site 404", new List<BatchDto>()
        }
    };

    private static SampleDto FakeSampleDto(Sample sample, FishHealthResultType? fishHealthResult) =>
        SampleDto.FromSample(sample, _ => fishHealthResult is null
            ? null
            : new FishHealthResult
            {
                Result = fishHealthResult.Value
            });

    private static Sample FakeSample(long id, long batchId, string sampleCode)
        => FakeSample(id, batchId, sampleCode, new List<FishHealthResult>(), new List<BiomarkerResult>());
    
    private static Sample FakeSample(long id, long batchId, string sampleCode, ICollection<FishHealthResult> fishHealthResults)
        => FakeSample(id, batchId, sampleCode, fishHealthResults, new List<BiomarkerResult>());

    private static Sample FakeSample(long id, long batchId, string sampleCode, ICollection<FishHealthResult> fishHealthResults, ICollection<BiomarkerResult> biomarkerResults)
        => new()
        {
            Id = id,
            BatchId = batchId,
            Batch = new Batch
            {
                Id = batchId,
                Site = new Site
                {
                    Id = "Site",
                    CompanyId = "Company"
                }
            },
            SampleCode = sampleCode,
            Instrument = "Violin",
            Species = "Fish",
            Hatcheries = new List<Hatchery>
            {
                new()
                {
                    HatcheryCode = "Hatchery"
                }
            },
            BiomarkerResults = biomarkerResults,
            FishHealthResults = fishHealthResults
        };
}
