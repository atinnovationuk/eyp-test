﻿using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class GetBatchesNeedingMLTests
{
    private readonly MLModel _model = new()
    {
        Id = 1
    };

    private readonly FakeRepository<Batch> _batches = new(new Dictionary<object, Batch>
    {
        // Update needed - no samples have results
        [1L] = new()
        {
            Id = 1,
            Samples = new List<Sample>
            {
                new()
                {
                    FishHealthResults = new List<FishHealthResult>()
                },
                new()
                {
                    FishHealthResults = new List<FishHealthResult>()
                }
            }
        },
        // No update needed - all samples up to date
        [2L] = new()
        {
            Id = 2,
            Samples = new List<Sample>
            {
                new()
                {
                    FishHealthResults = new List<FishHealthResult>
                    {
                        new()
                        {
                            ModelId = 1
                        },
                        new()
                        {
                            ModelId = 1
                        }
                    }
                },
                new()
                {
                    FishHealthResults = new List<FishHealthResult>
                    {
                        new()
                        {
                            ModelId = 1
                        }
                    }
                }
            }
        },
        // Needs update - only run against a different model
        [3L] = new()
        {
            Id = 3,
            Samples = new List<Sample>
            {
                new()
                {
                    FishHealthResults = new List<FishHealthResult>
                    {
                        new()
                        {
                            ModelId = 2
                        }
                    }
                }
            }
        },
        // Update needed - one sample missing results
        [4L] = new()
        {
            Id = 4,
            Samples = new List<Sample>
            {
                new()
                {
                    FishHealthResults = new List<FishHealthResult>
                    {
                        new()
                        {
                            ModelId = 1
                        }
                    }
                },
                new()
                {
                    FishHealthResults = new List<FishHealthResult>
                    {
                        new()
                        {
                            ModelId = 1
                        }
                    }
                },
                new()
                {
                    FishHealthResults = new List<FishHealthResult>()
                }
            }
        }
    });

    private readonly GetBatchesNeedingML _getBatches;

    public GetBatchesNeedingMLTests()
    {
        var getMlModel = new Mock<IGetMLModel>();
        getMlModel.Setup(g => g.GetLatest(It.IsAny<MLModelType>()))
            .Returns(() => _model);

        _getBatches = new GetBatchesNeedingML(_batches.Mock.Object, getMlModel.Object);
    }

    [Fact]
    public async Task Get_ReturnsExpected()
    {
        var batches = await _getBatches.Get().ToListAsync();
        
        Assert.Equal(
            new long[]
            {
                1,
                3,
                4
            },
            batches.Select(b => b.Id)
        );
    }
}