﻿using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class CompanyServiceTests
{
    private readonly FakeRepository<Company> _companies = new(
        new Dictionary<object, Company>
        {
            ["1"] = new()
            {
                Id = "1",
                CompanyName = "ACME"
            },
            ["2"] = new()
            {
                Id = "2",
                CompanyName = "Evil Inc"
            }
        }
    );

    private readonly FakeRepository<Site> _sites = new(
        new Dictionary<object, Site>
        {
            ["1"] = new()
            {
                Id = "1",
                SiteName = "Site 1",
                CompanyId = "1",
                CountryCode = "US"
            },
            ["2"] = new()
            {
                Id = "2",
                SiteName = "Site A",
                CompanyId = "1",
                CountryCode = "GB"
            },
            ["3"] = new()
            {
                Id = "3",
                SiteName = "Volcano Base",
                CompanyId = "2",
                CountryCode = "IS"
            },
            ["4"] = new()
            {
                Id = "4",
                SiteName = "Site Alpha",
                CompanyId = "1",
                CountryCode = "TH"
            }
        }
    );

    private readonly MockUnitOfWork _unitOfWork = new();

    private readonly CompanyService _service;

    public CompanyServiceTests()
    {
        _service = new CompanyService(_companies.Mock.Object, _sites.Mock.Object, _unitOfWork.UnitOfWork.Object);
    }

    [Fact]
    public async Task GetCompaniesAsync_ReturnsAll()
    {
        var companies = await _service.GetCompaniesAsync().ToListAsync();

        Assert.Equal(_companies.Items.Values.Select(CompanyDto.FromCompany), companies);
    }

    [Theory]
    [MemberData(nameof(GetSitesData))]
    public async Task GetSitesForCompanyAsync_(string companyId, IEnumerable<SiteDto> expectedSites)
    {
        var sites = await _service.GetSitesForCompanyAsync(companyId).ToListAsync();
        
        Assert.Equal(expectedSites, sites);
    }

    [Fact]
    public async Task Create_CreatesCompany()
    {
        const string id = "NewCompanyId";
        const string name = "New Company Name";
        const string address = "123 Fake Street";

        _companies.Mock.Setup(r => r.InsertAsync(It.IsAny<Company>()))
            .Returns(() => ValueTask.FromResult(new Company()));
        
        await _service.Create(new EditCompanyDto(id, name, address));

        _companies.Mock.Verify(r => r.InsertAsync(It.Is<Company>(
            c => c.Id == id && c.CompanyName == name && c.Address == address
        )));
        _unitOfWork.VerifyChangesSaved();
    }

    public static TheoryData<string, IEnumerable<SiteDto>> GetSitesData => new()
    {
        {
            "1",
            new[]
            {
                new SiteDto("1", "Site 1", "1", "US"),
                new SiteDto("2", "Site A", "1", "GB"),
                new SiteDto("4", "Site Alpha", "1", "TH")
            }
        },
        {
            "2",
            new[]
            {
                new SiteDto("3", "Volcano Base", "2", "IS")
            }
        },
        {
            "Does Not Exist",
            Array.Empty<SiteDto>()
        }
    };

    [Fact]
    public async Task Update_Updates()
    {
        const string id = "1";
        const string companyName = "ACME Inc";
        const string address = "99 Looney Way";

        await _service.Update(new EditCompanyDto(id, companyName, address));

        _companies.Mock.Verify(repo => repo.Update(It.Is<Company>(
            c => c.Id == id && c.CompanyName == companyName && c.Address == address
        )));

        _unitOfWork.VerifyChangesSaved();
    }

    [Fact]
    public async Task Update_ThrowsIfCompanyNotFound()
    {
        await Assert.ThrowsAsync<EntityNotFoundException>(async () =>
            await _service.Update(new EditCompanyDto("Enron", "Name", "Address")));
        
        _unitOfWork.VerifyChangesNotSaved();
    }
}