using System.Linq.Expressions;
using MockQueryable.Moq;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class SampleServiceTests
{
    private readonly Mock<IRepository<Sample>> _samples = new();
    private readonly Mock<IRepository<Company>> _companies = new();
    private readonly Mock<IRepository<Site>> _sites = new();
    private readonly Mock<IRepository<Biomarker>> _biomarkers = new();
    private readonly Mock<IRepository<Hatchery>> _hatcheries = new();
    private readonly Mock<IRepository<Batch>> _batches = new();
    private readonly Mock<IRepository<Country>> _countries = new();
    private readonly MockUnitOfWork _unitOfWork;
    private readonly Mock<IBatchListener> _batchListener = new();
    
    private readonly SampleService _sampleService;
    
    private readonly Sample _sample = new()
    {
        Id = 1,
        SampleCode = "TEST-SAMPLE",
        Instrument = "TEST-INSTRUMENT",
        Batch = new Batch
        {
            BatchNumber = "TEST-BATCHNO",
            Site = new Site
            {
                Id = "TEST-SITE",
                Company = new Company
                {
                    Id = "TEST",
                    CompanyName = "TEST-COMPANY"
                }
            },
            DateAnalysed = new DateTime(1999, 9, 9),
            DateCollected = new DateOnly(1999, 9, 8)
        },
        Pen = "TEST-PEN",
        Hatcheries = new List<Hatchery>(),
        BiomarkerResults = new List<BiomarkerResult>()
    };
    
    private readonly UploadSampleDto _uploadSample;

    public SampleServiceTests()
    {
        _unitOfWork = new MockUnitOfWork();
        _sampleService = new SampleService(_samples.Object, _companies.Object,
            _sites.Object, _batches.Object, _countries.Object, _biomarkers.Object, _hatcheries.Object,
            _unitOfWork.UnitOfWork.Object, _batchListener.Object);
        
        _uploadSample = new UploadSampleDto
        {
            CompanyCode = _sample.Batch.Site.Company.Id,
            CompanyName = _sample.Batch.Site.Company.CompanyName,
            SiteCode = _sample.Batch.Site.Id,
            SiteName = _sample.Batch.Site.SiteName,
            CountryCode = "IO",
            BatchNumber = _sample.Batch.BatchNumber,
            DateAnalysed = _sample.Batch.DateAnalysed,
            DateCollected = _sample.Batch.DateCollected,
            Hatcheries = new List<string>(),
            BiomarkerResults = new List<BiomarkerResultDto>()
        };

        _samples.Setup(x => x.InsertAsync(It.IsAny<Sample>())).ReturnsAsync(_sample);
        
        _batches.Setup(b => b.FindOrCreateAsync(It.IsAny<Func<Task<Batch?>>>(), It.IsAny<Func<Task<Batch>>>()))
            .ReturnsAsync(_sample.Batch);
        
        _companies.Setup(r => r.FindByIdOrCreateAsync(_uploadSample.CompanyCode, It.IsAny<Func<Task<Company>>>()))
            .ReturnsAsync(_sample.Batch.Site.Company);
        _sites.Setup(r => r.FindByIdOrCreateAsync(_uploadSample.SiteCode, It.IsAny<Func<Task<Site>>>()))
            .ReturnsAsync(_sample.Batch.Site);

        _biomarkers.Setup(b => b.FindAsync(It.IsAny<Expression<Func<Biomarker, bool>>>()))
            .Returns(Array.Empty<Biomarker>().BuildMock());
    }
    
    [Fact]
    public async Task AddSampleAsync_Looks_Up_Company_And_Site()
    {
        await AddSampleAsync();

        _samples.Verify(x => x.InsertAsync(It.Is<Sample>(s => s.Batch == _sample.Batch)), Times.Once);
        _unitOfWork.VerifyChangesSaved();
        _batchListener.Verify(b => b.OnBatchUpdated(_sample.Batch), Times.Once);
    }
    
    [Fact]
    public async Task AddSampleAsync_Disposes_Transaction()
    {
        await AddSampleAsync();

        _unitOfWork.UnitOfWork.Verify(u => u.BeginTransaction(), Times.Once);
        _unitOfWork.Transaction.Verify(t => t.Dispose(), Times.Once);
    }

    [Fact]
    public async Task AddSampleAsync_CreatesCompanyAndSiteIfBatchNotFound()
    {
        Func<Task<Batch>>? createFunction = null;
        _batches.Setup(b => b.FindOrCreateAsync(It.IsAny<Func<Task<Batch?>>>(), It.IsAny<Func<Task<Batch>>>()))
            .Callback<Func<Task<Batch?>>, Func<Task<Batch>>>((_, create) => createFunction = create);

        await AddSampleAsync();

        Assert.NotNull(createFunction);

        await createFunction();

        _companies.Verify(x => x.FindByIdOrCreateAsync(_uploadSample.CompanyCode, It.IsAny<Func<Task<Company>>>()),
            Times.Once);
        _sites.Verify(x => x.FindByIdOrCreateAsync(_uploadSample.SiteCode, It.IsAny<Func<Task<Site>>>()), Times.Once);
        _countries.Verify(x => x.FindByIdOrCreateAsync(_uploadSample.CountryCode, It.IsAny<Func<Task<Country>>>()), Times.Once);
        _batches.Verify(r => r.FindOrCreateAsync(It.IsAny<Func<Task<Batch?>>>(), It.IsAny<Func<Task<Batch>>>()), Times.Once);
    }

    [Fact]
    public async Task AddSampleAsync_Inserts_Missing_Biomarkers()
    {
        _uploadSample.BiomarkerResults.Add(new BiomarkerResultDto("Sodium", 12));
        _uploadSample.BiomarkerResults.Add(new BiomarkerResultDto("Potassium", 1.2M));
        _uploadSample.BiomarkerResults.Add(new BiomarkerResultDto("Caesium",0.12M));

        await AddSampleAsync();

        _biomarkers.Verify(r => 
            r.FindOrCreateAsync(It.IsAny<Func<Task<Biomarker?>>>(), It.IsAny<Func<Task<Biomarker>>>()),
            Times.Exactly(3));
        
        _samples.Verify(x => x.InsertAsync(It.Is<Sample>(s => s.BiomarkerResults.Count == 3)), Times.Once);
    }

    [Fact]
    public async Task AddSampleAsync_Does_Not_Insert_Present_Biomarkers()
    {
        _uploadSample.BiomarkerResults.Add(new BiomarkerResultDto("Sodium", 100));
        
        _biomarkers.Setup(b => b.FindAsync(It.IsAny<Expression<Func<Biomarker, bool>>>()))
            .Returns(new []
            {
                new Biomarker
                {
                    // We expect the name to be stored in upper case only
                    Name = "SODIUM"
                }
            }.BuildMock());

        await AddSampleAsync();

        _biomarkers.Verify(r => 
                r.FindOrCreateAsync(It.IsAny<Func<Task<Biomarker?>>>(), It.IsAny<Func<Task<Biomarker>>>()),
            Times.Never);
        
        _samples.Verify(x => x.InsertAsync(It.Is<Sample>(s => s.BiomarkerResults.Count == 1)), Times.Once);
    }

    [Fact]
    public async Task AddSampleAsync_Looks_Up_Hatcheries()
    {
        _uploadSample.Hatcheries = new List<string>
        {
            "Hatchery 1",
            "Hatchery 2"
        };
        
        await AddSampleAsync();

        _hatcheries.Verify(r => 
                r.FindOrCreateAsync(It.IsAny<Func<Task<Hatchery?>>>(), It.IsAny<Func<Task<Hatchery>>>()),
            Times.Exactly(2));
        
        _samples.Verify(x => x.InsertAsync(It.Is<Sample>(s => s.Hatcheries.Count == 2)), Times.Once);
    }

    [Fact]
    public async Task AddSampleAsync_Handles_Duplicate_Hatcheries()
    {
        _uploadSample.Hatcheries = new List<string>
        {
            "Hatchery 1",
            "Hatchery 1",
            "Hatchery 1"
        };

        await AddSampleAsync();

        _hatcheries.Verify(r => 
                r.FindOrCreateAsync(It.IsAny<Func<Task<Hatchery?>>>(), It.IsAny<Func<Task<Hatchery>>>()),
            Times.Exactly(1));
        
        _samples.Verify(x => x.InsertAsync(It.Is<Sample>(s => s.Hatcheries.Count == 1)), Times.Once);
    }
    
    [Fact]
    public async Task AddSampleAsync_Handles_Null_Hatcheries()
    {
        _uploadSample.Hatcheries = null;

        await AddSampleAsync();

        _biomarkers.Verify(r => 
                r.FindOrCreateAsync(It.IsAny<Func<Task<Biomarker?>>>(), It.IsAny<Func<Task<Biomarker>>>()),
            Times.Never);
        
        _samples.Verify(x => x.InsertAsync(It.Is<Sample>(s => s.Hatcheries.Count == 0)), Times.Once);
    }
    
    private async Task AddSampleAsync() => await _sampleService.AddSampleAsync(_uploadSample);
}
