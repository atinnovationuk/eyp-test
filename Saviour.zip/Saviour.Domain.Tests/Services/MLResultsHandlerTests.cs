﻿using Saviour.Domain.Entities;
using Saviour.Domain.Interfaces;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class MLResultsHandlerTests
{
    private readonly MLModel _mlModel = new();
    private readonly List<FishHealthResultType> _readResults = new();

    private readonly FakeRepository<FishHealthResult> _fishHealthResultRepository = new(new Dictionary<object, FishHealthResult>());
    private readonly MockUnitOfWork _unitOfWork = new();

    private readonly MLResultsHandler _resultsHandler;

    public MLResultsHandlerTests()
    {
        var getMlModel = new Mock<IGetMLModel>();
        getMlModel.Setup(g => g.GetLatest(It.IsAny<MLModelType>()))
            .Returns(() => _mlModel);

        var mlResultsReader = new Mock<IMLResultsReader>();
        mlResultsReader.Setup(r => r.ReadFishHealthResults(It.IsAny<Stream>()))
            .Returns(() => _readResults);

        _resultsHandler = new MLResultsHandler(_fishHealthResultRepository.Mock.Object,
            _unitOfWork.UnitOfWork.Object, mlResultsReader.Object);
    }

    [Fact]
    public async Task InsertResults_InsertsFishHealthResults()
    {
        _readResults.AddRange(new []
        {
            FishHealthResultType.Healthy,
            FishHealthResultType.Healthy,
            FishHealthResultType.Unhealthy
        });

        await _resultsHandler.InsertResults(_mlModel, new[]
        {
            new MLSampleData(3, new List<BiomarkerResultOnly>()),
            new MLSampleData(2, new List<BiomarkerResultOnly>()),
            new MLSampleData(5, new List<BiomarkerResultOnly>())
        }, new MemoryStream());
        
        Assert.Equal(
            new FishHealthResult[]
            {
                new()
                {
                    SampleId = 3,
                    Result = FishHealthResultType.Healthy,
                    Model = _mlModel
                },
                new()
                {
                    SampleId = 2,
                    Result = FishHealthResultType.Healthy,
                    Model = _mlModel
                },
                new()
                {
                    SampleId = 5,
                    Result = FishHealthResultType.Unhealthy,
                    Model = _mlModel
                }
            },
            _fishHealthResultRepository.Inserted, new FishHealthResultsComparer());
        
        _unitOfWork.VerifyChangesSaved();
    }

    private class FishHealthResultsComparer : IEqualityComparer<FishHealthResult>
    {
        public bool Equals(FishHealthResult? x, FishHealthResult? y)
        {
            // NB: Ignoring CreatedOn since that is annoying to test
            if (ReferenceEquals(x, y)) return true;
            if (ReferenceEquals(x, null)) return false;
            if (ReferenceEquals(y, null)) return false;

            return x.Result == y.Result
                && x.Model == y.Model
                && x.SampleId == y.SampleId;
        }

        public int GetHashCode(FishHealthResult obj)
        {
            return (int)obj.Result;
        }
    }
}