﻿using MockQueryable.EntityFrameworkCore;
using Saviour.Domain.Entities;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class GetMLInputsTests
{
    private readonly FakeRepository<MLBiomarker> _mlBiomarkers = new(new Dictionary<object, MLBiomarker>
    {
        [1] = new()
        {
            Id = 1,
            ModelType = MLModelType.FishHealth,
            BiomarkerId = 1,
            Biomarker = new Biomarker
            {
                Id = 1
            }
        },
        [2] = new()
        {
            Id = 2,
            ModelType = MLModelType.FishHealth,
            BiomarkerId = 2,
            Biomarker = new Biomarker
            {
                Id = 2,
                Children = new List<Biomarker>
                {
                    new()
                    {
                        Id = 22
                    }
                }
            }
        }
    });

    private readonly GetMLInputs _getMLInputs;
    
    public GetMLInputsTests()
    {
        _getMLInputs = new GetMLInputs(_mlBiomarkers.Mock.Object);
    }

    [Theory]
    [MemberData(nameof(GetData))]
    public async Task Get_ReturnsExpected(MLModel model, IEnumerable<Sample> samples, MLInputData expected)
    {
        var result = await _getMLInputs.Get(model, new TestAsyncEnumerableEfCore<Sample>(samples));
        
        Assert.Equivalent(expected, result);
    }

    private static Sample MakeSample(params int[] biomarkerIds)
        => new()
        {
            BiomarkerResults = biomarkerIds.Select(id => new BiomarkerResult
            {
                BioMarkerId = id,
                Biomarker = new Biomarker
                {
                    Id = id
                }
            }).ToList()
        };

    private static MLSampleData ToSampleData(Sample sample) => new (sample.Id, sample.BiomarkerResults.Select(result => new BiomarkerResultOnly(result.BioMarkerId, result.Result)).ToList());

    public static TheoryData<MLModel, IEnumerable<Sample>, MLInputData> GetData()
    {
        var validFishHealthSample = MakeSample(1, 2);
        
        var indirectBiomarkerSample = MakeSample(1);
        indirectBiomarkerSample.BiomarkerResults.Add(new BiomarkerResult
        {
            BioMarkerId = 22,
            Biomarker = new Biomarker
            {
                Id = 22,
                ParentId = 2,
                Parent = new Biomarker
                {
                    Id = 2
                }
            }
        });
        
        var fishHealthBiomarkers = new[]
        {
            new MLBiomarker
            {
                Id = 1,
                ModelType = MLModelType.FishHealth,
                BiomarkerId = 1,
                Biomarker = new Biomarker
                {
                    Id = 1
                }
            },
            new MLBiomarker
            {
                Id = 2,
                ModelType = MLModelType.FishHealth,
                BiomarkerId = 2,
                Biomarker = new Biomarker
                {
                    Id = 2
                }
            }
        };

        var model = new MLModel();
        
        return new TheoryData<MLModel, IEnumerable<Sample>, MLInputData>
        {
            {
                model, 
                new[]
                {
                    validFishHealthSample
                },
                new MLInputData(
                    model,
                    new[]
                    {
                        ToSampleData(validFishHealthSample)
                    },
                    fishHealthBiomarkers)
            },
            {
                model, 
                new[]
                {
                    indirectBiomarkerSample
                },
                new MLInputData(
                    model,
                    new[]
                    {
                        ToSampleData(validFishHealthSample)
                    },
                    fishHealthBiomarkers)
            },
            {
                model,
                new []
                {
                    MakeSample(1)
                },
                new MLInputData(model, Array.Empty<MLSampleData>(), fishHealthBiomarkers)
            },
            {
                model,
                new []
                {
                    MakeSample(2)
                },
                new MLInputData(model, Array.Empty<MLSampleData>(), fishHealthBiomarkers)
            },
            {
                model,
                Array.Empty<Sample>(),
                new MLInputData(model, Array.Empty<MLSampleData>(), fishHealthBiomarkers)
            }
        };
    }
}