﻿using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class PendingWorkServiceTests
{
    private readonly FakeRepository<Batch> _batches = new(new Dictionary<object, Batch>
    {
        [1] = FakeBatch(1, "Number 1", SiteA, true, 5, new DateOnly(2023, 1, 1)),
        [2] = FakeBatch(2, "Number 2", SiteB, false, 4, new DateOnly(2023, 1, 2)),
        [3] = FakeBatch(3, "Number 3", SiteC, false, 3, new DateOnly(2023, 1, 3)),
        [4] = FakeBatch(4, "Number 4", SiteB, false, 2, new DateOnly(2023, 1, 4)),
        [5] = FakeBatch(5, "Number 5", SiteA, false, 1, new DateOnly(2023, 1, 5))
    });

    private readonly FakeRepository<DraftReport> _draftReports = new(new Dictionary<object, DraftReport>
    {
        [1] = new()
        {
            Id = 1,
            CreatedOn = new DateTime(2023, 3, 1),
            Site = SiteA
        },
        [2] = new()
        {
            Id = 2,
            CreatedOn = new DateTime(2023, 3, 2),
            Site = SiteB
        },
        [4] = new()
        {
            Id = 4,
            CreatedOn = new DateTime(2023, 4, 4),
            Site = SiteC
        },
        [5] = new()
        {
            Id = 5,
            CreatedOn = new DateTime(2023, 5, 5),
            Site = SiteC
        },
        [6] = new()
        {
            Id = 6,
            CreatedOn = new DateTime(2023, 3, 3),
            Site = SiteB
        }
    });

    private readonly PendingWorkService _service;

    public PendingWorkServiceTests()
    {
        _service = new PendingWorkService(_draftReports.Mock.Object, _batches.Mock.Object);
    }

    [Fact]
    public async Task GetProducesExpectedResult()
    {
        var results = await _service.Get();

        var expected = new PendingWork(
            new List<CompanyAndSiteTree<BatchNeedingReport>>
            {
                new(new CompanyDto("C2", "Company 2", "12 Fake Avenue", 0), new List<PerSiteData<BatchNeedingReport>>
                {
                    new(new SiteDto("SB", "Site B", "C2", ""), new List<BatchNeedingReport>
                    {
                        new(2, "Number 2", 4, new DateOnly(2023, 1, 2)),
                        new(4, "Number 4", 2, new DateOnly(2023, 1, 4))
                    })
                }),
                
                new(new CompanyDto("C1", "Company 1", "44 Fake Street", 0), new List<PerSiteData<BatchNeedingReport>>
                {
                    new (new SiteDto("SC", "Site C", "C1", ""), new List<BatchNeedingReport>
                    {
                        new(3, "Number 3", 3, new DateOnly(2023, 1, 3))
                    }),
                    new(new SiteDto("SA", "Site A", "C1", ""), new List<BatchNeedingReport>
                    {
                        new(5, "Number 5", 1, new DateOnly(2023, 1, 5))
                    })
                })
            },
            new List<CompanyAndSiteTree<ReportSummary>>
            {
                new (new CompanyDto("C1", "Company 1", "44 Fake Street", 0), new List<PerSiteData<ReportSummary>>
                {
                    new(new SiteDto("SA", "Site A", "C1", ""), new List<ReportSummary>
                    {
                        new(1, new DateTime(2023, 3, 1))
                    }),
                    new(new SiteDto("SC", "Site C", "C1", ""), new List<ReportSummary>
                    {
                        new(4, new DateTime(2023, 4, 4)),
                        new(5, new DateTime(2023, 5, 5))
                    })
                }),
                new (new CompanyDto("C2", "Company 2", "12 Fake Avenue", 0), new List<PerSiteData<ReportSummary>>
                {
                    new(new SiteDto("SB", "Site B", "C2", ""), new List<ReportSummary>
                    {
                        new(2, new DateTime(2023, 3, 2)),
                        new(6, new DateTime(2023, 3, 3))
                    })
                })
            }
        );
        
        Assert.Equal(expected.BatchesNeedingReport, results.BatchesNeedingReport);
        Assert.Equal(expected.ReportsPendingReview, results.ReportsPendingReview);
    }

    [Theory]
    [MemberData(nameof(GetReportsData))]
    public async Task GetReports_ProducesExpectedResult(string companyId,
        IEnumerable<PerSiteData<ReportSummary>> expected)
    {
        var result = await _service.GetReports(companyId)
            .ToListAsync();
        
        Assert.Equal(expected, result);
    }

    public static TheoryData<string, IEnumerable<PerSiteData<ReportSummary>>> GetReportsData => new()
    {
        {
            Company1.Id, new List<PerSiteData<ReportSummary>>
            {
                new(SiteDto.FromSite(SiteA), new List<ReportSummary>
                {
                    new(1, new DateTime(2023, 3, 1))
                }),
                new(SiteDto.FromSite(SiteC), new List<ReportSummary>
                {
                    new(4, new DateTime(2023, 4, 4)),
                    new(5, new DateTime(2023, 5, 5))
                })
            }
        },
        {
            Company2.Id, new List<PerSiteData<ReportSummary>>
            {
                new(SiteDto.FromSite(SiteB), new List<ReportSummary>
                {
                    new(2, new DateTime(2023, 3, 2)),
                    new(6, new DateTime(2023, 3, 3))
                })
            }
        },
        {
            "Not there", Array.Empty<PerSiteData<ReportSummary>>()
        },
    };

    private static readonly Company Company1 = new()
    {
        Id = "C1",
        CompanyName = "Company 1",
        Address = "44 Fake Street"
    };

    private static readonly Company Company2 = new()
    {
        Id = "C2",
        CompanyName = "Company 2",
        Address = "12 Fake Avenue"
    };
    
    private static readonly Site SiteA = new()
    {
        Id = "SA",
        SiteName = "Site A",
        Company = Company1,
        CompanyId = Company1.Id
    };
    
    private static readonly Site SiteB = new()
    {
        Id = "SB",
        SiteName = "Site B",
        Company = Company2,
        CompanyId = Company2.Id
    };
    
    private static readonly Site SiteC = new()
    {
        Id = "SC",
        SiteName = "Site C",
        Company = Company1,
        CompanyId = Company1.Id
    };

    private static Batch FakeBatch(long id, string batchNumber, Site site, bool hasReports, int sampleCount,
        DateOnly dateCollected)
        => new()
        {
            Id = id,
            BatchNumber = batchNumber,
            Site = site,
            Reports = hasReports ? new Report[1] : Array.Empty<Report>(),
            Samples = new Sample[sampleCount],
            DateCollected = dateCollected
        };
}
