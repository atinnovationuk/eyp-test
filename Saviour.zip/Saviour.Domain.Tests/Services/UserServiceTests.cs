﻿using System.Security.Claims;
using System.Security.Principal;
using Saviour.Domain.Entities;
using Saviour.Domain.Exceptions;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;
using Saviour.Domain.Utility;

namespace Saviour.Domain.Tests.Services;

public class UserServiceTests
{
    private readonly UserService _service;

    private readonly FakeRepository<User> _users = new(new Dictionary<object, User>
    {
        [1] = new()
        {
            Id = 1,
            Name = "Jim",
            AzureId = "Jimothy"
        }
    });

    private readonly Mock<ClaimsPrincipal> _user = new();
    private readonly Mock<IIdentity> _userIdentity = new();
    private string? _userName = "Name";
    private string _userOid = "Oooo ID?";

    public UserServiceTests()
    {
        _userIdentity.Setup(u => u.Name)
            .Returns(() => _userName);

        _user.Setup(u => u.Identity).Returns(_userIdentity.Object);
        _user.Setup(u => u.FindFirst(ClaimSchemas.ObjectIdentifier))
            .Returns(() => new Claim(ClaimSchemas.ObjectIdentifier, _userOid));

        _service = new UserService(_users.Mock.Object);
    }

    [Fact]
    public async Task FindOrCreate_FindsExisting()
    {
        var expectedUser = _users.Items[1];

        _userOid = expectedUser.AzureId;
        
        var user = await FindOrCreate();
        
        Assert.Same(user, expectedUser);
    }

    [Fact]
    public async Task FindOrCreate_CreatesNew()
    {
        var user = await FindOrCreate();
        
        Assert.Equal(user.Name, _userName);
        Assert.Equal(user.AzureId, _userOid);
    }


    [Fact]
    public async Task FindOrCreate_ThrowsWhenUserMissingIdentity()
    {
        _user.Setup(u => u.Identity).Returns<IIdentity?>(null);
        await Assert.ThrowsAsync<InvalidUserException>(async () => await FindOrCreate());
    }
    [Fact]
    public async Task FindOrCreate_ThrowsWhenUserMissingName()
    {
        _userName = null;
        
        await Assert.ThrowsAsync<InvalidUserException>(async () => await FindOrCreate());
    }

    [Fact]
    public async Task FindOrCreate_ThrowsWhenUserMissingOID()
    {
        _user.Setup(u => u.FindFirst(ClaimSchemas.ObjectIdentifier))
            .Returns<Claim?>(null);
        
        await Assert.ThrowsAsync<InvalidUserException>(async () => await FindOrCreate());
    }

    [Fact]
    public async Task Find_FindsExisting()
    {
        var user = await _service.Find(1);
        
        Assert.Same(user, _users.Items[1]);
    }

    [Fact]
    public async Task Find_ThrowsOnNotFound()
    {
        await Assert.ThrowsAsync<EntityNotFoundException>(async () => await _service.Find(44));
    }

    private ValueTask<User> FindOrCreate() => _service.FindOrCreate(_user.Object);
}