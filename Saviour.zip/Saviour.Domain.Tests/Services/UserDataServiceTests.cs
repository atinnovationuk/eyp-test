﻿using System.Security.Claims;
using System.Security.Principal;
using Saviour.Domain.Dto;
using Saviour.Domain.Entities;
using Saviour.Domain.Services;
using Saviour.Domain.Tests.Mocks;

namespace Saviour.Domain.Tests.Services;

public class UserDataServiceTests
{
    private static Company Company1 => new()
    {
        Id = "HappyPlace",
        CompanyName = "Happy Place"
    };

    private static Company Company2 => new()
    {
        Id = "OtherHappyPlace",
        CompanyName = "Other Happy Place"
    };
    
    private readonly FakeRepository<Employee> _employees = new(new Dictionary<object, Employee>
    {
        [1] = new()
        {
            LoginIdentity = "user@gleemail.com",
            Company = Company1
        },
        [2] = new()
        {
            LoginIdentity = "user@joy.com",
            Company = Company2
        }
    });

    private readonly FakeRepository<Report> _reports = new(new Dictionary<object, Report>
    {
        [1] = new()
        {
            Id = 1,
            CreatedOn = new DateTime(1999, 9, 9),
            ReviewedById = 1,
            Site = new Site
            {
                SiteName = "Sweet shop",
                CompanyId = Company1.Id
            }
        },
        [4] = new()
        {
            Id = 4,
            CreatedOn = new DateTime(2004, 4, 4),
            ReviewedById = 1,
            Site = new Site
            {
                SiteName = "The Zoo",
                CompanyId = Company2.Id
            }
        },
        [5] = new()
        {
            Id = 5,
            CreatedOn = new DateTime(2010, 10, 10),
            ReviewedById = 2,
            Site = new Site
            {
                SiteName = "Sweet shop",
                CompanyId = Company1.Id
            }
        },
        [6] = new()
        {
            Id = 6,
            CreatedOn = new DateTime(2016, 6, 16),
            ReviewedById = 3,
            Site = new Site
            {
                SiteName = "Disneyland",
                CompanyId = Company1.Id
            }
        }
    });

    private readonly Mock<ClaimsPrincipal> _claimsPrincipal = new();
    private readonly Mock<IIdentity> _identity = new();
    private string? _currentIdentityName;

    private readonly UserDataService _userDataService;

    public UserDataServiceTests()
    {
        _userDataService = new UserDataService(_employees.Mock.Object, _reports.Mock.Object);

        _claimsPrincipal.Setup(c => c.Identity)
            .Returns(_identity.Object);
        _identity.Setup(i => i.Name)
            .Returns(() => _currentIdentityName);
    }

    private ValueTask<CompanyDto?> TryGetCompany() => _userDataService.TryGetCompany(_claimsPrincipal.Object);

    [Theory]
    [MemberData(nameof(TryGetCompanyData))]
    public async Task TryGetCompany_ReturnsCompanyWhenFound(string identityName, CompanyDto expectedResult)
    {
        _currentIdentityName = identityName;

        var company = await TryGetCompany();

        Assert.Equal(expectedResult, company);
    }

    public static TheoryData<string, CompanyDto> TryGetCompanyData => new()
    {
        { "user@gleemail.com", CompanyDto.FromCompany(Company1) },
        { "user@joy.com", CompanyDto.FromCompany(Company2) },
    };

    [Fact]
    public async Task TryGetCompany_ReturnsNullWhenEmployeeNotFound()
    {
        _currentIdentityName = "bob@bobmail.com";

        Assert.Null(await TryGetCompany());
    }

    [Fact]
    public async Task TryGetCompany_ReturnsNullOnNullIdentity()
    {
        _claimsPrincipal.Setup(c => c.Identity)
            .Returns<IIdentity?>(null);

        Assert.Null(await TryGetCompany());
    }

    [Fact]
    public async Task TryGetCompany_ReturnsNullOnNullIdentityName()
    {
        _currentIdentityName = null;
        Assert.Null(await TryGetCompany());
    }

    [Theory]
    [MemberData(nameof(GetReportsData))]
    public async Task GetReports_ReturnsReviewedReportsForCompany(string companyId, IEnumerable<PerSiteData<ReportSummary>> expectedResult)
    {
        var reports = await _userDataService.GetReports(companyId).ToListAsync();

        Assert.Equal(expectedResult, reports);
    }

    public static TheoryData<string, IEnumerable<PerSiteData<ReportSummary>>> GetReportsData => new()
    {
        {
            Company1.Id, 
            new[]
            {
                new PerSiteData<ReportSummary>(new SiteDto("", "Sweet shop", Company1.Id, ""),
                    new []
                    {
                        new ReportSummary(1, new DateTime(1999, 9, 9)),
                        new ReportSummary(5, new DateTime(2010, 10, 10))
                    }
                ),
                new PerSiteData<ReportSummary>(new SiteDto("", "Disneyland", Company1.Id, ""), 
                    new []
                    {
                        new ReportSummary(6, new DateTime(2016, 6, 16))
                    }
                )
            }
        },
        
        {
            Company2.Id,
            new[]
            {
                new PerSiteData<ReportSummary>(new SiteDto("", "The Zoo", Company2.Id, ""),
                    new []
                    {
                        new ReportSummary(4, new DateTime(2004, 4, 4))
                    }
                )
            }
        },

        { "UnhappyPlace", Array.Empty<PerSiteData<ReportSummary>>() },
    };
}
