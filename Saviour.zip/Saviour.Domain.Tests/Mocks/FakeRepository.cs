﻿using System.Linq.Expressions;
using Saviour.Domain.Interfaces;
using MockQueryable.Moq;

namespace Saviour.Domain.Tests.Mocks;

internal class FakeRepository<T> where T : class
{
    public Dictionary<object, T> Items { get; }

    public Mock<IRepository<T>> Mock { get; } = new();

    public IList<T> Inserted { get; } = new List<T>();

    public FakeRepository(Dictionary<object, T> items)
    {
        Items = items;
        
        Mock.Setup(repo => repo.GetAll())
            .Returns(() => AllValues().BuildMock());

        Mock.Setup(repo => repo.FindAsync(It.IsAny<Expression<Func<T, bool>>>()))
            .Returns<Expression<Func<T, bool>>>(expression => AllValues().BuildMock().Where(expression));

        Mock.Setup(repo => repo.GetByIdAsync(It.IsAny<object>()))
            .Returns<object>(id => Items.TryGetValue(id, out var found) 
                ? ValueTask.FromResult<T?>(found) 
                : ValueTask.FromResult<T?>(default));

        Mock.Setup(repo => repo.InsertAsync(It.IsAny<T>()))
            .Callback<T>(item => Inserted.Add(item))
            .Returns<T>(ValueTask.FromResult);
        
        Mock.Setup(repo => repo.FindOrCreateAsync(It.IsAny<Func<Task<T?>>>(), It.IsAny<Func<Task<T>>>()))
            .Returns<Func<Task<T?>>, Func<Task<T>>>(async (find, create) =>
            {
                var found = await find();
                if (found != null)
                {
                    return found;
                }
            
                var created = await create();
                Inserted.Add(created);
                return created;
            });
        
        Mock.Setup(repo => repo.FindByIdOrCreateAsync(It.IsAny<object>(), It.IsAny<Func<Task<T>>>()))
            .Returns<Func<object>, Func<Task<T>>>(async (id, create) =>
            {
                if (Items.TryGetValue(id, out var found) )
                {
                    return found;
                }
            
                var created = await create();
                Inserted.Add(created);
                return created;
            });
        
        Mock.Setup(repo => repo.Delete(It.IsAny<T>()))
            .Callback<T>(item =>
            {
                var itemKey = Items.Where(pair => Equals(item, pair.Value))
                    .Select(pair => pair.Key)
                    .FirstOrDefault();
                if (itemKey != null)
                {
                    Items.Remove(itemKey);
                    return;
                }
                Inserted.Remove(item);
            });
    }

    private IEnumerable<T> AllValues()
    {
        return Items.Values
            .Concat(Inserted);
    }
}
