﻿using Saviour.Domain.Interfaces;

namespace Saviour.Domain.Tests.Mocks;

public class MockUnitOfWork
{
    public Mock<IUnitOfWork> UnitOfWork { get; } = new();
    public Mock<ITransaction> Transaction { get; } = new();

    public void VerifyChangesSaved() => UnitOfWork.Verify(u => u.SaveChangesAsync());
    public void VerifyChangesNotSaved() => UnitOfWork.Verify(u => u.SaveChangesAsync(), Times.Never);

    public MockUnitOfWork()
    {
        UnitOfWork.Setup(u => u.BeginTransaction())
            .Returns(() => ValueTask.FromResult(Transaction.Object));
    }
}